# Signal Chase — HCI Unity ML-Agents lab

A Unity reinforcement-learning exercise based on the class roller-agent task. The baseline reaches a stationary goal. The extension follows a moving goal and lets the user steer it with the keyboard. Both agents use trained neural policies, with no scripted chasing controller.

## Files

- `SignalChase/`: Unity 6000.0.23f1 project, ML-Agents 4.0.0.
- `config/ppo.yaml`: two PPO behaviors, 200,000 training steps each.
- `scripts/train.ps1`: launches actual ML-Agents training.
- `scripts/analyze.py`: summarizes recorded evaluation episodes and reads TensorBoard scalar events.
- `results/`: native ML-Agents checkpoints, ONNX exports and TensorBoard events.
- `verification/`: actual evaluation JSON, derived CSV, graphs and player screenshots.
- `logs/`: build, training and evaluation logs.

## Environment

The existing Unity installation is reused at `D:\unity\6000.0.23f1`. Python 3.10.12 and the separate `mlagents-env` environment live in `D:\1_VAR_blog\HCI\tools`. New packages, training output and caches stay on D:.

The Python trainer and Unity package are a matched release: ML-Agents Python 1.1.0 and Unity ML-Agents 4.0.0 (release 23). The unrelated existing `D:\UnityRLProject` is untouched.

## Task and policy interface

Each arena is a 10 × 10 platform. A cyan Rigidbody sphere moves with two continuous acceleration actions. A gold target is stationary (`ReachTarget`) or moves at 1.2 units per second and reflects from arena edges (`ChaseTarget`).

The eight normalized observations, in order, are:

1. Target position minus agent position, X/Z, divided by 5.
2. Agent linear velocity, X/Z, divided by 5.
3. Target velocity, X/Z, divided by 3.
4. Agent position within the arena, X/Z, divided by 5.

The agent receives `0.08 × reduction in distance - 0.001` per physics action, +1 when it gets within 0.8 units of the goal, and -1 when it leaves the platform. Episodes also end at 500 physics steps (approximately 10 seconds). Decision period is 5 physics steps. The trainer runs 16 independent arenas for each behavior.

## Completed experiment

Training and evaluation finished on 15 October 2026. The final run is **`signal-chase-02`**. The first run remains in `results/signal-chase-01` and `logs/training-01.log` as a failed experiment: default contact friction resisted the frozen-rotation sphere's small force actions. The final environment uses zero static and dynamic friction on both the sphere and platform. Rigidbody mass is 1, linear damping is 2.5, acceleration scale is 14, and planar speed is capped at 4.5.

Run 02 reached 200,005 trainer steps for `ReachTarget` and 200,008 for `ChaseTarget`, after approximately 304 seconds. The two policies are separate 2 × 64 networks. Their exported files are each 23,856 bytes.

| Task | Random actions | Final ONNX | Mean trained capture time |
| --- | --- | --- | --- |
| Stationary target | 10 / 100 | 100 / 100 | 1.084 s |
| Moving target | 18 / 100 | 100 / 100 | 1.193 s |

Times are simulated episode seconds. Each rate uses all 100 episodes for that task, including failures. The 400 individual episode records, summary calculation, training scalars and graph validation are in `verification/`. `training-curves.png` plots mean reward and policy entropy; it is not an evaluation success-rate plot. These results cover one independent evaluation seed, not arbitrary trajectories or human usability.

Final model SHA-256 identities (identical in `results/signal-chase-02` and `SignalChase/Assets/Models`):

```text
ReachTarget  816fbb31b82516c94ca90e5a530d31aa6e2db9613ead47f997a50fb7caf93813
ChaseTarget  da21c288c6174ed28ca8766acaefef6fa3688a9e226c846b0fb82e5dd001a3ae
```

## Open, build and reproduce

Open `SignalChase/` in Unity 6000.0.23f1, then open `Assets/Scenes/SignalChase.unity`. The scene already references both final models. Use **Signal Chase → Build Windows** to make the standalone player. The editor entry point is `SignalChase.SignalChaseBuilder.BuildWindows` for batch builds. Windows inference uses the included models and does not require Python.

The command used for the final training run, from this lab directory, was:

```powershell
.\scripts\train.ps1 -RunId signal-chase-02
```

That run already exists; do not rerun it to inspect the delivered result. To train a new experiment, use a fresh run ID such as `signal-chase-03`, with the pinned Python 3.10 dependencies in `requirements.txt`. The YAML configuration references the standalone training environment, so build it first. After a new run, copy its two ONNX exports into `SignalChase/Assets/Models/` and rebuild. Keep both models from the same run.

The normal application has buttons for the static and moving tasks, reset, pause, and target control. With target control enabled, WASD or the arrow keys move the gold target. The cyan sphere still uses its neural policy.

## Evaluation protocol

Two standalone-player runs use the same arena code, an evaluation seed of 20261015 (different from training seed 742), 100 episodes per task and a 10-second maximum episode duration. One uses independent uniformly random continuous actions; the other uses deterministic ONNX inference. Random action sampling has its own RNG, so it does not change the sequence of reset layouts or automatic target headings. Successful captures, timeouts and falls all count in the denominator.

Example player arguments:

```text
--evaluate --episodes 100 --random --report D:\1_VAR_blog\HCI\lab-ml-agents\verification\random-evaluation.json
--evaluate --episodes 100 --report D:\1_VAR_blog\HCI\lab-ml-agents\verification\trained-evaluation.json
```

The reports are complete in `verification/summary.json`. `scripts/evaluate.ps1` reruns the two policies and regenerates their reports, while `scripts/analyze.py --run signal-chase-02` only derives tables and figures from the existing raw data. `scripts/verify-models.py` checks the exported ONNX graphs and finite CPU outputs. No repeat training is needed for either check. Preserve the original reports before deliberately rerunning evaluation.

## Runtime evidence and sharing

The supplied Windows build is in `SignalChase/Builds/Windows/`. Keep the executable, data directory, Mono runtime and Unity DLL together. The `*_BurstDebugInformation_DoNotShip` directory is not required to run it.

A hidden Windows player can produce all-black backbuffer screenshots. `--camera-capture` explicitly renders the running scene's real camera to a render texture instead. These captures contain the 3D scene and exclude IMGUI controls; they are not screenshots of a human playthrough. Example:

```powershell
.\scripts\capture-player.ps1
```

Successful images and renderer logs are retained under `verification/runtime-static`, `verification/runtime-moving` and `logs/camera-*.log`. The failed black backbuffer captures remain under `verification/player-static` and `verification/player-moving` for traceability. Only the runtime camera captures are suitable for illustration.

`scripts/package-source.ps1` makes `deliverables/signal-chase-source.zip`. The small source archive includes Unity Assets and their `.meta` files, both final ONNX models, Packages, ProjectSettings, configuration, scripts, documentation and selected raw evidence. Unity Library/Temp caches, compiled players, external environments, teacher slides and unrelated repositories are excluded. The complete local experiment retains the checkpoints and full build separately.

## Course materials used

`HCI/Human Computer Interaction/LAB_homework/ML_agent/Lab1_Unity_ML_agent.pptx` requires environment setup/testing, an extension to a new situation, and a process blog. The supplied `RollerAgent.cs`, `rollerball_config.yaml` and `Unity ML-Agents.pptx` provide the starting roller-agent idea.

## Reference record

- Official release 23 package manifest: https://github.com/Unity-Technologies/ml-agents/blob/release_23/com.unity.ml-agents/package.json
- Official training guide: https://unity-technologies.github.io/ml-agents/Training-ML-Agents/
- Official Unity 4.0 installation guide: https://docs.unity3d.com/Packages/com.unity.ml-agents@4.0/manual/Installation.html
