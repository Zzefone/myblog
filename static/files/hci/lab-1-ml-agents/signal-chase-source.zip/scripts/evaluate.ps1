param([int]$Episodes = 100)
$ErrorActionPreference = 'Stop'
$labRoot = Split-Path $PSScriptRoot -Parent
$env:TEMP = Join-Path $labRoot 'tmp'
$env:TMP = $env:TEMP
$env:MPLCONFIGDIR = Join-Path (Split-Path $labRoot -Parent) 'tools\cache\matplotlib'
$env:XDG_CACHE_HOME = Join-Path (Split-Path $labRoot -Parent) 'tools\cache'
$env:OMP_NUM_THREADS = '2'
$env:MKL_NUM_THREADS = '2'
$player = Join-Path $labRoot 'SignalChase\Builds\Windows\SignalChase.exe'
$processes = @()
foreach ($policy in @('random', 'trained')) {
    $playerArgs = @('-batchmode', '-nographics', '-job-worker-count', '2', '--evaluate', '--episodes', $Episodes, '--evaluation-seed', '20261015', '--report', (Join-Path $labRoot "verification\$policy-evaluation.json"), '-logFile', (Join-Path $labRoot "logs\$policy-evaluation.log"))
    if ($policy -eq 'random') { $playerArgs += '--random' }
    $processes += Start-Process -FilePath $player -ArgumentList $playerArgs -WindowStyle Hidden -PassThru
}
$processes | Wait-Process
foreach ($policy in @('random', 'trained')) {
    $report = Join-Path $labRoot "verification\$policy-evaluation.json"
    if (!(Test-Path -LiteralPath $report)) { throw "Missing evaluation report: $policy" }
    $data = Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
    if ($data.episodes.Count -ne 2 * $Episodes) { throw "Incomplete evaluation: $policy" }
}
$python = Join-Path (Split-Path $labRoot -Parent) 'tools\mlagents-env\Scripts\python.exe'
& $python (Join-Path $PSScriptRoot 'analyze.py') --run signal-chase-02
if ($LASTEXITCODE -ne 0) { throw 'Evaluation analysis failed.' }
& $python (Join-Path $PSScriptRoot 'verify-models.py')
if ($LASTEXITCODE -ne 0) { throw 'Model graph validation failed.' }
