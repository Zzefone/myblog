param([int]$UnityPid, [string]$BuildLog = 'unity-friction-build.log', [string]$RunId = 'signal-chase-02')
$ErrorActionPreference = 'Stop'
$labRoot = Split-Path $PSScriptRoot -Parent
if (Get-Process -Id $UnityPid -ErrorAction SilentlyContinue) { Wait-Process -Id $UnityPid }
$buildText = Get-Content -LiteralPath (Join-Path $labRoot "logs\$BuildLog") -Raw
if ($buildText -notmatch 'SIGNAL_CHASE_BUILD Succeeded') { throw 'The Unity training environment did not build successfully.' }
& (Join-Path $PSScriptRoot 'train.ps1') -RunId $RunId
