param([string]$RunId = 'signal-chase-02', [switch]$Resume)
$ErrorActionPreference = 'Stop'
$labRoot = Split-Path $PSScriptRoot -Parent
$toolsRoot = Join-Path (Split-Path $labRoot -Parent) 'tools'
$env:TEMP = Join-Path $labRoot 'tmp'
$env:TMP = $env:TEMP
$env:PIP_CACHE_DIR = Join-Path $toolsRoot 'cache\pip'
$env:TORCH_HOME = Join-Path $toolsRoot 'cache\torch'
$env:MPLCONFIGDIR = Join-Path $toolsRoot 'cache\matplotlib'
$env:NUMBA_CACHE_DIR = Join-Path $toolsRoot 'cache\numba'
$env:OMP_NUM_THREADS = '2'
$env:MKL_NUM_THREADS = '2'
$env:PYTHONIOENCODING = 'utf-8'
Push-Location $labRoot
try {
    $trainArgs = @('-m', 'mlagents.trainers.learn', 'config/ppo.yaml', '--run-id', $RunId, '--results-dir', 'results')
    if ($Resume) { $trainArgs += '--resume' }
    & (Join-Path $toolsRoot 'mlagents-env\Scripts\python.exe') @trainArgs
    if ($LASTEXITCODE -ne 0) { throw "ML-Agents exited with code $LASTEXITCODE" }
} finally { Pop-Location }
