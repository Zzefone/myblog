"""Validate the actual exported ONNX graphs and record their identities."""
import hashlib
import json
from pathlib import Path
import numpy as np
import onnx
import onnxruntime as ort

root = Path(__file__).resolve().parents[1]
reports = []
for task in ("ReachTarget", "ChaseTarget"):
    path = root / "SignalChase" / "Assets" / "Models" / f"{task}.onnx"
    onnx.checker.check_model(str(path))
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(str(path), sess_options=options, providers=["CPUExecutionProvider"])
    feed = {}
    for entry in session.get_inputs():
        shape = [dim if isinstance(dim, int) and dim > 0 else 1 for dim in entry.shape]
        feed[entry.name] = np.zeros(shape, dtype=np.float32)
    outputs = session.run(None, feed)
    assert all(np.isfinite(output).all() for output in outputs), task
    reports.append({"task": task, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "bytes": path.stat().st_size,
                    "inputs": [{"name": x.name, "shape": x.shape} for x in session.get_inputs()],
                    "outputs": [{"name": x.name, "shape": x.shape} for x in session.get_outputs()],
                    "onnx_checker": "passed", "cpu_finite_outputs": True})
(root / "verification" / "model-verification.json").write_text(json.dumps(reports, indent=2))
print(json.dumps(reports, indent=2))
