$ErrorActionPreference = 'Stop'
$labRoot = Split-Path $PSScriptRoot -Parent
$env:TEMP = Join-Path $labRoot 'tmp'
$env:TMP = $env:TEMP
$playerFile = Join-Path $labRoot 'SignalChase\Builds\Windows\SignalChase.exe'
foreach ($task in @('static', 'moving')) {
    $captureDir = Join-Path $labRoot "verification\runtime-$task"
    $captureArgs = @('-screen-fullscreen', '0', '-screen-width', '1280', '-screen-height', '800',
        '-job-worker-count', '2', '--task', $task, '--camera-capture', '--capture-dir', $captureDir,
        '--quit-after', '11', '-logFile', (Join-Path $labRoot "logs\camera-$task.log"))
    $playerProcess = Start-Process -FilePath $playerFile -ArgumentList $captureArgs -WindowStyle Hidden -PassThru
    $playerProcess | Wait-Process
    if (!(Test-Path -LiteralPath (Join-Path $captureDir 'runtime-camera-1.png'))) {
        throw "The $task runtime camera did not produce an image. Check logs/camera-$task.log."
    }
    Get-ChildItem -LiteralPath $captureDir -Filter '*.png' | Select-Object FullName, Length
}
