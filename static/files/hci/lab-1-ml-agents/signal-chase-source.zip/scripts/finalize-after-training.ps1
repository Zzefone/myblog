param([int]$TrainingPid)
$ErrorActionPreference = 'Stop'
$labRoot = Split-Path $PSScriptRoot -Parent
if (Get-Process -Id $TrainingPid -ErrorAction SilentlyContinue) { Wait-Process -Id $TrainingPid }
$modelFiles = @('ReachTarget.onnx', 'ChaseTarget.onnx') | ForEach-Object { Join-Path $labRoot "results\signal-chase-02\$_" }
foreach ($model in $modelFiles) { if (!(Test-Path -LiteralPath $model)) { throw "Missing final model: $model" } }
Copy-Item -LiteralPath $modelFiles -Destination (Join-Path $labRoot 'SignalChase\Assets\Models')
$env:TEMP = Join-Path $labRoot 'tmp'
$env:TMP = $env:TEMP
$env:UPM_CACHE_ROOT = Join-Path $labRoot 'upm-cache'
$env:UPM_NPM_CACHE_PATH = Join-Path $env:UPM_CACHE_ROOT 'npm'
$env:UPM_CACHE_PATH = Join-Path $env:UPM_CACHE_ROOT 'packages'
$buildProcess = Start-Process -FilePath 'D:\unity\6000.0.23f1\Editor\Unity.exe' -ArgumentList '-batchmode', '-nographics', '-quit', '-job-worker-count', '2', '-projectPath', (Join-Path $labRoot 'SignalChase'), '-executeMethod', 'SignalChase.SignalChaseBuilder.BuildWindows', '-logFile', (Join-Path $labRoot 'logs\unity-final-build.log') -WindowStyle Hidden -PassThru
Wait-Process -Id $buildProcess.Id
$buildText = Get-Content -LiteralPath (Join-Path $labRoot 'logs\unity-final-build.log') -Raw
if ($buildText -notmatch 'SIGNAL_CHASE_BUILD Succeeded') { throw 'Final inference player build failed.' }
& (Join-Path $PSScriptRoot 'evaluate.ps1')
