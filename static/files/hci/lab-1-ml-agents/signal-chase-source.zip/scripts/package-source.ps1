$ErrorActionPreference = 'Stop'
$labRoot = Split-Path $PSScriptRoot -Parent
$deliverables = Join-Path $labRoot 'deliverables'
New-Item -ItemType Directory -Force -Path $deliverables | Out-Null
$stagingRoot = Join-Path $deliverables ('source-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$projectTarget = Join-Path $stagingRoot 'SignalChase'
New-Item -ItemType Directory -Force -Path (Join-Path $projectTarget 'Assets') | Out-Null
foreach ($name in @('Scripts', 'Editor', 'Scenes', 'Materials', 'Models')) {
    Copy-Item -LiteralPath (Join-Path $labRoot "SignalChase\Assets\$name") -Destination (Join-Path $projectTarget 'Assets') -Recurse
    $folderMeta = Join-Path $labRoot "SignalChase\Assets\$name.meta"
    if (Test-Path -LiteralPath $folderMeta) { Copy-Item -LiteralPath $folderMeta -Destination (Join-Path $projectTarget 'Assets') }
}
foreach ($name in @('Packages', 'ProjectSettings')) {
    Copy-Item -LiteralPath (Join-Path $labRoot "SignalChase\$name") -Destination $projectTarget -Recurse
}
Copy-Item -LiteralPath (Join-Path $labRoot 'SignalChase\.gitignore') -Destination $projectTarget
foreach ($name in @('config', 'scripts')) { Copy-Item -LiteralPath (Join-Path $labRoot $name) -Destination $stagingRoot -Recurse }
Copy-Item -LiteralPath (Join-Path $labRoot 'README.md'), (Join-Path $labRoot 'experiment-notes.md'), (Join-Path $labRoot 'requirements.txt') -Destination $stagingRoot
$evidenceTarget = Join-Path $stagingRoot 'verification'
New-Item -ItemType Directory -Force -Path $evidenceTarget | Out-Null
foreach ($name in @('random-evaluation.json', 'trained-evaluation.json', 'summary.json', 'summary.csv', 'training-scalars.csv', 'training-curves.png', 'model-verification.json')) {
    $evidence = Join-Path $labRoot "verification\$name"
    if (Test-Path -LiteralPath $evidence) { Copy-Item -LiteralPath $evidence -Destination $evidenceTarget }
}
foreach ($name in @('runtime-static', 'runtime-moving')) {
    $evidence = Join-Path $labRoot "verification\$name"
    if (Test-Path -LiteralPath $evidence) { Copy-Item -LiteralPath $evidence -Destination $evidenceTarget -Recurse }
}
$logTarget = Join-Path $stagingRoot 'logs'
New-Item -ItemType Directory -Force -Path $logTarget | Out-Null
foreach ($name in @('training-01.log', 'training-02.log', 'random-evaluation.log', 'trained-evaluation.log', 'camera-static.log', 'camera-moving.log')) {
    $logFile = Join-Path $labRoot "logs\$name"
    if (Test-Path -LiteralPath $logFile) { Copy-Item -LiteralPath $logFile -Destination $logTarget }
}
foreach ($run in @('signal-chase-01', 'signal-chase-02')) {
    $runSource = Join-Path $labRoot "results\$run"
    $runTarget = Join-Path $stagingRoot "results\$run"
    New-Item -ItemType Directory -Force -Path (Join-Path $runTarget 'run_logs') | Out-Null
    Copy-Item -LiteralPath (Join-Path $runSource 'configuration.yaml') -Destination $runTarget
    Copy-Item -LiteralPath (Join-Path $runSource 'run_logs\training_status.json') -Destination (Join-Path $runTarget 'run_logs')
    foreach ($task in @('ReachTarget', 'ChaseTarget')) {
        $eventTarget = Join-Path $runTarget $task
        New-Item -ItemType Directory -Force -Path $eventTarget | Out-Null
        Get-ChildItem -LiteralPath (Join-Path $runSource $task) -Filter 'events.out.tfevents.*' | Copy-Item -Destination $eventTarget
    }
}
$archive = Join-Path $deliverables 'signal-chase-source.zip'
Compress-Archive -LiteralPath (Get-ChildItem -LiteralPath $stagingRoot).FullName -DestinationPath $archive -CompressionLevel Optimal -Force
Get-Item -LiteralPath $archive
