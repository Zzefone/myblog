"""Summarize recorded Unity episodes and render actual TensorBoard scalars."""
import argparse
import csv
import json
from pathlib import Path
from statistics import mean

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--run", default="signal-chase-02")
args = parser.parse_args()
verification = root / "verification"
verification.mkdir(exist_ok=True)
rows = []
for policy in ("random", "trained"):
    report = json.loads((verification / f"{policy}-evaluation.json").read_text())
    for task in ("ReachTarget", "ChaseTarget"):
        episodes = [e for e in report["episodes"] if e["task"] == task]
        successes = [e for e in episodes if e["success"]]
        assert len(episodes) == report["episodes_per_task"], (policy, task, len(episodes))
        rows.append({"policy": policy, "task": task, "episodes": len(episodes),
                     "successes": len(successes), "success_rate": len(successes) / len(episodes),
                     "mean_seconds_all": mean(e["seconds"] for e in episodes),
                     "mean_seconds_success": mean(e["seconds"] for e in successes) if successes else None,
                     "mean_reward": mean(e["reward"] for e in episodes)})
(verification / "summary.json").write_text(json.dumps(rows, indent=2))
with (verification / "summary.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.2), constrained_layout=True)
scalar_rows = []
for task, color in (("ReachTarget", "#167c9a"), ("ChaseTarget", "#cd761d")):
    acc = EventAccumulator(str(root / "results" / args.run / task))
    acc.Reload()
    for ax, tag, ylabel in zip(axes, ("Environment/Cumulative Reward", "Policy/Entropy"), ("Mean episode reward", "Policy entropy")):
        if tag not in acc.Tags().get("scalars", []):
            continue
        values = acc.Scalars(tag)
        ax.plot([v.step for v in values], [v.value for v in values], label=task, color=color, linewidth=2)
        ax.set_xlabel("Training steps per behavior")
        ax.set_xticks((0, 50000, 100000, 150000, 200000), labels=("0", "50k", "100k", "150k", "200k"))
        ax.set_xlim(0, 200000)
        ax.set_ylabel(ylabel)
        ax.grid(alpha=.18)
        ax.legend(frameon=False)
        for value in values:
            scalar_rows.append({"task": task, "tag": tag, "step": value.step, "value": value.value})
fig.savefig(verification / "training-curves.png", dpi=160)
with (verification / "training-scalars.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=("task", "tag", "step", "value"))
    writer.writeheader()
    writer.writerows(scalar_rows)
print(json.dumps(rows, indent=2))
