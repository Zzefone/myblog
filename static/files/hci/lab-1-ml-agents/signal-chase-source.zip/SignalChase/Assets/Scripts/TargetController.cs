using UnityEngine;

namespace SignalChase
{
    public class TargetController : MonoBehaviour
    {
        public bool Moving;
        public bool Manual;
        public Vector3 Velocity { get; private set; }
        private Vector2 manualDirection;
        private Vector3 automaticDirection;
        public void ResetTarget(Vector3 localPosition, Vector2 direction)
        {
            transform.localPosition = localPosition;
            automaticDirection = new Vector3(direction.x, 0, direction.y).normalized;
            Velocity = Moving ? automaticDirection * 1.2f : Vector3.zero;
        }
        public void ManualDirection(Vector2 direction)
        {
            Manual = true;
            Moving = true;
            manualDirection = Vector2.ClampMagnitude(direction, 1f);
        }
        private void FixedUpdate()
        {
            if (!Moving) { Velocity = Vector3.zero; return; }
            Velocity = Manual ? new Vector3(manualDirection.x, 0, manualDirection.y) * 2.1f : automaticDirection * 1.2f;
            Vector3 next = transform.localPosition + Velocity * Time.fixedDeltaTime;
            if (Mathf.Abs(next.x) > 4.1f) { automaticDirection.x *= -1; next.x = Mathf.Clamp(next.x, -4.1f, 4.1f); }
            if (Mathf.Abs(next.z) > 4.1f) { automaticDirection.z *= -1; next.z = Mathf.Clamp(next.z, -4.1f, 4.1f); }
            transform.localPosition = next;
        }
    }
}
