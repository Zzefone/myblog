using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Unity.InferenceEngine;
using Unity.MLAgents.Policies;
using Unity.MLAgents.Actuators;
using Unity.MLAgents;

namespace SignalChase
{
    public class SignalChaseApp : MonoBehaviour
    {
        public ModelAsset ReachModel;
        public ModelAsset ChaseModel;
        public Material BaseMaterial;
        private readonly List<RollerChaseAgent> agents = new List<RollerChaseAgent>();
        private readonly List<EpisodeRecord> records = new List<EpisodeRecord>();
        private bool training;
        private bool evaluation;
        private bool random;
        private int evaluationEpisodes;
        private int evaluationSeed;
        private string output;
        private string capture;
        private bool cameraCapture;
        private float quitAfter;
        private float nextCapture = 3f;
        private int captureCount;
        private bool paused;
        private int selectedTask = 1;
        private GUIStyle heading, normal, button;
        private Texture2D solid;

        [Serializable] public class EpisodeRecord { public string task; public int episode; public bool success; public float seconds; public float reward; }
        [Serializable] public class EvaluationReport { public string policy; public int seed; public int episodes_per_task; public List<EpisodeRecord> episodes; }

        public static string Arg(string name, string fallback = "")
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length; i++) if (args[i] == name) return i + 1 < args.Length ? args[i + 1] : "true";
            return fallback;
        }
        public static bool Has(string name) => Array.IndexOf(Environment.GetCommandLineArgs(), name) >= 0;

        private void Start()
        {
            Application.runInBackground = true;
            training = Has("--train");
            evaluation = Has("--evaluate");
            random = Has("--random");
            evaluationEpisodes = int.Parse(Arg("--episodes", "100"));
            evaluationSeed = int.Parse(Arg("--evaluation-seed", "20261015"));
            output = Arg("--report", Path.Combine(Application.dataPath, "evaluation.json"));
            capture = Arg("--capture-dir");
            cameraCapture = Has("--camera-capture");
            float.TryParse(Arg("--quit-after", "0"), out quitAfter);
            Time.fixedDeltaTime = .02f;
            if (evaluation) Time.timeScale = 20;
            Application.targetFrameRate = training || evaluation ? -1 : 60;
            QualitySettings.vSyncCount = 0;
            Physics.gravity = new Vector3(0, -9.81f, 0);
            int count = training ? 16 : 1;
            if (!training && !random && (ReachModel == null || ChaseModel == null))
            {
                Debug.LogError("Both trained ONNX models are required. No rule-based fallback is used.");
                if (evaluation) { Application.Quit(2); return; }
            }
            for (int i = 0; i < count; i++)
            {
                MakeArena("ReachTarget", false, new Vector3((i % 4) * 14, 0, (i / 4) * 14), i);
                MakeArena("ChaseTarget", true, new Vector3((i % 4) * 14 + 70, 0, (i / 4) * 14), i);
            }
            if (!training && !evaluation) SelectTask(Arg("--task", "moving") == "static" ? 0 : 1);
            MakeCamera();
            if (!string.IsNullOrEmpty(capture)) Directory.CreateDirectory(capture);
        }

        private Material Mat(Color color)
        {
            Material material = BaseMaterial != null ? new Material(BaseMaterial) : new Material(Shader.Find("Standard"));
            material.color = color;
            material.SetFloat("_Glossiness", .25f);
            return material;
        }
        private GameObject Primitive(PrimitiveType type, string name, Transform parent, Vector3 position, Vector3 scale, Color color)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().material = Mat(color);
            return go;
        }
        private void MakeArena(string task, bool moving, Vector3 origin, int index)
        {
            GameObject arena = new GameObject(task + "_Arena_" + index);
            arena.transform.position = origin;
            GameObject platform = Primitive(PrimitiveType.Cube, "Platform", arena.transform, new Vector3(0, -.2f, 0), new Vector3(10, .4f, 10), new Color(.12f, .20f, .29f));
            PhysicsMaterial sliding = new PhysicsMaterial("Low-friction learning surface")
            {
                dynamicFriction = 0,
                staticFriction = 0,
                bounciness = 0,
                frictionCombine = PhysicsMaterialCombine.Minimum,
                bounceCombine = PhysicsMaterialCombine.Minimum
            };
            platform.GetComponent<Collider>().sharedMaterial = sliding;
            for (int i = -4; i <= 4; i++)
            {
                GameObject stripe = Primitive(PrimitiveType.Cube, "Floor marking", arena.transform, new Vector3(i, .003f, 0), new Vector3(.018f, .006f, 9.8f), new Color(.22f, .33f, .42f));
                Destroy(stripe.GetComponent<Collider>());
                stripe = Primitive(PrimitiveType.Cube, "Floor marking", arena.transform, new Vector3(0, .003f, i), new Vector3(9.8f, .006f, .018f), new Color(.22f, .33f, .42f));
                Destroy(stripe.GetComponent<Collider>());
            }
            GameObject goal = Primitive(PrimitiveType.Cylinder, "Signal target", arena.transform, new Vector3(2, .25f, 2), new Vector3(.95f, .24f, .95f), new Color(1f, .68f, .18f));
            Destroy(goal.GetComponent<Collider>());
            TargetController target = goal.AddComponent<TargetController>();
            target.Moving = moving;
            GameObject ball = Primitive(PrimitiveType.Sphere, "Learning agent", arena.transform, new Vector3(-2, .36f, -2), Vector3.one * .7f, new Color(.13f, .82f, .89f));
            ball.GetComponent<Collider>().sharedMaterial = sliding;
            ball.SetActive(false);
            Rigidbody body = ball.AddComponent<Rigidbody>();
            body.linearDamping = 2.5f;
            body.angularDamping = .4f;
            body.constraints = RigidbodyConstraints.FreezeRotation;
            BehaviorParameters behavior = ball.AddComponent<BehaviorParameters>();
            behavior.BehaviorName = task;
            behavior.BrainParameters.VectorObservationSize = 8;
            behavior.BrainParameters.ActionSpec = ActionSpec.MakeContinuous(2);
            behavior.BrainParameters.NumStackedVectorObservations = 1;
            behavior.InferenceDevice = InferenceDevice.Burst;
            behavior.DeterministicInference = true;
            if (!training)
            {
                behavior.Model = moving ? ChaseModel : ReachModel;
                behavior.BehaviorType = random ? BehaviorType.HeuristicOnly : BehaviorType.InferenceOnly;
            }
            RollerChaseAgent agent = ball.AddComponent<RollerChaseAgent>();
            agent.Target = target;
            agent.TaskName = task;
            agent.Seed = (evaluation ? evaluationSeed : 742) + index;
            agent.RandomPolicy = random;
            agent.MaxStep = 0; // The agent explicitly records then interrupts after 500 actions.
            agent.EpisodeFinished += OnEpisode;
            DecisionRequester decisions = ball.AddComponent<DecisionRequester>();
            decisions.DecisionPeriod = 5;
            decisions.TakeActionsBetweenDecisions = true;
            agents.Add(agent);
            ball.SetActive(true);
        }
        private void OnEpisode(RollerChaseAgent agent, bool success, float seconds, float reward)
        {
            if (!evaluation) return;
            if (agent.Completed <= evaluationEpisodes)
                records.Add(new EpisodeRecord { task = agent.TaskName, episode = agent.Completed, success = success, seconds = seconds, reward = reward });
            if (agent.Completed >= evaluationEpisodes) agent.gameObject.SetActive(false);
            if (records.Count >= 2 * evaluationEpisodes)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output)));
                File.WriteAllText(output, JsonUtility.ToJson(new EvaluationReport { policy = random ? "random" : "trained_onnx_deterministic", seed = evaluationSeed, episodes_per_task = evaluationEpisodes, episodes = records }, true));
                Debug.Log("Evaluation finished: " + output);
                Application.Quit(0);
            }
        }
        private void MakeCamera()
        {
            GameObject lightObject = new GameObject("Sun");
            Light sun = lightObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.2f;
            lightObject.transform.rotation = Quaternion.Euler(55, -30, 0);
            RenderSettings.ambientLight = new Color(.58f, .67f, .78f);
            Camera camera = new GameObject("Main Camera").AddComponent<Camera>();
            camera.tag = "MainCamera";
            camera.backgroundColor = new Color(.045f, .075f, .12f);
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.orthographic = true;
            camera.orthographicSize = 7.2f;
            MoveCamera();
        }
        private void MoveCamera()
        {
            Camera camera = Camera.main;
            if (camera == null) return;
            Vector3 origin = selectedTask == 1 ? new Vector3(70, 0, 0) : Vector3.zero;
            camera.transform.position = origin + new Vector3(0, 11, -8.5f);
            camera.transform.LookAt(origin);
        }
        private void SelectTask(int task)
        {
            selectedTask = task;
            foreach (var agent in agents) agent.transform.parent.gameObject.SetActive(agent.TaskName == (task == 0 ? "ReachTarget" : "ChaseTarget"));
            MoveCamera();
        }
        private void Update()
        {
            if (training || evaluation) return;
            RollerChaseAgent current = agents[selectedTask];
            if (current.Target.Manual) current.Target.ManualDirection(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")));
            if (!string.IsNullOrEmpty(capture) && Time.realtimeSinceStartup > nextCapture && captureCount < 3)
            {
                StartCoroutine(Capture());
                captureCount++;
                nextCapture += 3f;
            }
            if (quitAfter > 0 && Time.realtimeSinceStartup > quitAfter) Application.Quit(0);
        }
        private IEnumerator Capture()
        {
            yield return new WaitForEndOfFrame();
            string file = Path.Combine(capture, (cameraCapture ? "runtime-camera-" : "signal-chase-") + captureCount + ".png");
            if (!cameraCapture)
            {
                ScreenCapture.CaptureScreenshot(file);
                Debug.Log("Screenshot: " + file);
                yield break;
            }
            // A hidden Windows player's backbuffer can be black. Render the actual
            // runtime camera to a texture instead. This deliberately excludes IMGUI.
            Camera camera = Camera.main;
            RenderTexture previousTarget = camera.targetTexture;
            RenderTexture previousActive = RenderTexture.active;
            RenderTexture target = RenderTexture.GetTemporary(Screen.width, Screen.height, 24);
            Texture2D pixels = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
            try
            {
                camera.targetTexture = target;
                camera.Render();
                RenderTexture.active = target;
                pixels.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
                pixels.Apply();
                File.WriteAllBytes(file, pixels.EncodeToPNG());
                Debug.Log("Runtime camera capture (no UI): " + file);
            }
            finally
            {
                camera.targetTexture = previousTarget;
                RenderTexture.active = previousActive;
                RenderTexture.ReleaseTemporary(target);
                Destroy(pixels);
            }
        }
        private void OnGUI()
        {
            if (training || evaluation) return;
            if (heading == null)
            {
                heading = new GUIStyle(GUI.skin.label) { fontSize = 31, fontStyle = FontStyle.Bold };
                normal = new GUIStyle(GUI.skin.label) { fontSize = 18 };
                button = new GUIStyle(GUI.skin.button) { fontSize = 17 };
                solid = new Texture2D(1, 1); solid.SetPixel(0, 0, new Color(.045f, .075f, .12f, .95f)); solid.Apply();
            }
            GUI.DrawTexture(new Rect(0, 0, Screen.width, 112), solid);
            GUI.Label(new Rect(26, 15, 600, 45), "SIGNAL CHASE", heading);
            GUI.Label(new Rect(28, 62, 1000, 30), "Unity ML-Agents  /  PPO-trained neural policy  /  WANG Zhaofeng", normal);
            GUI.DrawTexture(new Rect(0, Screen.height - 153, Screen.width, 153), solid);
            int y = Screen.height - 137;
            if (GUI.Button(new Rect(26, y, 170, 38), "Static target", button)) SelectTask(0);
            if (GUI.Button(new Rect(208, y, 170, 38), "Moving target", button)) SelectTask(1);
            GUI.enabled = selectedTask == 1;
            if (GUI.Button(new Rect(390, y, 185, 38), "Control target: " + (agents[selectedTask].Target.Manual ? "ON" : "OFF"), button)) agents[selectedTask].Target.Manual = !agents[selectedTask].Target.Manual;
            GUI.enabled = true;
            if (GUI.Button(new Rect(588, y, 125, 38), "Reset", button)) agents[selectedTask].ResetRound();
            if (GUI.Button(new Rect(726, y, 125, 38), paused ? "Resume" : "Pause", button)) { paused = !paused; Time.timeScale = paused ? 0 : 1; }
            RollerChaseAgent a = agents[selectedTask];
            GUI.Label(new Rect(28, y + 48, 1100, 28), (selectedTask == 0 ? "REACH" : "CHASE") + "   Captures: " + a.Successes + " / " + a.Completed + "   |   Cyan = learned agent   Gold = target", normal);
            GUI.Label(new Rect(28, y + 81, 1100, 28), "Turn target control on, then use WASD / arrow keys. The agent follows using its trained ONNX model.", normal);
        }
    }
}
