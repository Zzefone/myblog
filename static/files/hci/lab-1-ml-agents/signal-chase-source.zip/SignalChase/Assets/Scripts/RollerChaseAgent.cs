using System;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;

namespace SignalChase
{
    public class RollerChaseAgent : Agent
    {
        public TargetController Target;
        public bool RandomPolicy;
        public bool KeyboardTarget;
        public int Seed = 742;
        public string TaskName = "ReachTarget";
        public event Action<RollerChaseAgent, bool, float, float> EpisodeFinished;
        public int Completed { get; private set; }
        public int Successes { get; private set; }
        public Rigidbody Body { get; private set; }
        private System.Random resetRandom;
        private System.Random actionRandom;
        private float previousDistance;
        private float elapsed;
        private int actionSteps;

        public override void Initialize()
        {
            Body = GetComponent<Rigidbody>();
            resetRandom = new System.Random(Seed);
            actionRandom = new System.Random(Seed + 100000);
        }

        private float Sample(float min, float max) => min + (float)resetRandom.NextDouble() * (max - min);

        public override void OnEpisodeBegin()
        {
            Body.linearVelocity = Vector3.zero;
            Body.angularVelocity = Vector3.zero;
            transform.localPosition = new Vector3(Sample(-3.6f, 3.6f), .36f, Sample(-3.6f, 3.6f));
            Vector3 goal;
            do { goal = new Vector3(Sample(-3.6f, 3.6f), .25f, Sample(-3.6f, 3.6f)); }
            while (Vector2.Distance(new Vector2(goal.x, goal.z), new Vector2(transform.localPosition.x, transform.localPosition.z)) < 1.8f);
            Target.ResetTarget(goal, new Vector2(Sample(-1, 1), Sample(-1, 1)));
            previousDistance = Distance();
            elapsed = 0;
            actionSteps = 0;
        }

        private float Distance()
        {
            Vector3 delta = Target.transform.localPosition - transform.localPosition;
            return new Vector2(delta.x, delta.z).magnitude;
        }

        public override void CollectObservations(VectorSensor sensor)
        {
            Vector3 delta = Target.transform.localPosition - transform.localPosition;
            sensor.AddObservation(delta.x / 5f);
            sensor.AddObservation(delta.z / 5f);
            sensor.AddObservation(Body.linearVelocity.x / 5f);
            sensor.AddObservation(Body.linearVelocity.z / 5f);
            sensor.AddObservation(Target.Velocity.x / 3f);
            sensor.AddObservation(Target.Velocity.z / 3f);
            sensor.AddObservation(transform.localPosition.x / 5f);
            sensor.AddObservation(transform.localPosition.z / 5f);
        }

        public override void OnActionReceived(ActionBuffers actions)
        {
            var a = actions.ContinuousActions;
            Body.AddForce(new Vector3(Mathf.Clamp(a[0], -1, 1), 0, Mathf.Clamp(a[1], -1, 1)) * 14f, ForceMode.Acceleration);
            Vector3 planar = Body.linearVelocity;
            if (new Vector2(planar.x, planar.z).magnitude > 4.5f)
            {
                Vector2 v = new Vector2(planar.x, planar.z).normalized * 4.5f;
                Body.linearVelocity = new Vector3(v.x, planar.y, v.y);
            }
            elapsed += Time.fixedDeltaTime;
            actionSteps++;
            float distance = Distance();
            AddReward((previousDistance - distance) * .08f - .001f);
            previousDistance = distance;
            if (distance < .8f)
            {
                AddReward(1f);
                Finish(true);
                EndEpisode();
            }
            else if (actionSteps >= 500)
            {
                Finish(false);
                EpisodeInterrupted();
            }
            else if (Mathf.Abs(transform.localPosition.x) > 5.1f || Mathf.Abs(transform.localPosition.z) > 5.1f || transform.localPosition.y < -.6f)
            {
                AddReward(-1f);
                Finish(false);
                EndEpisode();
            }
        }

        private void Finish(bool success)
        {
            Completed++;
            if (success) Successes++;
            if (Academy.IsInitialized && Academy.Instance.IsCommunicatorOn)
            {
                Academy.Instance.StatsRecorder.Add("Task/Success", success ? 1f : 0f);
                Academy.Instance.StatsRecorder.Add("Task/Seconds", elapsed);
            }
            EpisodeFinished?.Invoke(this, success, elapsed, GetCumulativeReward());
            elapsed = 0;
        }

        public override void Heuristic(in ActionBuffers actionsOut)
        {
            var output = actionsOut.ContinuousActions;
            if (RandomPolicy)
            {
                output[0] = (float)actionRandom.NextDouble() * 2f - 1f;
                output[1] = (float)actionRandom.NextDouble() * 2f - 1f;
            }
            else
            {
                output[0] = Input.GetAxisRaw("Horizontal");
                output[1] = Input.GetAxisRaw("Vertical");
            }
        }

        public void ResetRound() => EndEpisode();
    }
}
