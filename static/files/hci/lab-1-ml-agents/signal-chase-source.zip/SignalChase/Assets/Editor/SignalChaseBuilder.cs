using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using Unity.InferenceEngine;

namespace SignalChase
{
    public static class SignalChaseBuilder
    {
        [MenuItem("Signal Chase/Build Windows")]
        public static void BuildWindows()
        {
            Directory.CreateDirectory("Assets/Scenes");
            Directory.CreateDirectory("Assets/Models");
            Directory.CreateDirectory("Assets/Materials");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var app = new GameObject("Signal Chase").AddComponent<SignalChaseApp>();
            var material = AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/Base.mat");
            if (material == null)
            {
                material = new Material(Shader.Find("Standard"));
                AssetDatabase.CreateAsset(material, "Assets/Materials/Base.mat");
            }
            app.BaseMaterial = material;
            app.ReachModel = AssetDatabase.LoadAssetAtPath<ModelAsset>("Assets/Models/ReachTarget.onnx");
            app.ChaseModel = AssetDatabase.LoadAssetAtPath<ModelAsset>("Assets/Models/ChaseTarget.onnx");
            EditorSceneManager.SaveScene(scene, "Assets/Scenes/SignalChase.unity");
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/SignalChase.unity", true) };
            PlayerSettings.companyName = "WANG Zhaofeng";
            PlayerSettings.productName = "Signal Chase";
            PlayerSettings.defaultScreenWidth = 1200;
            PlayerSettings.defaultScreenHeight = 820;
            PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
            PlayerSettings.runInBackground = true;
            PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone, ScriptingImplementation.Mono2x);
            Directory.CreateDirectory("Builds/Windows");
            BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = new[] { "Assets/Scenes/SignalChase.unity" }, locationPathName = "Builds/Windows/SignalChase.exe", target = BuildTarget.StandaloneWindows64, options = BuildOptions.None });
            Debug.Log("SIGNAL_CHASE_BUILD " + report.summary.result + " " + report.summary.totalSize);
            if (report.summary.result != BuildResult.Succeeded) throw new Exception("Windows build failed");
        }
    }
}
