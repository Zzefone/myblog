# Experiment log

Date: 15 October 2026, Europe/Paris.

## Implementation

The class sample uses a Rigidbody ball, a goal, two continuous force actions and a PPO configuration. The baseline here keeps that task with randomized starts. The extension gives the target a velocity, includes that velocity in the observations, and adds an optional keyboard-controlled target for the standalone demonstration.

Training uses 16 arenas per behavior in one standalone Unity environment. Both networks have two hidden layers of 64 units. The initial budget is 200,000 decisions per behavior, seed 742. The experiment has not been substituted with the unrelated rule-based demonstration in `D:\UnityRLProject`.

## Problems addressed during setup

1. Unity ML-Agents 4.0.0 calls its CPU inference backend `InferenceDevice.Burst`, not `InferenceDevice.CPU`. The first compilation caught this; the enum was corrected against the installed package source.
2. The scene creates its geometry at runtime. A persistent material asset is referenced by the scene so the Standard shader remains in the standalone build.
3. Episode timeouts are recorded inside the agent, immediately before `EpisodeInterrupted()`. This avoids reading a cumulative reward after ML-Agents has reset it. All 500-action timeouts count as failures in evaluation.
4. Run `signal-chase-01` completed 200,000 decisions per behavior in about 239 seconds, but the final training mean reward was only 0.100 (static) and -0.172 (moving). The frozen-rotation sphere used the default friction, which strongly resisted small force actions. The next environment uses an explicit zero-friction material on both the sphere and platform, while retaining Rigidbody damping 2.5. A fresh run is used rather than presenting the first model as a successful solution.

## Evidence policy

Only logs, native TensorBoard events, exported models, recorded standalone evaluation episodes and actual player captures are used as completed evidence. Training and evaluation numbers are reported only after those runs finish. No human usability test has been conducted for this lab.

## Completed final run

Run `signal-chase-02` finished on 15 October 2026, with 200,005 trainer steps for ReachTarget and 200,008 for ChaseTarget. The log's 200,000-step summaries report about 304 seconds elapsed, mean reward 1.223 for static reach and 1.200 for moving chase. Both final ONNX exports were copied into Assets/Models and included in the successful Windows inference build.

The completed standalone evaluation uses seed 20261015 rather than training seed 742. Each policy has 100 episodes per task, for 400 records total. Random actions captured the static target 10/100 times and the moving target 18/100 times. Deterministic inference captured both 100/100 times; mean simulated capture times were 1.0838 s and 1.1928 s. These are results from one reset/heading seed, not a guarantee for all starts, manually controlled targets or external devices.

Final SHA-256 hashes:

- ReachTarget: `816fbb31b82516c94ca90e5a530d31aa6e2db9613ead47f997a50fb7caf93813`
- ChaseTarget: `da21c288c6174ed28ca8766acaefef6fa3688a9e226c846b0fb82e5dd001a3ae`

The model graph checker passed, and ONNX Runtime produced finite CPU outputs. The source of each scene reference is checked against the matching model `.meta` GUID. Native TensorBoard data is retained for both runs. The plotted curves use run 02 reward and policy entropy, with no invented evaluation points.

## Capture follow-up, 16 October 2026

Launching the normal player with `Start-Process -WindowStyle Hidden` and `ScreenCapture.CaptureScreenshot` produced entirely black 1280 × 800 images. Those failed captures are preserved under verification/player-static and verification/player-moving, and are not used as visual evidence.

The optional `--camera-capture` path renders the current runtime camera into a RenderTexture and saves the actual pixels. It excludes the OnGUI interface and makes no claim of a manual interaction test. No physics, reward, observations, model or evaluation logic was changed for this capture path. The Windows player was rebuilt for this addition; the existing 400-episode evaluation still applies to the unchanged task logic and model identities.

The capture build succeeded (`SIGNAL_CHASE_BUILD Succeeded 95091658`). Three non-black 1280 × 800 camera renders were saved for each task under verification/runtime-static and verification/runtime-moving. The first image from each task was visually inspected: the platform, cyan agent and gold target are visible. Both capture runs exited normally. `scripts/capture-player.ps1` preserves the actual launch arguments, including hidden windows and explicit D: log/output paths.
