# Verification record

Completed 2026-10-16 (Europe/Paris).

## Environment

Unity 6000.0.23f1, Windows x64, Mono development build, Built-in Render Pipeline,
TextMeshPro/UGUI 2.0.0. No LLMUnity package or local model was downloaded.
Python standard library relay; upstream model deepseek-flash, thinking disabled,
max_tokens 256. API credentials were provided through a hidden terminal prompt
and retained only in relay memory. No key is included in these records.

## Passed checks

- Python unit tests: 9, covering request validation, model settings, rejected
  browser origins, concurrency, mock stream framing, analysis exclusion, ratings
  joins and duplicate detection. Command: python -m unittest discover -s Proxy -p 'test_*.py' -v
- C# stream tests: 10 checks, run by LabBuild.Tests before building. Packet sizes
  1/2/3/7/4096 bytes, split UTF-8, ignored role/reasoning events, malformed JSON,
  early EOF, empty output, content filter and multiline SSE.
- Windows build: LAB_BUILD_SUCCEEDED; see local build.log.
- Runtime mock checks: input lock, condition A, condition B, indicator, long-chat
  auto-scroll, complete-turn history, and failure recovery. See mock-release/.
  Synthetic ratings from this run are for file-output verification only.
- Runtime API check: 6/6 real requests succeeded from Unity, 3 per condition.
  Each trial reset the conversation; A ran before B. See live-final/.
- The study analyzer correctly excludes all six AUTO rows and returns zero
  paired participants. No human ratings were generated in live verification.

## Real API timings

| Condition | Successful requests | Median first text | Median total | First-text range |
| --- | ---: | ---: | ---: | ---: |
| A: no waiting text | 3 | 1.480 s | 2.038 s | 1.131-1.720 s |
| B: typing indicator | 3 | 1.666 s | 2.185 s | 1.196-3.649 s |

These are engineering checks, not participant results. Sequential blocks and
small request counts cannot establish an indicator effect. Time to first text
includes local client/relay processing, network, provider queueing and generation.

## Visual verification

Inspected live-condition-a.png and live-condition-b.png from the running player.
The images are rendered by the application's actual Unity camera and Canvas at
1280x900 while the test window is hidden. They are runtime renders, not a
desktop capture or mockup. Mock images are labelled MOCK and kept separately.
Fixed the slider handle dimensions and immediate enabled/disabled colours
before this final run. Text wraps inside the scrolling viewport.

## Remaining human work

No participants have been recruited and no satisfaction or perceived-wait
results exist. Follow STUDY.md for a suggested five-person paired comparison.
The source deck requires two chosen exercises and a presentation next session;
it does not give a calendar date, report length or upload format. The instructor
should confirm acceptance of the API/Built-in variation of the local/URP lab.

## Records

technical-verification.json records the script-assembly SHA-256 and exact checks.
Earlier runs remain locally for debugging; final published measurements come
only from live-final/. Raw human data, if collected later, belongs in private/.
