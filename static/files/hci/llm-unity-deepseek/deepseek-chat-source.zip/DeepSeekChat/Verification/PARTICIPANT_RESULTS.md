# Participant feedback follow-up

Reviewed 2026-10-16 (Europe/Paris), after the initial technical verification.

The user reported participant use and confirmed that multiple participants
shared P01. The available logs contain three completed real DeepSeek turns and
three ratings, matched one-to-one by session + turn. All are condition B.
Exact participant count and person-to-turn mapping are unknown.

| Turn | First text (s) | Total (s) | Perceived first-text wait (s) | Satisfaction (1-7) |
| --- | ---: | ---: | ---: | ---: |
| 1 | 1.026030 | 1.311445 | 4 | 7 |
| 2 | 0.862408 | 1.075010 | 10 | 6 |
| 3 | 0.935810 | 1.287045 | 5 | 1 |

Turn-level medians: first text 0.935810 s, total 1.287045 s, perceived first-text
wait 5 s, satisfaction 6/7. No records were excluded. There are no missing ratings,
duplicate keys, mock responses, failed requests or truncated responses in this
three-turn snapshot. All rating values are within the application's stated ranges.

The three ratings are observations, not three independent participants. P01
cannot be used to group these observations by person because the code was shared.
No inference about an indicator effect, population preference or a per-person
change is supported. The earlier six AUTO turns are technical checks only and
must not be pooled with these ratings or used as a human control condition.

The reported first-text waits exceed measured first-text latency in all three
turns. The third satisfaction rating is 1/7 despite subsecond first-text latency.
No qualitative explanations were recorded, so possible explanations remain
questions for follow-up, not established findings.

The paired five-classmate protocol in STUDY.md was proposed before this pilot.
The logs do not establish its sample size, task prompts, resets or counterbalancing.
For a later comparison, assign a unique code per person, obtain both A and B,
alternate their order, and record a short explanation alongside each score.

Raw snapshots and the user's participant-code clarification are kept in
private/participant-2026-10-16/ and excluded from downloads. The public
participant-summary.json omits session IDs, turn IDs and UTC timestamps.
The original technical-verification.json describes only the original automated
run; it is not overwritten to mix automated and participant records.
