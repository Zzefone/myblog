# Two HCI exercises: latency and typing feedback

Source: LLM_Talking_Character_HCI_Lab.pptx, slide 24 and its speaker notes.
The notes ask each group to select two exercises and present changes,
measurement methods and user comments in the next session. No calendar
deadline, report length or upload format is specified.

This implementation replaces LLMUnity/local inference with a DeepSeek API
relay at the user's request. Ask the instructor whether this variation is
acceptable. Internet access and API credit are needed. No local model is used.

## Conditions

- A: streaming chat with no waiting text.
- B: the same chat, with "AI is typing..." from Send until the first visible
  answer content. After that the text streams in the same way in both conditions.

Both conditions lock the input, use the same model, prompt and maximum output
length, and require saving ratings before the next turn. Condition selection,
participant ID and reset are locked during a request and its rating stage.
No artificial delay is added in live mode. Mock mode is only for software checks.

## Suggested small study (not a teacher-specified sample size)

Recruit five consenting classmates; identify them as P01-P05, not by name.
Tell them their messages will be sent to DeepSeek and avoid personal content.
Use one unscored practice turn, then reset. P01/P03/P05 use A then B;
P02/P04 use B then A. This approximately counterbalances order with five people.
Within each condition use the same three prompts, resetting before each prompt:

1. Explain one benefit of an Undo button in two sentences.
2. Give one way to make a small chat window easier to read.
3. Why can a progress indicator make waiting feel easier?

After each answer, the participant rates how long it felt until the first text
(0-30 seconds, with 30 meaning 30 or more) and satisfaction with the wait
(1 = very dissatisfied, 7 = very satisfied), then clicks Save ratings & continue.
Ask after both blocks: "When did you know the system was working?" and
"Which version would you prefer, and why?" Record anonymous comments locally.
Do not claim participant results until these sessions actually take place.

## Measures and interpretation

- TTFT = first non-empty visible answer content time minus send time.
  This is a client-visible content chunk measurement, not a tokenizer-level
  measurement or isolated server inference time. Role/reasoning/keepalive events
  do not count. Time.realtimeSinceStartupAsDouble is unaffected by timeScale.
- Total = stream/network completion time minus send time.
- Perceived first-text wait = participant's estimate, collected after the answer.
- Satisfaction = ordinal 1-7 self-report. Use per-participant medians and show
  paired A/B values, rather than treating turns as independent participants.
- Perceived wait / measured TTFT can be explored, but do not treat capped 30+
  responses as exact 30-second values. Report them separately.

Network, provider load, cache and answer length all affect latency. Use the
same network, machine and model. Keep UTC timestamps and condition order.
Do not equate token streaming with reduced measured latency or infer a causal
effect from a few informal sessions. Exclude errors and mock rows from live
analysis and report their counts. Truncated responses are flagged separately.

## Evidence and next-session presentation

The app writes turns.csv and ratings.csv under its persistent StudyLogs folder
(or HCI_OUTPUT_DIR). They join on session + turn, without prompt/reply text.
Save real screenshots as Verification/live-condition-a.png and
Verification/live-condition-b.png, showing the condition and timing readout.
Keep raw participant CSVs/comments in Verification/private/; do not publish
them by default. Run Proxy/analyze.py on a copy to produce aggregate summaries.

Present the architecture change, A/B screens, actual timings, paired ratings,
anonymous comments and limitations. The initial automated mock run is software
verification only and cannot answer either human-subject research question.
