@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Proxy\start-relay.ps1"
pause
