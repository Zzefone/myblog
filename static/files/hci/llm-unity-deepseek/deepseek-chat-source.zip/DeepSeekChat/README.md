# DeepSeek Interaction Lab

A Unity 6 streaming chat application for the HCI talking-character lab.
No LLMUnity package or local model is required. This is an API-based adaptation
of the supplied slide deck, not a reproduction of its offline-inference setup.
The UI-only project uses the Built-in Render Pipeline and TextMeshPro.

## Start on this machine

For the Windows build, double-click `Run-Lab.cmd`. It reuses a running real relay,
or opens a terminal for hidden key entry, then opens the chat application.

Manual steps (also useful when running from the Unity Editor):

1. Double-click `Start-DeepSeek.cmd`. Paste a DeepSeek API key at the hidden
   terminal prompt and press Enter. Keep the relay terminal open.
2. Run `Builds/Windows/DeepSeekChat.exe`, or open the project in Unity
   **6000.0.23f1**, open `Assets/Scenes/DeepSeekChat.unity`, and press Play.
3. Enter an anonymous participant code, choose condition A/B, and send a message.
   Save ratings after a successful turn to unlock the next turn. Use New
   conversation between independent trials.

The key is used only by the Python relay in memory. It is never sent to Unity,
saved in a scene, written to the CSVs, or included in the source download.
Restarting the relay requires entering it again. This is a desktop/Editor lab
client, not a public multiuser service or WebGL deployment.

`Start-DeepSeek.cmd` uses Python 3 from the existing Codex runtime, the existing
course environment, or PATH. No external Python packages are needed. On another
machine with Python available, `python Proxy/server.py` is sufficient.

Default model: `deepseek-flash`, following the official API documentation checked
on 2026-10-15. To override it, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Proxy\start-relay.ps1 -Model deepseek-flash
```

API keys require valid DeepSeek credit. The relay uses
`https://api.deepseek.com/chat/completions`, streams SSE, disables thinking mode,
fixes a short conversational system prompt and caps output at 256 tokens.
Chat history is limited to the latest 10 complete turns. Do not send sensitive
personal content: the provider receives the conversation history with each turn.

## Software checks

```powershell
python -m unittest discover -s Proxy -p 'test_*.py' -v
python Proxy/server.py --mock --port 8766
```

The mock relay produces visibly labelled scripted text, never DeepSeek answers.
Unity's build helper runs packet-boundary, UTF-8, malformed/truncated stream and
completion checks before building. `Verification/REPORT.md` records actual runs.

Rebuild with the matching editor (adjust the executable path on another machine):

```powershell
& 'D:\unity\6000.0.23f1\Editor\Unity.exe' -batchmode -nographics -quit -projectPath $PWD.Path -executeMethod LabBuild.Build -logFile "$PWD\Verification\build.log"
```

The committed scene instantiates the UI through `ChatBootstrap`. If recreating
the scene from scripts only, run `LabBuild.Prepare` once before `LabBuild.Build`.
The source archive includes TMP Essential Resources and their licence files.

## Experiment data

The normal application writes `turns.csv` and `ratings.csv` under
`%USERPROFILE%\AppData\LocalLow\HCI Lab\DeepSeek Interaction Lab\StudyLogs`.
Join them by `session` and `turn`. Prompts, replies and keys are not logged.
Failed turns are recorded with a blank TTFT if no answer content arrived.
A truncated answer is flagged and excluded from the analysis by default.
Ratings use perceived first-text wait (0-30 seconds, with 30 meaning 30+) and
satisfaction with waiting (1-7). Raw participant data stays local.

```powershell
python Proxy/analyze.py '<StudyLogs-folder>' --output '<private-summary.json>'
```

See `STUDY.md` for the proposed paired study and presentation plan. Technical
latency checks are real API requests but are not human-subject study results.
The analyzer excludes AUTO/SMOKE IDs and mock/error/truncated rows.

For reproducible automated player checks, set process-scoped environment
variables before starting the executable:

- `HCI_SMOKE=1`, `HCI_RELAY_PORT=8766`, `HCI_OUTPUT_DIR=<new-folder>`: two mock
  conditions, synthetic ratings and an intentional connection failure.
- `HCI_VERIFY_LIVE=1`, `HCI_OUTPUT_DIR=<new-folder>`: six real API requests,
  independent histories, three fixed prompts per condition, screenshots and no
  human ratings. Requires the real relay on port 8765. Consumes API credit.

These flags are absent in normal interactive use. Never use mock timings or
synthetic smoke ratings as study evidence. Use separate output folders per run.

## References

- Course slide deck: `../LLM_Talking_Character_HCI_Lab.pptx`, slides 18-24 and notes.
- [DeepSeek API overview](https://api-docs.deepseek.com/)
- [Chat Completions and streaming response format](https://api-docs.deepseek.com/api/create-chat-completion/)
