import csv
import tempfile
import unittest
from pathlib import Path
from analyze import summarize


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        root = Path(__file__).resolve().parents[1] / "Verification"
        root.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=root)
        self.directory = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, rows):
        with (self.directory / name).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    def turn(self, id="t1", participant="P01", condition="A_indicator_off", mode="deepseek", status="ok"):
        return dict(session="fixture", turn=id, participant=participant, condition=condition,
                    mode=mode, status=status, ttft_ms="500", total_ms="1000")

    def test_exclude_synthetic_and_failed_data(self):
        self.write("turns.csv", [self.turn(participant="AUTO"), self.turn("t2", mode="mock"),
                                 self.turn("t3", status="error"), self.turn("t4", status="truncated")])
        result = summarize(self.directory)
        self.assertEqual(result["conditions"], {})
        self.assertEqual(result["paired_participants"], 0)
        self.assertEqual(sum(result["excluded"].values()), 4)

    def test_join_ratings_and_count_people(self):
        self.write("turns.csv", [self.turn(), self.turn("t2", condition="B_indicator_on")])
        base = dict(utc="fixture", session="fixture", turn="t1", participant="P01", condition="A_indicator_off",
                    mode="deepseek", perceived_wait_seconds="30", satisfaction_1_to_7="3")
        other = dict(base, turn="t2", condition="B_indicator_on", perceived_wait_seconds="1", satisfaction_1_to_7="6")
        self.write("ratings.csv", [base, other])
        result = summarize(self.directory)
        self.assertEqual(result["paired_participants"], 1)
        self.assertEqual(result["conditions"]["A_indicator_off"]["capped_wait_ratings"], 1)
        self.assertEqual(result["participant_condition_medians"]["P01"]["B_indicator_on"]["median_satisfaction"], 6)

    def test_duplicate_turns_fail(self):
        self.write("turns.csv", [self.turn(), self.turn()])
        with self.assertRaises(ValueError):
            summarize(self.directory)


if __name__ == "__main__":
    unittest.main(verbosity=2)
