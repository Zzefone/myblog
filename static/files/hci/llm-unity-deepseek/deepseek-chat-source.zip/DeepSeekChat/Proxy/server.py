"""Loopback-only DeepSeek relay. Python standard library; no model downloads."""
import argparse
import getpass
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ENDPOINT = "https://api.deepseek.com/chat/completions"
SYSTEM_PROMPT = ("You are an AI conversational agent. Respond naturally and briefly "
                 "(1-3 sentences), as if having a real-time spoken conversation with "
                 "a user testing your interface. Use plain English. Do not use emojis.")
MAX_BODY = 65536


def upstream_body(messages, model):
    if not isinstance(messages, list) or not 1 <= len(messages) <= 21:
        raise ValueError("Use 1-21 conversation messages.")
    for index, message in enumerate(messages):
        expected = "user" if index % 2 == 0 else "assistant"
        if (not isinstance(message, dict) or message.get("role") != expected
                or not isinstance(message.get("content"), str)
                or not 1 <= len(message["content"]) <= 4000):
            raise ValueError("Expected alternating user/assistant text, up to 4000 characters each.")
    if messages[-1]["role"] != "user":
        raise ValueError("The last message must be from the user.")
    return {"model": model, "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + messages,
            "stream": True, "max_tokens": 256, "thinking": {"type": "disabled"}}


class RelayServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, port, key="", model="deepseek-flash", mock=False):
        super().__init__(("127.0.0.1", port), RelayHandler)
        self.key, self.model, self.mock = key, model, mock
        self.slot = threading.BoundedSemaphore(1)


class RelayHandler(BaseHTTPRequestHandler):
    # Deliberately no access log, prompts, Authorization headers, or raw upstream errors.
    def log_message(self, *args):
        pass

    def reply(self, status, message):
        payload = json.dumps({"error": message}).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        if self.path != "/health":
            self.reply(404, "Not found")
            return
        payload = json.dumps({"mode": "mock" if self.server.mock else "deepseek",
                              "model": self.server.model}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        # No CORS support. Reject browser origins and cross-site form requests.
        if self.path != "/chat":
            self.reply(404, "Not found")
            return
        if self.headers.get("Origin") or self.headers.get("Content-Type", "").split(";")[0] != "application/json":
            self.reply(403, "Use the local Unity client.")
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 1 <= size <= MAX_BODY:
                raise ValueError("Invalid request size.")
            body = upstream_body(json.loads(self.rfile.read(size)).get("messages"), self.server.model)
        except (ValueError, TypeError, AttributeError):
            self.reply(400, "Invalid conversation payload.")
            return
        if not self.server.slot.acquire(blocking=False):
            self.reply(429, "Another reply is in progress.")
            return
        try:
            if self.server.mock:
                self.mock_stream(body)
                return
            request = urllib.request.Request(ENDPOINT, data=json.dumps(body).encode(), headers={
                "Authorization": "Bearer " + self.server.key, "Content-Type": "application/json"})
            # Do not forward credentials to any redirect target.
            class NoRedirect(urllib.request.HTTPRedirectHandler):
                def redirect_request(self, req, fp, code, msg, headers, newurl):
                    return None
            opener = urllib.request.build_opener(NoRedirect)
            try:
                upstream = opener.open(request, timeout=90)
            except urllib.error.HTTPError as error:
                status = error.code if error.code in (400, 401, 402, 403, 429) else 502
                error.close()
                self.reply(status, "DeepSeek rejected the request; check key, balance, model or quota.")
                return
            except (urllib.error.URLError, TimeoutError, OSError):
                self.reply(502, "Cannot reach DeepSeek. Check network and retry.")
                return
            with upstream:
                if "text/event-stream" not in upstream.headers.get("Content-Type", ""):
                    self.reply(502, "Unexpected response format from DeepSeek.")
                    return
                self.begin_stream("deepseek")
                # readline forwards each SSE line as soon as available, without buffering a whole reply.
                for line in upstream:
                    self.wfile.write(line)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
            # A disconnected or truncated stream is reported by the Unity client, never as success.
            self.close_connection = True
        finally:
            self.server.slot.release()

    def begin_stream(self, mode):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Lab-Mode", mode)
        self.send_header("X-Lab-Model", self.server.model)
        self.end_headers()

    def mock_stream(self, body):
        self.begin_stream("mock")
        time.sleep(0.3)
        text = "[MOCK] This is a scripted reply for interface testing. No DeepSeek request was made."
        for word in text.split(" "):
            payload = json.dumps({"choices": [{"delta": {"content": word + " "}, "finish_reason": None}]})
            self.wfile.write(("data: " + payload + "\n\n").encode())
            self.wfile.flush()
            time.sleep(0.025)
        self.wfile.write(b'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n')
        self.wfile.flush()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--model", default="deepseek-flash")
    parser.add_argument("--mock", action="store_true", help="Scripted offline stream, explicitly labelled MOCK")
    parser.add_argument("--key-stdin", action="store_true", help="Read a key from private process stdin, without a terminal prompt")
    args = parser.parse_args()
    key = "" if args.mock else (sys.stdin.readline().strip() if args.key_stdin else
          os.environ.get("DEEPSEEK_API_KEY", "") or getpass.getpass("DeepSeek API key (hidden, memory only): "))
    if not args.mock and (not key.strip() or "\n" in key or "\r" in key):
        parser.error("A non-empty API key is required.")
    server = RelayServer(args.port, key.strip(), args.model, args.mock)
    print(f"Relay ready at http://127.0.0.1:{server.server_port} | mode={'MOCK' if args.mock else 'DeepSeek'} | model={args.model}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
