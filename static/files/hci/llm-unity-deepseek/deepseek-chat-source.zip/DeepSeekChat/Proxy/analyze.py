"""Summarize completed API-mode turns and paired anonymous ratings; no dependencies."""
import argparse
import csv
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def summarize(directory):
    with (directory / "turns.csv").open(newline="", encoding="utf-8") as stream:
        turns = list(csv.DictReader(stream))
    ratings_path = directory / "ratings.csv"
    ratings = []
    if ratings_path.exists():
        with ratings_path.open(newline="", encoding="utf-8") as stream:
            ratings = list(csv.DictReader(stream))
    # A repeated session+turn in a hand-merged file must not silently inflate sample size.
    keys = [(r["session"], r["turn"]) for r in turns]
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate turn IDs. Deduplicate the input before analysis.")
    rating_keys = [(r["session"], r["turn"]) for r in ratings]
    if len(set(rating_keys)) != len(rating_keys):
        raise ValueError("Duplicate ratings.")
    joined = {(r["session"], r["turn"]): r for r in ratings}
    groups = defaultdict(list)
    excluded = Counter()
    for row in turns:
        if row["participant"] in ("AUTO", "SMOKE"):
            excluded["automated_check"] += 1
            continue
        if row["mode"] != "deepseek" or row["status"] != "ok":
            excluded[row["mode"] + "/" + row["status"]] += 1
            continue
        float(row["ttft_ms"]); float(row["total_ms"])
        groups[row["condition"]].append(row)
    conditions = {}
    paired = defaultdict(dict)
    for condition, rows in sorted(groups.items()):
        conditions[condition] = {"turns": len(rows), "participants": len({r["participant"] for r in rows}),
            "median_ttft_ms": statistics.median(float(r["ttft_ms"]) for r in rows),
            "median_total_ms": statistics.median(float(r["total_ms"]) for r in rows)}
        by_person = defaultdict(list)
        for row in rows:
            rating = joined.get((row["session"], row["turn"]))
            if rating and all(rating[k] == row[k] for k in ("participant", "condition", "mode")):
                by_person[row["participant"]].append(rating)
        conditions[condition]["rated_turns"] = sum(map(len, by_person.values()))
        conditions[condition]["capped_wait_ratings"] = sum(float(r["perceived_wait_seconds"]) >= 30 for values in by_person.values() for r in values)
        for person, values in by_person.items():
            paired[person][condition] = {"rated_turns": len(values),
                "median_satisfaction": statistics.median(float(r["satisfaction_1_to_7"]) for r in values),
                "median_perceived_wait_seconds": statistics.median(float(r["perceived_wait_seconds"]) for r in values)}
    return {"conditions": conditions, "excluded": dict(excluded),
            "paired_participants": sum(len(v) == 2 for v in paired.values()),
            "participant_condition_medians": dict(paired),
            "note": "Descriptive only. Mock, failed and truncated turns are excluded. No causal conclusion or participant count is inferred from turns."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(summarize(args.directory), indent=2)
    if args.output:
        args.output.write_text(result + "\n", encoding="utf-8")
    print(result)
