param([switch]$Mock, [string]$Model = 'deepseek-flash')
$ErrorActionPreference = 'Stop'
$pythonCandidates = @(
    (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'),
    (Join-Path $PSScriptRoot '..\..\..\..\..\tools\mlagents-env\Scripts\python.exe')
)
$pythonExe = $pythonCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $pythonExe) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if ($pythonCommand) { $pythonExe = $pythonCommand.Source }
}
if (-not $pythonExe) { throw 'Python 3 is required. No model or third-party Python packages are needed.' }
$relayArgs = @((Join-Path $PSScriptRoot 'server.py'), '--model', $Model)
if ($Mock) { $relayArgs += '--mock' }
Write-Host 'The API key is entered privately in this terminal. It is kept only in relay memory.'
& $pythonExe @relayArgs
