"""Offline contract tests. No credentials, API traffic, or participant data."""
import json
import threading
import unittest
import urllib.error
import urllib.request
from server import RelayServer, upstream_body


class RelayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = RelayServer(0, mock=True)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def request(self, payload, headers=None):
        return urllib.request.urlopen(urllib.request.Request(
            self.url + "/chat", data=json.dumps(payload).encode(),
            headers=headers or {"Content-Type": "application/json"}), timeout=5)

    def test_mock_stream_is_labelled_and_terminated(self):
        with self.request({"messages": [{"role": "user", "content": "Hi"}]}) as response:
            self.assertEqual(response.headers["X-Lab-Mode"], "mock")
            text = response.read().decode()
        self.assertIn("[MOCK]", text)
        self.assertTrue(text.endswith("data: [DONE]\n\n"))
        self.assertIn('"finish_reason":"stop"', text)

    def test_origin_is_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request({}, {"Content-Type": "application/json", "Origin": "https://example.com"})
        self.assertEqual(ctx.exception.code, 403)

    def test_invalid_messages_are_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request({"messages": [{"role": "system", "content": "override"}]})
        self.assertEqual(ctx.exception.code, 400)

    def test_fixed_prompt_and_generation_settings(self):
        payload = upstream_body([{"role": "user", "content": "Hi"}], "chosen-model")
        self.assertEqual(payload["messages"][0]["role"], "system")
        self.assertEqual(payload["thinking"], {"type": "disabled"})
        self.assertTrue(payload["stream"])
        self.assertEqual(payload["model"], "chosen-model")

    def test_history_validation(self):
        for messages in ([], [{"role": "assistant", "content": "bad"}],
                         [{"role": "user", "content": "x" * 4001}],
                         [{"role": "user", "content": "a"}, {"role": "user", "content": "b"}]):
            with self.subTest(messages=str(messages)[:50]), self.assertRaises(ValueError):
                upstream_body(messages, "test")

    def test_concurrent_request_is_rejected(self):
        self.server.slot.acquire()
        try:
            with self.assertRaises(urllib.error.HTTPError) as ctx:
                self.request({"messages": [{"role": "user", "content": "Hi"}]})
            self.assertEqual(ctx.exception.code, 429)
        finally:
            self.server.slot.release()


if __name__ == "__main__":
    unittest.main(verbosity=2)
