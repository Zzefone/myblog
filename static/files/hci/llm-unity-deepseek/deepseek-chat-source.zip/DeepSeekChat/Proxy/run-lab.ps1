$ErrorActionPreference = 'Stop'
$projectDirectory = Split-Path -Parent $PSScriptRoot
$playerPath = Join-Path $projectDirectory 'Builds\Windows\DeepSeekChat.exe'
if (-not (Test-Path -LiteralPath $playerPath)) {
    throw 'Windows player is missing. Open the Unity scene or build the project with LabBuild.Build.'
}
function Test-RelayReady {
    try {
        $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 1
        return $health.mode -eq 'deepseek'
    } catch { return $false }
}
if (-not (Test-RelayReady)) {
    $relayScript = Join-Path $PSScriptRoot 'start-relay.ps1'
    # Visible because the user needs this terminal to enter a key privately.
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-NoExit', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $relayScript)) | Out-Null
    Write-Host 'Enter your API key in the relay terminal. Waiting for the local service...'
    $deadline = (Get-Date).AddMinutes(3)
    while (-not (Test-RelayReady)) {
        if ((Get-Date) -gt $deadline) { throw 'Relay did not start. Check the relay terminal and retry.' }
        Start-Sleep -Milliseconds 500
    }
}
# The player is the interactive application the user requested to run.
Start-Process -FilePath $playerPath -WorkingDirectory $projectDirectory
