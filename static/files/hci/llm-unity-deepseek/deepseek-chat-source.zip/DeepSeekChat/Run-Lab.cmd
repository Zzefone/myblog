@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Proxy\run-lab.ps1"
if errorlevel 1 pause
