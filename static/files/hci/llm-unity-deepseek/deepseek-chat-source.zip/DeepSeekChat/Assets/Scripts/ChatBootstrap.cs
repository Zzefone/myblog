using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class ChatBootstrap : MonoBehaviour
{
    static readonly Color Ink = new Color32(228, 235, 243, 255);
    static readonly Color Muted = new Color32(151, 171, 190, 255);
    static readonly Color Panel = new Color32(23, 35, 49, 255);
    static readonly Color Accent = new Color32(84, 216, 188, 255);
    RectTransform canvas;
    void Awake()
    {
        var cameraObject = new GameObject("Main Camera", typeof(Camera));
        var camera = cameraObject.GetComponent<Camera>(); camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color32(12, 21, 32, 255); camera.orthographic = true;
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        var root = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        root.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = root.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 900); scaler.matchWidthOrHeight = 0.5f;
        canvas = root.GetComponent<RectTransform>();
        Label("HCI  /  INTERACTION LAB", canvas, 40, 28, 900, 24, 16, Accent);
        Label("A conversation, one word at a time.", canvas, 40, 66, 1180, 52, 36, Ink);
        Label("Unity + DeepSeek API   /   Compare measured latency with the wait you feel.", canvas, 40, 121, 1180, 28, 18, Muted);
        var controller = gameObject.AddComponent<NPCController>();
        controller.participantField = Input("Participant", canvas, 40, 168, 210, 42, "Anonymous ID");
        controller.participantField.text = "P01";
        controller.conditionButton = Button("Condition", canvas, 270, 168, 620, 42, "");
        controller.conditionText = controller.conditionButton.GetComponentInChildren<TextMeshProUGUI>();
        controller.resetButton = Button("New conversation", canvas, 910, 168, 330, 42, "New conversation");

        var scroll = Box("ChatScrollView", canvas, 40, 228, 1200, 314, Panel);
        controller.scrollRect = scroll.gameObject.AddComponent<ScrollRect>();
        controller.scrollRect.horizontal = false; controller.scrollRect.vertical = true;
        var viewport = Box("Viewport", scroll, 18, 10, 1164, 294, Panel);
        viewport.gameObject.AddComponent<RectMask2D>();
        var content = new GameObject("Content", typeof(RectTransform)).GetComponent<RectTransform>();
        content.SetParent(viewport, false); content.anchorMin = new Vector2(0, 1); content.anchorMax = new Vector2(1, 1);
        content.pivot = new Vector2(0.5f, 1); content.sizeDelta = Vector2.zero;
        var layout = content.gameObject.AddComponent<VerticalLayoutGroup>();
        layout.childControlWidth = true; layout.childControlHeight = true;
        layout.childForceExpandHeight = false; layout.childForceExpandWidth = true;
        var fitter = content.gameObject.AddComponent<ContentSizeFitter>(); fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        controller.chatLogText = Label("ChatLogText", content, 0, 0, 1164, 0, 23, Ink);
        controller.chatLogText.text = "";
        controller.chatLogText.textWrappingMode = TextWrappingModes.Normal;
        controller.chatLogText.overflowMode = TextOverflowModes.Overflow;
        controller.scrollRect.viewport = viewport; controller.scrollRect.content = content;
        controller.scrollRect.scrollSensitivity = 35;

        controller.inputField = Input("InputField_UserMessage", canvas, 40, 562, 980, 58, "Type a message, then press Enter...");
        controller.inputField.characterLimit = 4000;
        controller.sendButton = Button("Button_Send", canvas, 1040, 562, 200, 58, "Send", true);
        controller.statusText = Label("Status", canvas, 40, 638, 1200, 30, 18, Accent);
        controller.metricsText = Label("Metrics", canvas, 40, 674, 1200, 28, 17, Muted);
        var waitLabel = Label("WaitLabel", canvas, 40, 722, 570, 26, 18, Ink);
        var satisfactionLabel = Label("SatisfactionLabel", canvas, 670, 722, 570, 26, 18, Ink);
        controller.waitRating = Slider("PerceivedWait", canvas, 40, 764, 550, 24, 0, 30, 5);
        controller.waitRating.wholeNumbers = true;
        controller.satisfactionRating = Slider("Satisfaction", canvas, 670, 764, 550, 24, 1, 7, 4);
        controller.satisfactionRating.wholeNumbers = true;
        controller.waitRating.onValueChanged.AddListener(v => waitLabel.text = "How long did the first text feel?  " + v.ToString("F0") + " s (30 = 30+)");
        controller.satisfactionRating.onValueChanged.AddListener(v => satisfactionLabel.text = "Satisfaction with the wait  " + v.ToString("F0") + " / 7");
        waitLabel.text = "How long did the first text feel?  5 s (30 = 30+)";
        satisfactionLabel.text = "Satisfaction with the wait  4 / 7";
        controller.ratingButton = Button("SaveRatings", canvas, 910, 810, 330, 44, "Save ratings & continue", true);
        Label("Privacy", canvas, 40, 815, 830, 50, 15, Muted).text =
            "Messages go to DeepSeek in API mode. CSV logs contain timings and anonymous IDs, not chat text.\nScripted test replies are marked MOCK. No model is downloaded.";
    }
    static RectTransform Rect(string name, Transform parent, float x, float y, float width, float height)
    {
        var rect = new GameObject(name, typeof(RectTransform)).GetComponent<RectTransform>();
        rect.SetParent(parent, false); rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
        rect.pivot = new Vector2(0, 1); rect.anchoredPosition = new Vector2(x, -y); rect.sizeDelta = new Vector2(width, height);
        return rect;
    }
    static RectTransform Box(string name, Transform parent, float x, float y, float w, float h, Color color)
    { var rect = Rect(name, parent, x, y, w, h); rect.gameObject.AddComponent<Image>().color = color; return rect; }
    static TextMeshProUGUI Label(string name, Transform parent, float x, float y, float w, float h, int size, Color color)
    {
        var rect = Rect(name, parent, x, y, w, h); var text = rect.gameObject.AddComponent<TextMeshProUGUI>();
        text.font = TMP_Settings.defaultFontAsset; text.fontSize = size; text.color = color; text.text = name;
        text.raycastTarget = false; text.textWrappingMode = TextWrappingModes.Normal;
        return text;
    }
    static Button Button(string name, Transform parent, float x, float y, float w, float h, string caption, bool accent = false)
    {
        var rect = Box(name, parent, x, y, w, h, accent ? Accent : Panel);
        var button = rect.gameObject.AddComponent<Button>(); button.targetGraphic = rect.GetComponent<Image>();
        var label = Label("Label", rect, 8, 0, w - 16, h, 18, accent ? new Color32(10, 29, 32, 255) : Ink);
        label.text = caption; label.alignment = TextAlignmentOptions.Center;
        var colors = button.colors; colors.disabledColor = new Color(.4f, .4f, .4f, .6f); colors.fadeDuration = 0; button.colors = colors;
        return button;
    }
    static TMP_InputField Input(string name, Transform parent, float x, float y, float w, float h, string placeholder)
    {
        var rect = Box(name, parent, x, y, w, h, Panel);
        var input = rect.gameObject.AddComponent<TMP_InputField>();
        var area = Rect("Text Area", rect, 14, 4, w - 28, h - 8); area.gameObject.AddComponent<RectMask2D>();
        var text = Label("Text", area, 0, 0, w - 28, h - 8, 20, Ink); text.text = "";
        text.alignment = TextAlignmentOptions.MidlineLeft; text.richText = false;
        var hint = Label("Placeholder", area, 0, 0, w - 28, h - 8, 19, Muted);
        hint.text = placeholder; hint.alignment = TextAlignmentOptions.MidlineLeft;
        input.textViewport = area; input.textComponent = text; input.placeholder = hint;
        input.lineType = TMP_InputField.LineType.SingleLine; input.customCaretColor = true; input.caretColor = Accent;
        return input;
    }
    static Slider Slider(string name, Transform parent, float x, float y, float w, float h, float min, float max, float value)
    {
        var rect = Rect(name, parent, x, y, w, h);
        Box("Track", rect, 0, h / 2 - 2, w, 4, Panel);
        var area = Rect("Handle Area", rect, 10, 0, w - 20, h);
        var handle = Box("Handle", area, 0, 0, 20, h, Accent);
        handle.pivot = new Vector2(0.5f, 0.5f); handle.sizeDelta = new Vector2(20, 0);
        var slider = rect.gameObject.AddComponent<Slider>(); slider.handleRect = handle;
        slider.targetGraphic = handle.GetComponent<Image>(); slider.minValue = min; slider.maxValue = max; slider.value = value;
        var colors = slider.colors; colors.fadeDuration = 0; slider.colors = colors;
        return slider;
    }
}
