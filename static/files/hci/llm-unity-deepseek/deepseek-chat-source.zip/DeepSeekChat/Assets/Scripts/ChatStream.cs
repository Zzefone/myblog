using System;
using System.Collections.Concurrent;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

[Serializable] public class ChatMessage
{
    public string role, content;
    public ChatMessage(string role, string content) { this.role = role; this.content = content; }
}
[Serializable] public class ChatPayload { public ChatMessage[] messages; }
[Serializable] public class StreamDelta { public string content, reasoning_content; }
[Serializable] public class StreamChoice { public StreamDelta delta; public string finish_reason; }
[Serializable] public class StreamChunk { public StreamChoice[] choices; }

// SSE framing is independent of HTTP packet boundaries and UTF-8 character boundaries.
public sealed class SseDecoder
{
    readonly Decoder utf8 = Encoding.UTF8.GetDecoder();
    readonly StringBuilder line = new StringBuilder(), data = new StringBuilder();
    public readonly ConcurrentQueue<string> Events = new ConcurrentQueue<string>();
    bool previousCR;
    public void Feed(byte[] bytes, int length, bool final = false)
    {
        var chars = new char[Encoding.UTF8.GetMaxCharCount(length)];
        int count = utf8.GetChars(bytes, 0, length, chars, 0, final);
        for (int i = 0; i < count; i++)
        {
            char ch = chars[i];
            if (ch == '\n' && previousCR) { previousCR = false; continue; }
            previousCR = ch == '\r';
            if (ch == '\r' || ch == '\n') FlushLine(); else line.Append(ch);
            if (line.Length + data.Length > 1048576) throw new InvalidOperationException("SSE event too large");
        }
        // An incomplete final event is intentionally discarded: it is a broken stream.
    }
    void FlushLine()
    {
        string value = line.ToString(); line.Clear();
        if (value.Length == 0)
        {
            if (data.Length > 0) { Events.Enqueue(data.ToString()); data.Clear(); }
        }
        else if (value.StartsWith("data:", StringComparison.Ordinal))
        {
            if (data.Length > 0) data.Append('\n');
            string fragment = value.Substring(5);
            data.Append(fragment.StartsWith(" ") ? fragment.Substring(1) : fragment);
        }
        if (line.Length + data.Length > 1048576) throw new InvalidOperationException("SSE event too large");
    }
}

public sealed class StreamDownload : DownloadHandlerScript
{
    public readonly SseDecoder Decoder = new SseDecoder();
    public string ParseError;
    public StreamDownload() : base(new byte[4096]) { }
    protected override bool ReceiveData(byte[] data, int length)
    {
        if (data == null) return false;
        try { Decoder.Feed(data, length); return true; }
        catch (Exception) { ParseError = "Invalid response stream."; return false; }
    }
    protected override void CompleteContent() { Decoder.Feed(Array.Empty<byte>(), 0, true); }
}

public sealed class ChatReply
{
    public readonly StringBuilder Text = new StringBuilder();
    public bool Done;
    public string FinishReason, Error;
    public bool Accept(string payload)
    {
        if (Done) return false;
        if (payload == "[DONE]") { Done = true; return false; }
        try
        {
            var chunk = JsonUtility.FromJson<StreamChunk>(payload);
            if (chunk == null || chunk.choices == null) { Error = "Invalid stream event."; return false; }
            if (chunk.choices.Length == 0) return false;
            var choice = chunk.choices[0];
            if (!string.IsNullOrEmpty(choice.finish_reason)) FinishReason = choice.finish_reason;
            // First visible content, not role events, keepalives or reasoning, defines TTFT here.
            string part = choice.delta == null ? null : choice.delta.content;
            if (string.IsNullOrEmpty(part)) return false;
            Text.Append(part); return true;
        }
        catch (Exception) { Error = "Malformed stream JSON."; return false; }
    }
    public bool Successful => Error == null && Done && Text.Length > 0 && (FinishReason == "stop" || FinishReason == "length");
}
