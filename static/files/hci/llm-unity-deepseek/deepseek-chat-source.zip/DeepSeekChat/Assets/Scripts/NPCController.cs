using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public sealed class NPCController : MonoBehaviour
{
    public TMP_InputField inputField, participantField;
    public TextMeshProUGUI chatLogText, statusText, metricsText, conditionText;
    public Button sendButton, resetButton, conditionButton, ratingButton;
    public Slider waitRating, satisfactionRating;
    public ScrollRect scrollRect;
    public bool ShowIndicator { get; private set; } = true;
    public bool Busy { get; private set; }
    public bool AwaitingRating { get; private set; }
    public bool LastSucceeded { get; private set; }
    public double LastFirstMs { get; private set; }
    public double LastTotalMs { get; private set; }
    public string LastMode { get; private set; } = "unconnected";
    public string OutputDirectory { get; private set; }
    readonly List<ChatMessage> history = new List<ChatMessage>();
    string fullLog = "", session, lastTurn, lastParticipant, lastCondition, lastModel;
    string endpoint = "http://127.0.0.1:8765/chat";
    double started, first;
    UnityWebRequest activeRequest;
    ChatReply reply;

    void Start()
    {
        if (int.TryParse(Environment.GetEnvironmentVariable("HCI_RELAY_PORT"), out int port) && port > 0 && port <= 65535)
            endpoint = "http://127.0.0.1:" + port + "/chat";
        session = Guid.NewGuid().ToString("N").Substring(0, 12);
        OutputDirectory = Environment.GetEnvironmentVariable("HCI_OUTPUT_DIR");
        if (string.IsNullOrEmpty(OutputDirectory)) OutputDirectory = Path.Combine(Application.persistentDataPath, "StudyLogs");
        Directory.CreateDirectory(OutputDirectory);
        sendButton.onClick.AddListener(Send);
        inputField.onSubmit.AddListener(_ => Send());
        resetButton.onClick.AddListener(ResetConversation);
        conditionButton.onClick.AddListener(() => SetIndicator(!ShowIndicator));
        ratingButton.onClick.AddListener(SaveRatings);
        SetIndicator(true);
        SetControls();
        statusText.text = "Start the local relay, then send a message. No local model required.";
        metricsText.text = "TTFT and total time appear after each turn. Ratings are saved separately.";
        if (Environment.GetEnvironmentVariable("HCI_SMOKE") == "1") StartCoroutine(Smoke());
        else if (Environment.GetEnvironmentVariable("HCI_VERIFY_LIVE") == "1") StartCoroutine(VerifyLive());
    }
    public void SetIndicator(bool enabled)
    {
        if (Busy || AwaitingRating) return;
        ShowIndicator = enabled;
        conditionText.text = enabled ? "Condition B  /  Typing indicator ON" : "Condition A  /  Typing indicator OFF";
    }
    public void ResetConversation()
    {
        if (Busy || AwaitingRating) return;
        history.Clear(); fullLog = ""; chatLogText.text = "";
        statusText.text = "New conversation. The next request has no previous chat history.";
    }
    public void Send()
    {
        if (Busy || AwaitingRating) return;
        string message = inputField.text.Trim();
        if (message.Length == 0) return;
        if (message.Length > 4000) { statusText.text = "Please use 4000 characters or fewer."; return; }
        string participant = participantField.text.Trim();
        if (participant.Length == 0 || participant.Length > 24 ||
            !System.Text.RegularExpressions.Regex.IsMatch(participant, "^[A-Za-z0-9_-]+$"))
        { statusText.text = "Use an anonymous participant code: letters, digits, underscore or hyphen (1-24)."; return; }
        lastParticipant = participant; lastCondition = ShowIndicator ? "B_indicator_on" : "A_indicator_off";
        lastTurn = Guid.NewGuid().ToString("N"); LastSucceeded = false;
        Busy = true; first = -1; reply = new ChatReply(); SetControls();
        inputField.text = "";
        fullLog += "<color=#8FAAFF>You</color>\n" + Escape(message) + "\n\n<color=#64DBC8>AI</color>\n";
        chatLogText.text = fullLog; ScrollToBottom();
        statusText.text = ShowIndicator ? "AI is typing..." : "";
        started = Time.realtimeSinceStartupAsDouble;
        StartCoroutine(Request(message));
    }
    IEnumerator Request(string message)
    {
        var outgoing = new List<ChatMessage>(history) { new ChatMessage("user", message) };
        var handler = new StreamDownload();
        using (var request = new UnityWebRequest(endpoint, "POST"))
        {
            activeRequest = request;
            request.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(JsonUtility.ToJson(new ChatPayload { messages = outgoing.ToArray() })));
            request.downloadHandler = handler; request.timeout = 120;
            request.SetRequestHeader("Content-Type", "application/json");
            var operation = request.SendWebRequest();
            while (!operation.isDone)
            {
                Drain(handler);
                if (reply.Error != null) request.Abort();
                yield return null;
            }
            Drain(handler);
            LastTotalMs = (Time.realtimeSinceStartupAsDouble - started) * 1000;
            LastFirstMs = first < 0 ? -1 : (first - started) * 1000;
            LastMode = request.GetResponseHeader("X-Lab-Mode") ?? "unconnected";
            lastModel = request.GetResponseHeader("X-Lab-Model") ?? "unknown";
            LastSucceeded = request.result == UnityWebRequest.Result.Success && handler.ParseError == null && reply.Successful;
            string result;
            if (LastSucceeded)
            {
                history.Add(new ChatMessage("user", message));
                history.Add(new ChatMessage("assistant", reply.Text.ToString()));
                // Keep 10 complete previous turns; no dangling user messages after failures.
                while (history.Count > 20) history.RemoveRange(0, 2);
                AwaitingRating = true;
                waitRating.value = 5; satisfactionRating.value = 4;
                result = reply.FinishReason == "length" ? "truncated" : "ok";
                statusText.text = (LastMode == "mock" ? "MOCK / scripted offline response. " : "DeepSeek / ") +
                    (result == "truncated" ? "Reply reached the token limit. " : "Reply complete. ") + "Rate this turn to continue.";
            }
            else
            {
                result = "error";
                chatLogText.text += "\n<color=#FFB3A8>[Reply interrupted or unavailable]</color>";
                statusText.text = request.responseCode > 0 && request.responseCode != 200
                    ? "Request failed (HTTP " + request.responseCode + "). Check relay, API key, balance and model; then retry."
                    : "Reply failed or stream ended early. Check the relay/network and retry.";
            }
            fullLog = chatLogText.text + "\n\n";
            metricsText.text = (LastMode == "mock" ? "MOCK  |  " : "") +
                "First visible text: " + (first < 0 ? "none" : LastFirstMs.ToString("F0") + " ms") +
                "    Total: " + LastTotalMs.ToString("F0") + " ms    /    " + result;
            try
            {
                AppendCsv("turns.csv", "utc,session,turn,participant,condition,mode,model,ttft_ms,total_ms,status,http_status,finish_reason",
                    DateTime.UtcNow.ToString("O"), session, lastTurn, lastParticipant, lastCondition, LastMode, lastModel,
                    first < 0 ? "" : Number(LastFirstMs), Number(LastTotalMs), result, request.responseCode.ToString(), reply.FinishReason ?? "");
            }
            catch (Exception) { statusText.text += " Log could not be saved; check output folder permissions."; }
            activeRequest = null;
        }
        Busy = false; SetControls(); ScrollToBottom();
        if (!AwaitingRating) inputField.ActivateInputField();
    }
    void Drain(StreamDownload handler)
    {
        while (handler.Decoder.Events.TryDequeue(out string data))
        {
            if (!reply.Accept(data)) continue;
            if (first < 0) { first = Time.realtimeSinceStartupAsDouble; statusText.text = ""; }
            chatLogText.text = fullLog + Escape(reply.Text.ToString()); ScrollToBottom();
        }
    }
    public void SaveRatings()
    {
        if (Busy || !AwaitingRating) return;
        try
        {
            AppendCsv("ratings.csv", "utc,session,turn,participant,condition,mode,perceived_wait_seconds,satisfaction_1_to_7",
                DateTime.UtcNow.ToString("O"), session, lastTurn, lastParticipant, lastCondition, LastMode,
                Number(waitRating.value), Number(satisfactionRating.value));
        }
        catch (Exception) { statusText.text = "Ratings could not be saved. Check output folder permissions, then retry."; return; }
        AwaitingRating = false; SetControls();
        statusText.text = "Ratings saved. Send another message or reset the conversation.";
        inputField.ActivateInputField();
    }
    void SetControls()
    {
        bool idle = !Busy && !AwaitingRating;
        inputField.interactable = sendButton.interactable = resetButton.interactable = conditionButton.interactable = participantField.interactable = idle;
        ratingButton.interactable = waitRating.interactable = satisfactionRating.interactable = AwaitingRating && !Busy;
    }
    void AppendCsv(string name, string header, params string[] values)
    {
        string path = Path.Combine(OutputDirectory, name);
        if (!File.Exists(path)) File.WriteAllText(path, header + "\n");
        for (int i = 0; i < values.Length; i++) values[i] = "\"" + values[i].Replace("\"", "\"\"") + "\"";
        File.AppendAllText(path, string.Join(",", values) + "\n");
    }
    static string Number(double value) => value.ToString("F3", CultureInfo.InvariantCulture);
    static string Escape(string text) => text.Replace("<", "\u2039").Replace(">", "\u203a");
    void ScrollToBottom() { Canvas.ForceUpdateCanvases(); scrollRect.verticalNormalizedPosition = 0; }
    void OnDestroy() { if (activeRequest != null) activeRequest.Abort(); }

    IEnumerator Smoke()
    {
        yield return null;
        participantField.text = "SMOKE";
        SetIndicator(false); inputField.text = "Hello, what is this interface?"; Send();
        bool locked = !inputField.interactable && !sendButton.interactable;
        while (Busy) yield return null;
        bool firstOK = LastSucceeded && AwaitingRating && LastMode == "mock" && LastFirstMs >= 0 && LastTotalMs >= LastFirstMs;
        waitRating.value = 1; satisfactionRating.value = 4; SaveRatings();
        ResetConversation(); SetIndicator(true);
        inputField.text = "Why is feedback useful in HCI?"; Send();
        bool indicatorOK = statusText.text == "AI is typing...";
        while (Busy) yield return null;
        bool secondOK = LastSucceeded && AwaitingRating && LastMode == "mock";
        yield return new WaitForEndOfFrame();
        CaptureEvidence(Path.Combine(OutputDirectory, "mock-ui.png"));
        SaveRatings();
        inputField.text = string.Join(" ", new string[80]).Replace(" ", "readable long conversation "); Send();
        while (Busy) yield return null;
        bool scrollOK = LastSucceeded && scrollRect.content.rect.height > scrollRect.viewport.rect.height && scrollRect.verticalNormalizedPosition < 0.001f;
        bool historyOK = history.Count == 4;
        SaveRatings();
        // A real connection failure must unlock the UI, log an error and add no history.
        ResetConversation(); endpoint = "http://127.0.0.1:1/chat";
        inputField.text = "Connection failure check"; Send();
        while (Busy) yield return null;
        bool failureOK = !LastSucceeded && !AwaitingRating && inputField.interactable && history.Count == 0;
        bool ok = locked && firstOK && secondOK && indicatorOK && failureOK && scrollOK && historyOK;
        File.WriteAllText(Path.Combine(OutputDirectory, "runtime-smoke.json"),
            "{\"passed\":" + ok.ToString().ToLowerInvariant() + ",\"input_lock\":" + locked.ToString().ToLowerInvariant() +
            ",\"condition_a\":" + firstOK.ToString().ToLowerInvariant() + ",\"condition_b\":" + secondOK.ToString().ToLowerInvariant() +
            ",\"indicator\":" + indicatorOK.ToString().ToLowerInvariant() + ",\"failure_recovery\":" + failureOK.ToString().ToLowerInvariant() +
            ",\"auto_scroll\":" + scrollOK.ToString().ToLowerInvariant() + ",\"history\":" + historyOK.ToString().ToLowerInvariant() +
            ",\"service\":\"scripted mock, not DeepSeek\"}");
        yield return new WaitForSeconds(1);
        Application.Quit(ok ? 0 : 1);
    }
    IEnumerator VerifyLive()
    {
        yield return null;
        participantField.text = "AUTO";
        string[] prompts = {
            "Explain one benefit of an Undo button in two sentences.",
            "Give one way to make a small chat window easier to read.",
            "Why can a progress indicator make waiting feel easier?" };
        int completed = 0;
        bool ok = true;
        foreach (bool indicator in new[] { false, true })
        {
            foreach (string prompt in prompts)
            {
                ResetConversation(); SetIndicator(indicator);
                inputField.text = prompt; Send();
                while (Busy) yield return null;
                if (!LastSucceeded || LastMode != "deepseek") { ok = false; break; }
                completed++;
                yield return new WaitForEndOfFrame();
                CaptureEvidence(Path.Combine(OutputDirectory,
                    indicator ? "live-condition-b.png" : "live-condition-a.png"));
                yield return null;
                // Automated engineering checks have no human ratings. Never call SaveRatings here.
                AwaitingRating = false; SetControls();
            }
            if (!ok) break;
        }
        File.WriteAllText(Path.Combine(OutputDirectory, "live-verification.json"),
            "{\"passed\":" + ok.ToString().ToLowerInvariant() + ",\"completed_api_turns\":" + completed +
            ",\"human_participants\":0,\"ratings_collected\":0,\"mode\":\"deepseek\"}");
        yield return new WaitForSeconds(2);
        Application.Quit(ok ? 0 : 1);
    }
    void CaptureEvidence(string path)
    {
        // Render this live UI through its real camera even when the test window is hidden.
        var canvas = chatLogText.canvas;
        var camera = FindFirstObjectByType<Camera>();
        var target = new RenderTexture(1280, 900, 24);
        var previousTarget = camera.targetTexture;
        var previousActive = RenderTexture.active;
        canvas.renderMode = RenderMode.ScreenSpaceCamera; canvas.worldCamera = camera; canvas.planeDistance = 1;
        camera.targetTexture = target; Canvas.ForceUpdateCanvases(); camera.Render();
        RenderTexture.active = target;
        var image = new Texture2D(1280, 900, TextureFormat.RGB24, false);
        image.ReadPixels(new Rect(0, 0, 1280, 900), 0, 0); image.Apply();
        File.WriteAllBytes(path, image.EncodeToPNG());
        camera.targetTexture = previousTarget; RenderTexture.active = previousActive;
        canvas.renderMode = RenderMode.ScreenSpaceOverlay; canvas.worldCamera = null;
        target.Release(); Destroy(target); Destroy(image);
    }
}
