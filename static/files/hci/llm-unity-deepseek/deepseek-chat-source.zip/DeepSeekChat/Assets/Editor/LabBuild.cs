using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class LabBuild
{
    public static void Prepare()
    {
        string essentials = Path.Combine(EditorApplication.applicationContentsPath,
            "Resources/PackageManager/BuiltInPackages/com.unity.ugui/Package Resources/TMP Essential Resources.unitypackage");
        if (!Directory.Exists("Assets/TextMesh Pro")) AssetDatabase.ImportPackage(essentials, false);
        AssetDatabase.Refresh();
        Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        new GameObject("AI Character - API Lab", typeof(ChatBootstrap));
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/DeepSeekChat.unity");
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/DeepSeekChat.unity", true) };
        PlayerSettings.companyName = "HCI Lab"; PlayerSettings.productName = "DeepSeek Interaction Lab";
        PlayerSettings.defaultScreenWidth = 1280; PlayerSettings.defaultScreenHeight = 900;
        PlayerSettings.fullScreenMode = FullScreenMode.Windowed; PlayerSettings.runInBackground = true;
        PlayerSettings.insecureHttpOption = InsecureHttpOption.DevelopmentOnly;
        PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone, ScriptingImplementation.Mono2x);
        AssetDatabase.SaveAssets();
        Debug.Log("LAB_PREPARED");
    }
    public static void Build()
    {
        Tests();
        // HTTP is used exclusively for the loopback relay. The relay uses HTTPS upstream.
        PlayerSettings.insecureHttpOption = InsecureHttpOption.AlwaysAllowed;
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
            scenes = new[] { "Assets/Scenes/DeepSeekChat.unity" },
            locationPathName = "Builds/Windows/DeepSeekChat.exe", target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.Development });
        if (report.summary.result != BuildResult.Succeeded) throw new Exception("Player build failed");
        Debug.Log("LAB_BUILD_SUCCEEDED " + report.summary.totalSize);
    }
    public static void Tests()
    {
        int checks = 0;
        Action<bool, string> check = (ok, label) => { if (!ok) throw new Exception(label); checks++; };
        string fixture = ": ping\r\ndata: {\"choices\":[{\"delta\":{\"role\":\"assistant\"}}]}\r\n\r\n" +
            "data: {\"choices\":[{\"delta\":{\"reasoning_content\":\"hidden\"}}]}\n\n" +
            "data: {\"choices\":[{\"delta\":{\"content\":\"Hello \u4e16\u754c\"}}]}\n\n" +
            "data: {\"choices\":[{\"delta\":{},\"finish_reason\":\"stop\"}]}\n\ndata: [DONE]\n\n";
        byte[] bytes = Encoding.UTF8.GetBytes(fixture);
        foreach (int chunkSize in new[] { 1, 2, 3, 7, 4096 })
        {
            var decoder = new SseDecoder(); var reply = new ChatReply(); int visible = 0;
            for (int offset = 0; offset < bytes.Length; offset += chunkSize)
            {
                int length = Math.Min(chunkSize, bytes.Length - offset); var packet = new byte[length];
                Array.Copy(bytes, offset, packet, 0, length); decoder.Feed(packet, length);
            }
            while (decoder.Events.TryDequeue(out string item)) if (reply.Accept(item)) visible++;
            check(reply.Successful && reply.Text.ToString() == "Hello \u4e16\u754c" && visible == 1, "Packet split/UTF8/reasoning test " + chunkSize);
        }
        var truncated = new ChatReply(); truncated.Accept("{\"choices\":[{\"delta\":{\"content\":\"partial\"}}]}");
        check(!truncated.Successful, "Early EOF must fail");
        var invalid = new ChatReply(); invalid.Accept("not-json"); check(invalid.Error != null, "Bad JSON must fail");
        var empty = new ChatReply(); empty.Accept("[DONE]"); check(!empty.Successful, "Empty answer must fail");
        var blocked = new ChatReply(); blocked.Accept("{\"choices\":[{\"delta\":{\"content\":\"partial\"},\"finish_reason\":\"content_filter\"}]}");
        blocked.Accept("[DONE]"); check(!blocked.Successful, "Content filter must not be recorded as success");
        var multiline = new SseDecoder(); byte[] multi = Encoding.UTF8.GetBytes("data: line1\ndata: line2\n\n");
        multiline.Feed(multi, multi.Length); check(multiline.Events.TryDequeue(out string joined) && joined == "line1\nline2", "Multiline SSE");
        Directory.CreateDirectory("Verification");
        File.WriteAllText("Verification/parser-tests.json", "{\"passed\":true,\"checks\":" + checks + ",\"uses_api\":false}");
        Debug.Log("LAB_PARSER_TESTS_PASSED " + checks);
    }
}
