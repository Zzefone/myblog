# Recorded verification — 19 October 2026

Brush v0.3.0 completed 3,000 training steps on the RTX 3060 Laptop GPU using
Vulkan. The process exited 0 in 38.944 seconds. All three PLY exports have recorded
SHA-256 hashes in training/run-01/status.json. The complete Brush log is retained.

The 100 training and ten validation images use provided synthetic poses, resized
to 400 square pixels. The source manifest records attribution, selection and
original hashes. Final monitored validation PSNR/SSIM: 30.395605 dB / 0.9542484.
Recomputing mean per-image PSNR from saved RGB PNGs gives 30.395845 dB.
Validation is not an independent final benchmark; these are Brush render scores.

Both PLY payloads were checked for finite float properties and correct size.
Filtering removes 200 of 9,020 splats (199 low opacity, 3 distant, 2 overlapping).
Unity imported exactly 9,020 / 8,820 splats using the Medium preset.

Unity 6000.0.23f1 built the Windows player successfully. The actual player exited
0 on Direct3D 12 / RTX 3060, switching raw/filtered models at three camera poses.
All six 800x800 RGB captures contain visible content. All three poses, both
models, and the debug-point capture were inspected visually. The subject and
orientation are consistent; raw/filtered differences are small.

No runtime exception was found. An editor exit warning reported two Persistent
allocations after import. It remains unresolved; this is not a memory-cleanliness
claim. The initial minimal package manifest also failed on XRSettings; including
the VR module resolved that compilation error. Full editor/player logs remain
local, with build success and runtime counts summarized in the public JSON.

No personal photography, COLMAP run, SuperSplat UI session, FPS benchmark,
VR run or mobile run is claimed. The public source archive includes the saved
scene, imported assets, both PLYs, embedded MIT viewer, preparation/training
scripts, training exports/renders and recorded evidence. Input images and the
Brush executable are fetched separately as described in README.md.
