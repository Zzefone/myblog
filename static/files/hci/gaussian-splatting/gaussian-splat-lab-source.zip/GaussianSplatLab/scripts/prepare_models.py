"""Validate the trained PLY, make a documented filtered variant, and export Unity cameras."""
from pathlib import Path
import hashlib
import json
import math
import re
import shutil
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "training/run-01/hotdog_3000.ply"
with path.open("rb") as stream:
    lines = []
    while True:
        line = stream.readline()
        if not line:
            raise ValueError("Missing PLY end_header")
        lines.append(line.decode("ascii"))
        if line.strip() == b"end_header":
            break
    offset = stream.tell()
properties = [line.split()[2] for line in lines if line.startswith("property float ")]
count = int(next(line for line in lines if line.startswith("element vertex ")).split()[-1])
assert "format binary_little_endian 1.0\n" in lines
dtype = np.dtype([(name, "<f4") for name in properties])
values = np.fromfile(path, dtype=dtype, offset=offset, count=count)
assert len(values) == count
assert path.stat().st_size == offset + count * dtype.itemsize
assert np.isfinite(np.column_stack([values[name] for name in properties])).all()
xyz = np.column_stack([values[n] for n in ("x", "y", "z")])
center = np.median(xyz, axis=0)
alpha = 1 / (1 + np.exp(-values["opacity"]))
low_alpha = alpha < 0.01
outlying = np.linalg.norm(xyz - center, axis=1) > 2.0
keep = ~(low_alpha | outlying)
assert keep.sum() > count * 0.8
output = ROOT / "models"
output.mkdir(exist_ok=True)
shutil.copy2(path, output / "hotdog_raw.ply")
header = "".join(re.sub(r"^element vertex \d+", "element vertex " + str(int(keep.sum())), line) for line in lines)
with (output / "hotdog_clean.ply").open("wb") as stream:
    stream.write(header.encode("ascii"))
    values[keep].tofile(stream)
report = {"raw_splats": count, "filtered_splats": int(keep.sum()),
          "removed_splats": int((~keep).sum()), "low_opacity_splats": int(low_alpha.sum()),
          "distant_splats": int(outlying.sum()), "overlap": int((low_alpha & outlying).sum()),
          "opacity_minimum": 0.01, "radius_maximum_scene_units": 2.0,
          "radius_center": center.tolist(),
          "note": "Chosen experiment thresholds, not a general optimum. Removal is not proof of a quality improvement.",
          "models": {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                     for p in output.glob("*.ply")}}
(ROOT / "verification/cleanup.json").write_text(json.dumps(report, indent=2) + "\n")
doc = json.loads((ROOT / "data/hotdog-400/transforms_val.json").read_text())
cameras = []
for index in (0, 4, 7):
    frame = doc["frames"][index]
    m = np.array(frame["transform_matrix"])
    reflect = np.array([1, 1, -1])
    cameras.append({"position": (m[:3, 3] * reflect).tolist(),
                    "forward": (-m[:3, 2] * reflect).tolist(),
                    "up": (m[:3, 1] * reflect).tolist(),
                    "fieldOfView": math.degrees(doc["camera_angle_x"])})
(ROOT / "verification/lab-cameras.json").write_text(json.dumps({"views": cameras}, indent=2) + "\n")
checks = []
for frame in doc["frames"]:
    relative = frame["file_path"].lstrip("./") + ".png"
    original = Image.open(ROOT / "data/hotdog-400" / relative).convert("RGBA")
    black = Image.new("RGBA", original.size, (0, 0, 0, 255))
    target = np.asarray(Image.alpha_composite(black, original).convert("RGB"), dtype=np.float64) / 255
    name = Path(relative).name
    rendered = np.asarray(Image.open(ROOT / "training/run-01/eval_3000" / name).convert("RGB"), dtype=np.float64) / 255
    assert target.shape == rendered.shape == (400, 400, 3)
    mse = float(np.mean((target - rendered) ** 2))
    checks.append({"image": name, "mse": mse, "psnr_db": -10 * math.log10(mse)})
metrics = {"held_out_images": len(checks), "independent_mean_psnr_db": float(np.mean([v["psnr_db"] for v in checks])),
           "metric": "RGB, black-alpha composite, 8-bit saved Brush render, per-image PSNR then mean", "images": checks}
(ROOT / "verification/heldout-check.json").write_text(json.dumps(metrics, indent=2) + "\n")
print(json.dumps(report, indent=2))
print("Independent held-out PSNR:", metrics["independent_mean_psnr_db"])
