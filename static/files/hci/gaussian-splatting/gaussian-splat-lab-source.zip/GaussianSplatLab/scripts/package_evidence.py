"""Check recorded evidence and package only the public lab deliverables."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
BLOG = ROOT.parents[1] / "myblog"
VERIFY = ROOT / "verification"

def read(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))

state = read("training/run-01/status.json")
runtime = read("verification/runtime/runtime.json")
imported = read("verification/unity-import.json")
cleanup = read("verification/cleanup.json")
assert state["status"] == "completed" and state["exit_code"] == 0
assert runtime["passed"] and len(runtime["captures"]) == 6
assert imported["raw_splats"] == cleanup["raw_splats"] == 9020
assert imported["cleaned_splats"] == cleanup["filtered_splats"] == 8820
assert "SPLAT_LAB_BUILD_SUCCEEDED" in (VERIFY / "unity-build-final.log").read_text(encoding="utf-8")
captures = []
for capture in runtime["captures"]:
    name = "view-{}-{}.png".format(capture["view"], "filtered" if capture["filtered"] else "raw")
    path = VERIFY / "runtime" / name
    rgb = np.array(Image.open(path).convert("RGB"))
    assert rgb.shape == (800, 800, 3)
    nonblack = float(np.mean(np.max(rgb, axis=2) > 8))
    assert 0.01 < nonblack < 0.95
    assert capture["splats"] == (8820 if capture["filtered"] else 9020)
    captures.append(dict(capture, file=name, nonblack_fraction=round(nonblack, 6),
                         sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

evaluations = []
for line in state["evaluation_log_lines"]:
    match = re.search(r"Eval iter (\d+): PSNR ([\d.]+), ssim ([\d.]+)", line)
    assert match
    evaluations.append({"step": int(match[1]), "psnr_db": float(match[2]), "ssim": float(match[3])})
summary = {
    "experiment_date": "2026-10-19", "dataset": "NeRF Synthetic Hotdog (CC0), supplied poses",
    "own_photo_capture": False, "colmap_run": False,
    "train_views": 100, "validation_views": 10, "resolution": [400, 400],
    "brush_version": "v0.3.0", "training_backend": "Vulkan", "seed": 20261019,
    "steps": 3000, "process_wall_seconds": state["elapsed_seconds"],
    "validation": evaluations,
    "independent_saved_render_check": read("verification/heldout-check.json"),
    "cleanup": cleanup, "unity_import": imported,
    "runtime": dict(runtime, captures=captures, exit_code=0),
    "visual_inspection": "Three poses, both models and debug points inspected; object visible and orientation consistent.",
    "limits": ["Public synthetic data, no personal capture or COLMAP.",
               "Validation used for monitoring; no final independent benchmark.",
               "Brush metrics are not Unity rendering metrics.",
               "Filtering is not demonstrated to improve image quality.",
               "No FPS, VR or mobile test.",
               "Editor importer reported two persistent allocations at exit; unresolved."]
}
(VERIFY / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
log_lines = (ROOT / "training/run-01/brush.log").read_text(encoding="utf-8", errors="replace").splitlines()
events = [line for line in log_lines if "Eval iter" in line or "adapter" in line.lower() or "Training done" in line]
(VERIFY / "training-events.log").write_text("\n".join(events) + "\n", encoding="utf-8")
(ROOT / "requirements.txt").write_text("numpy>=1.26,<3\nPillow>=10,<13\n", encoding="utf-8")

report = """# Recorded verification — 19 October 2026

Brush v0.3.0 completed 3,000 training steps on the RTX 3060 Laptop GPU using
Vulkan. The process exited 0 in 38.944 seconds. All three PLY exports have recorded
SHA-256 hashes in training/run-01/status.json. The complete Brush log is retained.

The 100 training and ten validation images use provided synthetic poses, resized
to 400 square pixels. The source manifest records attribution, selection and
original hashes. Final monitored validation PSNR/SSIM: 30.395605 dB / 0.9542484.
Recomputing mean per-image PSNR from saved RGB PNGs gives 30.395845 dB.
Validation is not an independent final benchmark; these are Brush render scores.

Both PLY payloads were checked for finite float properties and correct size.
Filtering removes 200 of 9,020 splats (199 low opacity, 3 distant, 2 overlapping).
Unity imported exactly 9,020 / 8,820 splats using the Medium preset.

Unity 6000.0.23f1 built the Windows player successfully. The actual player exited
0 on Direct3D 12 / RTX 3060, switching raw/filtered models at three camera poses.
All six 800x800 RGB captures contain visible content. All three poses, both
models, and the debug-point capture were inspected visually. The subject and
orientation are consistent; raw/filtered differences are small.

No runtime exception was found. An editor exit warning reported two Persistent
allocations after import. It remains unresolved; this is not a memory-cleanliness
claim. The initial minimal package manifest also failed on XRSettings; including
the VR module resolved that compilation error. Full editor/player logs remain
local, with build success and runtime counts summarized in the public JSON.

No personal photography, COLMAP run, SuperSplat UI session, FPS benchmark,
VR run or mobile run is claimed. The public source archive includes the saved
scene, imported assets, both PLYs, embedded MIT viewer, preparation/training
scripts, training exports/renders and recorded evidence. Input images and the
Brush executable are fetched separately as described in README.md.
"""
(VERIFY / "REPORT.md").write_text(report, encoding="utf-8")

images = BLOG / "static/images/hci/gaussian-splatting"
files = BLOG / "static/files/hci/gaussian-splatting"
images.mkdir(parents=True, exist_ok=True)
files.mkdir(parents=True, exist_ok=True)
for source, name in [(VERIFY / "training-progress.png", "training-progress.png"),
                     (VERIFY / "runtime/view-0-filtered.png", "unity-filtered.png"),
                     (VERIFY / "runtime/view-2-filtered.png", "unity-second-view.png"),
                     (VERIFY / "runtime/debug-points.png", "debug-points.png")]:
    shutil.copy2(source, images / name)
shutil.copy2(VERIFY / "summary.json", files / "results.json")

selected = set()
for folder in ("UnityProject/Assets", "UnityProject/Packages", "UnityProject/ProjectSettings",
               "scripts", "models", "training/run-01"):
    selected.update(p for p in (ROOT / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts)
for filename in ("README.md", "requirements.txt", ".gitignore", "upstream-version.json", "data/source-manifest.json"):
    selected.add(ROOT / filename)
for pattern in ("*.json", "*.md", "training-events.log", "training-progress.png", "runtime/*.json", "runtime/*.png"):
    selected.update(VERIFY.glob(pattern))
archive_path = files / "gaussian-splat-lab-source.zip"
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for path in sorted(selected):
        assert path.is_relative_to(ROOT) and path.is_file()
        archive.write(path, "GaussianSplatLab/" + path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert all(not any(part in {"Library", "Builds", "UserSettings", ".git", "cache"} for part in Path(name).parts)
               for name in archive.namelist())
assert archive_path.stat().st_size < 50 * 1024 * 1024
print(json.dumps({"archive_files": len(selected), "archive_bytes": archive_path.stat().st_size,
                  "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
                  "runtime_captures_checked": len(captures)}, indent=2))
