"""Fetch the CC0 Hotdog views and make the recorded 400px training/validation input."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import urllib.request
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/hotdog"
READY = ROOT / "data/hotdog-400"
MIRROR = "https://huggingface.co/datasets/pablovela5620/nerf-synthetic-mirror/resolve/main/"
RAW.mkdir(parents=True, exist_ok=True)
READY.mkdir(parents=True, exist_ok=True)
documents = {}
for split in ("train", "val"):
    with urllib.request.urlopen(MIRROR + "hotdog/transforms_" + split + ".json", timeout=30) as response:
        payload = response.read()
    (RAW / ("transforms_" + split + ".json")).write_bytes(payload)
    doc = json.loads(payload)
    if split == "val":
        doc["frames"] = doc["frames"][::10]
    documents[split] = doc
    (RAW / split).mkdir(exist_ok=True)
    (READY / split).mkdir(exist_ok=True)
jobs = [(frame["file_path"].lstrip("./") + ".png", split)
        for split, doc in documents.items() for frame in doc["frames"]]


def prepare(job):
    relative, split = job
    original = RAW / relative
    if not original.exists():
        with urllib.request.urlopen(MIRROR + "hotdog/" + relative, timeout=60) as response:
            original.write_bytes(response.read())
    with Image.open(original) as image:
        if image.size != (800, 800):
            raise ValueError("Unexpected source resolution")
        image.resize((400, 400), Image.Resampling.LANCZOS).save(READY / relative)
    return {"path": relative, "sha256": hashlib.sha256(original.read_bytes()).hexdigest()}


with ThreadPoolExecutor(max_workers=8) as pool:
    files = list(pool.map(prepare, jobs))
manifest_path = ROOT / "data/source-manifest.json"
if manifest_path.exists():
    previous = json.loads(manifest_path.read_text())
    expected = {item["path"]: item["sha256"] for item in previous["files"]}
    assert expected == {item["path"]: item["sha256"] for item in files}, "Source bytes changed; preserve the old manifest and review."
for split, doc in documents.items():
    (READY / ("transforms_" + split + ".json")).write_text(json.dumps(doc, indent=2) + "\n")
manifest = {"scene": "NeRF Synthetic Hotdog", "author": "erickfree",
            "source_model": "https://www.blendswap.com/blend/23962", "license": "CC0",
            "dataset_mirror": MIRROR + "hotdog/", "original_resolution": [800, 800],
            "prepared_resolution": [400, 400], "train_views": 100, "validation_views": 10,
            "validation_selection": "every tenth original validation frame, indices 0,10,...,90",
            "poses": "Provided synthetic camera-to-world matrices; no COLMAP estimation performed", "files": files}
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
print("Prepared 100 train and 10 held-out validation views. Source hashes verified.")
