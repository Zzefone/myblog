"""Run the recorded, bounded Brush experiment. Uses only the Python standard library."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
BRUSH = Path(os.environ.get("BRUSH_EXE", ROOT.parent / "tools/brush-v0.3.0/brush_app.exe"))
OUTPUT = ROOT / "training/run-01"
OUTPUT.mkdir(parents=True, exist_ok=True)
args = [str(BRUSH), str(ROOT / "data/hotdog-400"),
        "--total-steps", "3000", "--max-resolution", "400", "--max-splats", "100000",
        "--growth-stop-iter", "2500", "--refine-every", "100", "--sh-degree", "3",
        "--seed", "20261019", "--eval-every", "1000", "--eval-save-to-disk",
        "--export-every", "1000", "--export-path", str(OUTPUT),
        "--export-name", "hotdog_{iter}.ply"]
config = {"brush_version": "v0.3.0", "executable_sha256": hashlib.sha256(BRUSH.read_bytes()).hexdigest(),
          "command": args, "train_images": 100, "validation_images": 10,
          "image_resolution": [400, 400], "seed": 20261019,
          "steps": 3000, "max_splats": 100000, "growth_stop_iter": 2500,
          "dataset": "NeRF Synthetic Hotdog (CC0), provided poses", "colmap_run": False}
(OUTPUT / "config.json").write_text(json.dumps(config, indent=2) + "\n")
state = {"status": "running", "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUTPUT / "status.json").write_text(json.dumps(state, indent=2) + "\n")
environment = dict(os.environ, RUST_LOG="info", XDG_CACHE_HOME=str(ROOT / "cache"))
started = time.perf_counter()
print("Starting actual Brush training: 100 training images, 10 validation images, 3000 steps.", flush=True)
with (OUTPUT / "brush.log").open("wb") as log:
    result = subprocess.run(args, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
elapsed = time.perf_counter() - started
state.update(status="completed" if result.returncode == 0 else "failed", exit_code=result.returncode,
             elapsed_seconds=round(elapsed, 3), finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
text = (OUTPUT / "brush.log").read_text(encoding="utf-8", errors="replace")
state["evaluation_log_lines"] = [line for line in text.splitlines() if "Eval iter" in line]
state["exports"] = [{"filename": p.name, "bytes": p.stat().st_size,
                     "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUTPUT.glob("*.ply"))]
(OUTPUT / "status.json").write_text(json.dumps(state, indent=2) + "\n")
print(json.dumps(state, indent=2), flush=True)
if result.returncode != 0:
    print(text[-5000:], flush=True)
    raise SystemExit(result.returncode)
