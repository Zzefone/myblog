using System;
using System.IO;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

public static class SplatLabBuild
{
    const string Package = "Packages/org.nesnausk.gaussian-splatting/Shaders/";
    public static void Configure()
    {
        PlayerSettings.companyName = "HCI Lab";
        PlayerSettings.productName = "Gaussian Splat Lab";
        PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.StandaloneWindows64, false);
        PlayerSettings.SetGraphicsAPIs(BuildTarget.StandaloneWindows64, new[] { GraphicsDeviceType.Direct3D12 });
        PlayerSettings.colorSpace = ColorSpace.Linear;
        PlayerSettings.defaultScreenWidth = 1000; PlayerSettings.defaultScreenHeight = 760;
        PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
        PlayerSettings.runInBackground = true;
        QualitySettings.antiAliasing = 0;
        AssetDatabase.SaveAssets();
        Debug.Log("SPLAT_LAB_CONFIGURED");
    }
    static GaussianSplatAsset Import(string name)
    {
        var creator = ScriptableObject.CreateInstance<GaussianSplatAssetCreator>();
        var fields = new SerializedObject(creator);
        fields.FindProperty("m_InputFile").stringValue = Path.GetFullPath("../models/" + name + ".ply");
        fields.FindProperty("m_OutputFolder").stringValue = "Assets/GaussianAssets/" + name;
        fields.FindProperty("m_ImportCameras").boolValue = false;
        fields.FindProperty("m_Quality").enumValueIndex = 2; // pinned package's Medium preset
        fields.ApplyModifiedPropertiesWithoutUndo();
        var flags = BindingFlags.Instance | BindingFlags.NonPublic;
        typeof(GaussianSplatAssetCreator).GetMethod("ApplyQualityLevel", flags).Invoke(creator, null);
        try { typeof(GaussianSplatAssetCreator).GetMethod("CreateAsset", flags).Invoke(creator, null); }
        finally { EditorUtility.ClearProgressBar(); UnityEngine.Object.DestroyImmediate(creator); }
        var asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>("Assets/GaussianAssets/" + name + "/" + name + ".asset");
        if (asset == null || asset.splatCount == 0) throw new Exception("Splat import failed: " + name);
        return asset;
    }
    public static void Build()
    {
        Configure();
        GaussianSplatAsset raw = Import("hotdog_raw"), clean = Import("hotdog_clean");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var cameraObject = new GameObject("Main Camera", typeof(Camera));
        cameraObject.tag = "MainCamera";
        var camera = cameraObject.GetComponent<Camera>();
        camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = Color.black;
        camera.nearClipPlane = 0.01f; camera.farClipPlane = 100; camera.allowMSAA = false;
        camera.allowHDR = true;
        var go = new GameObject("Trained Hotdog Gaussians");
        go.SetActive(false);
        var renderer = go.AddComponent<GaussianSplatRenderer>();
        renderer.m_Asset = raw;
        renderer.m_ShaderSplats = AssetDatabase.LoadAssetAtPath<Shader>(Package + "RenderGaussianSplats.shader");
        renderer.m_ShaderComposite = AssetDatabase.LoadAssetAtPath<Shader>(Package + "GaussianComposite.shader");
        renderer.m_ShaderDebugPoints = AssetDatabase.LoadAssetAtPath<Shader>(Package + "GaussianDebugRenderPoints.shader");
        renderer.m_ShaderDebugBoxes = AssetDatabase.LoadAssetAtPath<Shader>(Package + "GaussianDebugRenderBoxes.shader");
        renderer.m_CSSplatUtilities = AssetDatabase.LoadAssetAtPath<ComputeShader>(Package + "SplatUtilities.compute");
        go.transform.localScale = new Vector3(1, 1, -1);
        var control = new GameObject("Lab controls").AddComponent<SplatLabController>();
        control.splats = renderer; control.raw = raw; control.cleaned = clean; control.viewCamera = camera;
        string cameraPath = "Assets/Resources/lab-cameras.json";
        Directory.CreateDirectory("Assets/Resources");
        File.Copy("../verification/lab-cameras.json", cameraPath, true);
        AssetDatabase.ImportAsset(cameraPath);
        control.cameras = AssetDatabase.LoadAssetAtPath<TextAsset>(cameraPath);
        go.SetActive(true);
        Directory.CreateDirectory("Assets/Scenes");
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/SplatLab.unity");
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/SplatLab.unity", true) };
        AssetDatabase.SaveAssets();
        Directory.CreateDirectory("../verification");
        File.WriteAllText("../verification/unity-import.json", "{\"raw_splats\":" + raw.splatCount +
            ",\"cleaned_splats\":" + clean.splatCount + ",\"graphics_api\":\"Direct3D12\",\"asset_quality\":\"Medium\",\"unity\":\"6000.0.23f1\"}");
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
            scenes = new[] { "Assets/Scenes/SplatLab.unity" },
            locationPathName = "Builds/Windows/GaussianSplatLab.exe",
            target = BuildTarget.StandaloneWindows64, options = BuildOptions.Development });
        if (report.summary.result != BuildResult.Succeeded) throw new Exception("Gaussian player build failed");
        Debug.Log("SPLAT_LAB_BUILD_SUCCEEDED");
    }
}
