using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using GaussianSplatting.Runtime;
using UnityEngine;

[Serializable] public class LabView { public float[] position, forward, up; public float fieldOfView; }
[Serializable] public class LabViews { public LabView[] views; }

public sealed class SplatLabController : MonoBehaviour
{
    public GaussianSplatRenderer splats;
    public GaussianSplatAsset raw, cleaned;
    public Camera viewCamera;
    public TextAsset cameras;
    LabView[] views;
    int current;
    bool clean;
    string output;

    void Start()
    {
        views = JsonUtility.FromJson<LabViews>(cameras.text).views;
        ApplyView(0);
        output = Environment.GetEnvironmentVariable("GS_LAB_OUTPUT");
        if (!string.IsNullOrEmpty(output)) StartCoroutine(Verify());
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow)) ApplyView((current + 1) % views.Length);
        if (Input.GetKeyDown(KeyCode.LeftArrow)) ApplyView((current + views.Length - 1) % views.Length);
        if (Input.GetKeyDown(KeyCode.C)) SetClean(!clean);
        if (Input.GetKeyDown(KeyCode.P)) splats.m_RenderMode = splats.m_RenderMode == GaussianSplatRenderer.RenderMode.Splats
            ? GaussianSplatRenderer.RenderMode.DebugPoints : GaussianSplatRenderer.RenderMode.Splats;
        if (Input.GetKeyDown(KeyCode.Escape)) Application.Quit();
    }
    void ApplyView(int index)
    {
        current = index; var view = views[index];
        viewCamera.transform.SetPositionAndRotation(Vector(view.position), Quaternion.LookRotation(Vector(view.forward), Vector(view.up)));
        viewCamera.fieldOfView = view.fieldOfView;
    }
    static Vector3 Vector(float[] value) => new Vector3(value[0], value[1], value[2]);
    void SetClean(bool enabled) { clean = enabled; splats.m_Asset = clean ? cleaned : raw; }
    void OnGUI()
    {
        var style = new GUIStyle(GUI.skin.label) { fontSize = 18 };
        style.normal.textColor = Color.white;
        GUI.Label(new Rect(20, 12, 950, 36), "HCI Gaussian Splat Lab  |  NeRF Synthetic Hotdog / CC0", style);
        GUI.Label(new Rect(20, 44, 950, 32), (clean ? "Filtered" : "Raw") + "  /  " + splats.splatCount +
            " Gaussians  /  camera " + (current + 1) + "  /  " + SystemInfo.graphicsDeviceType, style);
        GUI.Label(new Rect(20, Screen.height - 42, 950, 35), "Left / Right: views     C: raw / filtered     P: points / splats     Esc: exit", style);
    }
    IEnumerator Verify()
    {
        Directory.CreateDirectory(output);
        yield return new WaitForSeconds(2);
        bool valid = splats.HasValidAsset && splats.HasValidRenderSetup && SystemInfo.supportsComputeShaders;
        var records = new List<string>();
        for (int index = 0; index < Math.Min(3, views.Length); index++)
        {
            ApplyView(index);
            foreach (bool filtered in new[] { false, true })
            {
                SetClean(filtered);
                yield return null; yield return null;
                Capture(Path.Combine(output, "view-" + index + (filtered ? "-filtered.png" : "-raw.png")));
                records.Add("{\"view\":" + index + ",\"filtered\":" + filtered.ToString().ToLowerInvariant() +
                    ",\"splats\":" + splats.splatCount + "}");
            }
        }
        splats.m_RenderMode = GaussianSplatRenderer.RenderMode.DebugPoints;
        yield return null;
        Capture(Path.Combine(output, "debug-points.png"));
        File.WriteAllText(Path.Combine(output, "runtime.json"), "{\"passed\":" + valid.ToString().ToLowerInvariant() +
            ",\"gpu\":\"" + SystemInfo.graphicsDeviceName + "\",\"graphics_api\":\"" + SystemInfo.graphicsDeviceType +
            "\",\"captures\":[" + string.Join(",", records) + "]}");
        yield return new WaitForSeconds(1);
        Application.Quit(valid ? 0 : 1);
    }
    void Capture(string path)
    {
        var target = new RenderTexture(800, 800, 24, RenderTextureFormat.ARGBHalf);
        var previous = viewCamera.targetTexture; var active = RenderTexture.active;
        viewCamera.targetTexture = target; viewCamera.Render();
        RenderTexture.active = target;
        var image = new Texture2D(800, 800, TextureFormat.RGB24, false);
        image.ReadPixels(new Rect(0, 0, 800, 800), 0, 0); image.Apply();
        File.WriteAllBytes(path, image.EncodeToPNG());
        viewCamera.targetTexture = previous; RenderTexture.active = active;
        target.Release(); Destroy(target); Destroy(image);
    }
}
