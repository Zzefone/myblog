# Gaussian splatting: posed images, training, filtering and Unity

HCI lab follow-up, 19 October 2026. The input is the public **NeRF Synthetic
Hotdog** scene. The original model is by erickfree, released as CC0:
https://www.blendswap.com/blend/23962 . Image mirror:
https://huggingface.co/datasets/pablovela5620/nerf-synthetic-mirror .

This is a reconstruction experiment using published synthetic views and their
provided camera poses. No personal capture or COLMAP pose estimation was done.
The filtering script performs a stated numerical filter; no SuperSplat GUI
session is claimed. These distinctions matter when comparing workflows.

## Actual run

- Brush v0.3.0, official Windows release, publisher SHA-256 checked before use.
- 100 training views and 10 held-out validation views, resized 800 to 400 pixels.
  Validation selects original frames 0, 10, ..., 90. All training frames are used.
- 3,000 steps, SH degree 3, seed 20261019, max 100,000 splats,
  refinement every 100 steps, growth ending at step 2,500.
- NVIDIA RTX 3060 Laptop GPU, 6 GB; Brush logs Vulkan as its backend.
- 38.944 seconds wall time including startup, evaluation and exports.
  Brush reports 33 seconds for training itself.
- At 1,000/2,000/3,000 steps, held-out PSNR was 23.608936 / 28.688244 /
  30.395605 dB and SSIM was 0.8682354 / 0.94056 / 0.9542484.
- An independent RGB comparison of the ten saved final renders to the held-out
  references gives mean per-image PSNR 30.395845 dB. Alpha is composited on black.
  These are validation results used while monitoring training, not a final
  independent benchmark test or scores from Unity rendering.

`training/run-01/` contains the actual command, complete log, exports and saved
validation renders. Keep it separate from any later experiment.

## Filter

`scripts/prepare_models.py` reads PLY properties by name, checks finite values
and the binary payload length, and preserves the original export. A splat is
removed if sigmoid(opacity) is below 0.01 or its centre is farther than 2 scene
units from the median centre. The thresholds were chosen for this experiment.
The original 9,020 splats become 8,820; 199 have low opacity, 3 are distant,
with 2 in both groups. This is a small cleanup, not evidence that visual quality
improved. See `verification/cleanup.json` for values and model hashes.

## Unity viewer

Open `UnityProject` with Unity **6000.0.23f1** and open
`Assets/Scenes/SplatLab.unity` after the recorded build. The embedded MIT viewer
package is pinned to aras-p/UnityGaussianSplatting commit
`2c6fed37da67a217367261fcfcd3316d34c73e76`, package version 1.1.1.
Its source and licence are included under Packages.

Windows requires **Direct3D 12** (or an independently configured Vulkan build).
Direct3D 11 is not supported by this viewer. The project uses the Built-in
Render Pipeline, Linear colour and no MSAA. The manifest includes VR/XR
engine modules because the viewer references XRSettings, even for a desktop
scene. A minimal manifest without the VR module initially failed compilation.

The desktop controls are Left/Right to select one of three validation cameras,
C to switch raw/filtered models, P to switch splats/debug points, and Escape
to exit. Imported data uses the Medium preset. The coordinate conversion
reflects Z for both the model and its OpenGL camera poses.

To rebuild, invoke the editor with this project path and
`-batchmode -force-d3d12 -quit -executeMethod SplatLabBuild.Build`.
The build helper uses the pinned package's asset-creator entry points and saves
the scene plus `Builds/Windows/GaussianSplatLab.exe`. `verification/unity-import.json`
records imported counts. See `verification/REPORT.md` for runtime verification.

## Reproduce the data steps

Python with NumPy and Pillow is needed for preparation. Existing course
environments provide these packages. No CUDA toolkit installation is needed
for the released Brush binary.

1. Prepare the CC0 dataset with `python scripts/fetch_dataset.py`.
2. Download Brush v0.3.0 from its official GitHub release and verify the published
   SHA-256. Set `BRUSH_EXE` if it is outside the original course tools directory.
3. Run `python scripts/train.py` in a fresh copy of the project. The recorded
   run already exists, so preserve it before starting another experiment.
4. Run `python scripts/prepare_models.py`, then the Unity build helper.

Set `GS_LAB_OUTPUT` to an output folder before starting the Windows player to
run the automated capture check. It renders raw and filtered models through the
actual camera at three poses, writes a debug-point image and runtime JSON, then
exits. The capture files are Unity renders with the desktop overlay excluded.
The check does not measure FPS or demonstrate a VR/mobile deployment.

## References

- [Original 3DGS paper and project](https://repo-sam.inria.fr/fungraph/3d-gaussian-splatting/)
- [Brush release used](https://github.com/ArthurBrussee/brush/releases/tag/v0.3.0)
- [Unity viewer](https://github.com/aras-p/UnityGaussianSplatting)
- [NeRF Synthetic data context](https://www.matthewtancik.com/nerf)

The original local course source is `3D Gaussian splatting in unity.pptx`.
It describes the training pipeline and the Unity asset/renderer walkthrough;
it does not provide a separate grading table or calendar deadline.
