# Added sparse reconstruction — 21 October 2026

This is a separate, measured Structure-from-Motion addition to the Hotdog lab.
The Brush training, Gaussian PLY files, Unity project and earlier downloads are
unchanged. The new sparse model was not used to retrain the recorded Brush run.

## What ran

Official PyCOLMAP **4.2.1**, CPU, eight threads, seed 20261021. The Windows wheel
was installed in a separate tools folder on D:. No learned feature model, CUDA
toolkit or full COLMAP desktop installation was needed.

Input: the same 100 original NeRF Synthetic Hotdog training images, **800x800**.
Alpha is composited on black and saved as RGB. Source hashes match the existing
data manifest. No validation image is used.

The shared SIMPLE_PINHOLE camera starts at focal length 1111.1110 pixels from
the supplied field of view, with principal point (400,400). Bundle adjustment
can refine the focal length. **No camera extrinsics are supplied to COLMAP.**

The run performs SIFT extraction (cap 4096 features per image), exhaustive image
matching, geometric verification, incremental mapping, triangulation and bundle
adjustment. Full options, input hashes and native logs are retained.

- 124,205 SIFT keypoints.
- 4,950 candidate image pairs; 2,010 have at least 15 verified inliers.
- One retained model: **96/100 registered images, 8,425 sparse 3D points**.
- Unregistered: r_15.png, r_69.png, r_79.png, r_91.png.
- Mean reprojection error **0.528781 pixels**; mean track length **9.0114**.
- Total process time **72.68 s**, including RGB preparation/export. Extraction
  6.08 s, matching 25.18 s, mapping 35.22 s.

The sparse cloud has gaps and some outliers. Feature-rich bread has more points
than the smooth plate. This is an SfM point cloud, not the Gaussian debug view,
a dense surface, or evidence of registration of all input views.

## Outputs and checks

`run-01/sparse/0/` contains COLMAP binary cameras, images, points, rigs and frames.
`run-01/text/0/` contains the equivalent text model. `run-01/sparse.ply` exports
every sparse point in the native SfM coordinate system. `summary.json` records
the actual metrics and binary model hashes; `verification.json` records export
reload and preservation checks.

`make_figures.py` uses the measured points and camera poses. A post-hoc similarity
fit to the provided camera centres only orients the plot; it was not an input
to SfM. The camera-centre RMSE after this fit is 0.00809 dataset units. The close
view uses 1st–99th coordinate percentiles plus a margin; the full-scene panel
and PLY retain all points. The matching figure displays 50 of 634 geometrically
verified correspondences in r_16.png / r_99.png, taken from the database.

## Reproduce

Use Python 3.12, then install `pycolmap==4.2.1`, NumPy, Pillow and Matplotlib.
The archive has the same `GaussianSplatLab/` root as the earlier Unity archive.
The native database and input photos are retained locally rather than duplicated
in the download. Download the inputs first if they are absent:

1. From `GaussianSplatLab`, run `python scripts/fetch_dataset.py`.
2. Preserve/move the included `sparse-colmap/run-01` before rerunning; the runner
   refuses to overwrite an existing database or result summary.
3. Run `python sparse-colmap/run_sparse.py` and capture stdout/stderr to a new log.
4. Run `python sparse-colmap/make_figures.py`.

Results can vary with platform, numerical libraries and thread scheduling.
Recorded results and hashes describe this run, not a reproducibility guarantee.

## Browser options checked

- [colmap-wasm demo](https://colmap.wasm.obraia.dev/): unofficial browser port
  of COLMAP 4.2.1. Supports images/video, SIFT, global mapping and downloading
  `sparse/0` as ZIP; WebGPU is needed for matching. Repository:
  https://github.com/obraia/colmap-wasm .
- [WebSfM](https://websfm.fdahle.de/): browser-local SfM with COLMAP/PLY export,
  an early test release. https://github.com/fdahle/websfm .
- [ReconViewer cloud SfM](https://reconviewer.com/products/sfm-tool/): advertised
  server-side COLMAP reconstruction; cloud processing uses paid credits. No
  purchase, account creation or cloud reconstruction job was performed.

The first two websites returned HTTP 200 and their live interfaces opened in
Edge on 21 October. The colmap-wasm page had image input, Estimate cameras and
Download sparse/0 buttons, with WebGPU available. These were interface checks,
not full reconstruction runs. **The measured experiment above ran in native
official PyCOLMAP, not on a website.** A COLMAP viewer alone cannot generate a
new sparse reconstruction from photos.

## Sources

- COLMAP SfM tutorial: https://colmap.github.io/tutorial.html
- Official Python pipeline: https://github.com/colmap/colmap/tree/main/python
- File format: https://colmap.github.io/format.html
- Input model: erickfree, CC0, https://www.blendswap.com/blend/23962
- Rendered image mirror: https://huggingface.co/datasets/pablovela5620/nerf-synthetic-mirror
