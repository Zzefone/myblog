"""Plot measured COLMAP geometry and verified image matches, without rerunning SfM."""
from pathlib import Path
import json
import sqlite3
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch

HERE = Path(__file__).resolve().parent
RUN = HERE / "run-01"
geometry = json.loads((RUN / "geometry.json").read_text())
points = np.array([p["xyz"] for p in geometry["points"]])
colors = np.array([p["rgb"] for p in geometry["points"]]) / 255
cameras = geometry["cameras"]
estimated = np.array([c["center"] for c in cameras])
reference_doc = json.loads((HERE.parent / "data/raw/hotdog/transforms_train.json").read_text())
references = {Path(f["file_path"]).stem + ".png": np.array(f["transform_matrix"])
              for f in reference_doc["frames"]}
target = np.array([references[c["name"]][:3, 3] for c in cameras])
# SfM has arbitrary scale/orientation. Fit one similarity using registered
# camera centres for display/validation only, after the blind mapping run.
mean_a, mean_b = estimated.mean(axis=0), target.mean(axis=0)
a, b = estimated - mean_a, target - mean_b
u, singular, vt = np.linalg.svd(b.T @ a / len(a))
sign = np.ones(3)
sign[-1] = np.linalg.det(u @ vt)
rotation = u @ np.diag(sign) @ vt
scale = float(np.sum(singular * sign) / np.mean(np.sum(a * a, axis=1)))
translation = mean_b - scale * rotation @ mean_a
def aligned(x):
    return scale * (x @ rotation.T) + translation
points, centers = aligned(points), aligned(estimated)
errors = np.linalg.norm(centers - target, axis=1)
alignment = {"purpose": "Post-hoc plot alignment, not an input to COLMAP or a Brush retraining step.",
             "scale": scale, "rotation": rotation.tolist(), "translation": translation.tolist(),
             "registered_camera_center_rmse_dataset_units": float(np.sqrt(np.mean(errors**2))),
             "maximum_camera_center_error_dataset_units": float(errors.max()),
             "display_closeup_limits": "1st to 99th coordinate percentiles plus 10% margin; exported PLY retains every point."}
(RUN / "display-alignment.json").write_text(json.dumps(alignment, indent=2) + "\n")

fig = plt.figure(figsize=(15, 6.8), facecolor="#10141d")
axes = [fig.add_subplot(121, projection="3d"), fig.add_subplot(122, projection="3d")]
for ax in axes:
    ax.set_facecolor("#10141d")
    ax.tick_params(colors="#bac6d8", labelsize=8)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.label.set_color("#d7e1ef")
        axis.set_pane_color((0.07,0.09,0.13,1))
    ax.set_xlabel("X"); ax.set_ylabel("Y"); ax.set_zlabel("Z")
    ax.view_init(elev=25, azim=-60)
bounds = np.quantile(points, [0.01,0.99], axis=0)
margin = np.maximum(bounds[1]-bounds[0], 0.1)*0.1
in_view = np.all((points >= bounds[0]-margin) & (points <= bounds[1]+margin), axis=1)
axes[0].scatter(*points[in_view].T, c=colors[in_view], s=2.0, depthshade=False, rasterized=True)
for i, setter in enumerate((axes[0].set_xlim, axes[0].set_ylim, axes[0].set_zlim)):
    setter(bounds[0,i]-margin[i], bounds[1,i]+margin[i])
axes[0].set_box_aspect(bounds[1]-bounds[0]+2*margin)
axes[0].set_title("8,425 triangulated points — close view",color="white",pad=18)
axes[0].text2D(0.02,0.01,"Close-up uses 1–99% bounds; the PLY retains all points.",transform=axes[0].transAxes,color="#bac6d8",fontsize=9)
axes[1].scatter(*points.T,c=colors,s=1.5,depthshade=False,alpha=.85)
axes[1].scatter(*centers.T,c="#54b9f7",s=9,label="96 registered cameras",depthshade=False)
for index, camera in enumerate(cameras):
    rot = rotation @ np.array(camera["rotation_camera_to_world"])
    origin = centers[index]
    corners = np.array([[-.055,-.055,.09],[.055,-.055,.09],[.055,.055,.09],[-.055,.055,.09]]) @ rot.T + origin
    for corner in corners:
        axes[1].plot(*np.vstack([origin,corner]).T,color="#54b9f7",alpha=.3,linewidth=.45)
    axes[1].plot(*np.vstack([corners,corners[0]]).T,color="#54b9f7",alpha=.45,linewidth=.45)
axes[1].set_title("Sparse scene and estimated cameras",color="white",pad=18)
all_xyz = np.vstack([points, centers])
extent = np.ptp(all_xyz,axis=0)
axes[1].set_box_aspect(extent)
axes[1].legend(facecolor="#10141d",labelcolor="white",loc="lower left",fontsize=9)
fig.suptitle("COLMAP sparse reconstruction · 100 input images · 96 registered",color="white",fontsize=17,y=.98)
fig.subplots_adjust(left=.01,right=.99,bottom=.06,top=.87,wspace=.02)
fig.savefig(HERE / "sparse-cloud.png",dpi=160,facecolor=fig.get_facecolor())
plt.close(fig)

camera_by_id = {c["id"]: c for c in cameras}
with sqlite3.connect(RUN / "database.db") as db:
    rows=db.execute("SELECT pair_id,rows,data FROM two_view_geometries WHERE rows>=100 ORDER BY rows DESC").fetchall()
    chosen=None
    for pair_id,count,blob in rows:
        first,second=divmod(pair_id,2147483647)
        if first not in camera_by_id or second not in camera_by_id:
            continue
        va=aligned(np.array([camera_by_id[first]["center"]]))[0]
        vb=aligned(np.array([camera_by_id[second]["center"]]))[0]
        angle=np.degrees(np.arccos(np.clip(np.dot(va,vb)/np.linalg.norm(va)/np.linalg.norm(vb),-1,1)))
        if 20 < angle < 50:
            chosen=(first,second,count,blob,float(angle));break
    assert chosen
    first,second,count,blob,angle=chosen
    matches=np.frombuffer(blob,dtype=np.uint32).reshape(-1,2)
    selected=np.random.default_rng(20261021).choice(len(matches),size=min(50,len(matches)),replace=False)
    keypoints=[]
    for image_id in (first,second):
        columns,raw=db.execute("SELECT cols,data FROM keypoints WHERE image_id=?",(image_id,)).fetchone()
        keypoints.append(np.frombuffer(raw,dtype=np.float32).reshape(-1,columns)[:,:2])
fig,axes=plt.subplots(1,2,figsize=(13,6.8),facecolor="#10141d")
for ax,image_id in zip(axes,(first,second)):
    name=camera_by_id[image_id]["name"]
    ax.imshow(Image.open(RUN / "images" / name)); ax.set_axis_off()
    ax.set_title(name,color="white",fontsize=13)
for match in matches[selected]:
    left,right=keypoints[0][match[0]],keypoints[1][match[1]]
    axes[0].scatter(*left,c="#60e5a0",s=5)
    axes[1].scatter(*right,c="#60e5a0",s=5)
    fig.add_artist(ConnectionPatch(xyA=left,xyB=right,coordsA="data",coordsB="data",axesA=axes[0],axesB=axes[1],color="#60e5a0",linewidth=.5,alpha=.5))
fig.suptitle(f"Geometrically verified SIFT correspondences · {count:,} inliers in this pair",color="white",fontsize=15,y=.98)
fig.text(.5,.025,"50 verified matches shown; image coordinates come directly from the COLMAP database.",ha="center",color="#bac6d8",fontsize=10)
fig.subplots_adjust(left=.02,right=.98,bottom=.07,top=.91,wspace=.025)
fig.savefig(HERE / "verified-matches.png",dpi=150,facecolor=fig.get_facecolor())
plt.close(fig)
(RUN / "match-figure.json").write_text(json.dumps({"images":[camera_by_id[first]["name"],camera_by_id[second]["name"]],"pair_inliers":count,"matches_displayed":len(selected),"estimated_camera_separation_degrees":angle},indent=2)+"\n")
print(json.dumps({"camera_alignment":alignment,"match_pair_inliers":count}))
