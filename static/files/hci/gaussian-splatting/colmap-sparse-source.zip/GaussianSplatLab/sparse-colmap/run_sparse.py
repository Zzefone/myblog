"""Add a separate, real COLMAP SfM run; never modify the recorded Brush experiment."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import sqlite3
import time
import numpy as np
from PIL import Image
import pycolmap

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
RUN = HERE / "run-01"
if (RUN / "database.db").exists() or (RUN / "summary.json").exists():
    raise SystemExit("Run already exists. Preserve it and use a fresh run folder.")
RUN.mkdir(parents=True, exist_ok=True)
images = RUN / "images"
images.mkdir(exist_ok=True)
seed = 20261021
pycolmap.set_random_seed(seed)
start = time.perf_counter()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = json.loads((LAB / "data/source-manifest.json").read_text())
expected = {item["path"]: item["sha256"] for item in manifest["files"]}
inputs = []
for path in sorted((LAB / "data/raw/hotdog/train").glob("*.png")):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == expected["train/" + path.name]
    with Image.open(path) as source:
        rgba = source.convert("RGBA")
        assert rgba.size == (800, 800)
        black = Image.new("RGBA", rgba.size, (0, 0, 0, 255))
        Image.alpha_composite(black, rgba).convert("RGB").save(images / path.name)
    inputs.append({"name": path.name, "original_sha256": digest})
assert len(inputs) == 100
# Only the field of view is used for calibration. No input camera extrinsics
# or validation images are supplied to COLMAP.
angle = json.loads((LAB / "data/raw/hotdog/transforms_train.json").read_text())["camera_angle_x"]
focal = 800 / (2 * math.tan(angle / 2))
reader = pycolmap.ImageReaderOptions()
reader.camera_model = "SIMPLE_PINHOLE"
reader.camera_params = f"{focal},400,400"
extract = pycolmap.FeatureExtractionOptions()
extract.num_threads = 8
extract.max_image_size = 800
extract.sift.max_num_features = 4096
matching = pycolmap.FeatureMatchingOptions()
matching.num_threads = 8
verify = pycolmap.TwoViewGeometryOptions()
verify.ransac.random_seed = seed
mapping = pycolmap.IncrementalPipelineOptions()
mapping.num_threads = 8
mapping.random_seed = seed
mapping.mapper.random_seed = seed
mapping.triangulation.random_seed = seed
mapping.max_num_models = 5
mapping.max_runtime_seconds = 600
mapping.ba_local_max_num_iterations = 25
mapping.ba_global_max_num_iterations = 50
config = {"experiment_date": "2026-10-21", "pycolmap_version": pycolmap.__version__,
          "device": "CPU", "seed": seed, "images": inputs, "resolution": [800, 800],
          "shared_camera": "SIMPLE_PINHOLE", "focal_prior_pixels": focal,
          "camera_extrinsics_supplied": False, "validation_images_used": False,
          "reader_options": reader.todict(), "extraction_options": extract.todict(),
          "matching_options": matching.todict(), "verification_options": verify.todict(),
          "mapping_options": mapping.todict()}
(RUN / "config.json").write_text(json.dumps(config, indent=2, default=str) + "\n")
database = RUN / "database.db"
times = {}
checkpoint = time.perf_counter()
print("STAGE: SIFT extraction, 100 RGB training views, 800px, CPU", flush=True)
pycolmap.extract_features(database, images, camera_mode=pycolmap.CameraMode.SINGLE,
                         reader_options=reader, extraction_options=extract, device=pycolmap.Device.cpu)
times["extraction_seconds"] = time.perf_counter() - checkpoint
checkpoint = time.perf_counter()
print("STAGE: exhaustive matching and geometric verification", flush=True)
pycolmap.match_exhaustive(database, matching_options=matching,
                         verification_options=verify, device=pycolmap.Device.cpu)
times["matching_seconds"] = time.perf_counter() - checkpoint
checkpoint = time.perf_counter()
print("STAGE: incremental mapping, triangulation and bundle adjustment", flush=True)
models = pycolmap.incremental_mapping(database, images, RUN / "models", options=mapping)
times["mapping_seconds"] = time.perf_counter() - checkpoint
assert models, "COLMAP returned no sparse model; inspect run.log."
best_id, best = max(models.items(), key=lambda item: item[1].num_reg_images())
binary = RUN / "sparse/0"
text = RUN / "text/0"
binary.mkdir(parents=True, exist_ok=True)
text.mkdir(parents=True, exist_ok=True)
best.write(binary)
best.write_text(text)
best.export_PLY(RUN / "sparse.ply")
points = [{"id": int(point_id), "xyz": point.xyz.tolist(), "rgb": point.color.tolist(),
           "reprojection_error": point.error, "track_length": point.track.length()}
          for point_id, point in best.points3D.items()]
cameras = [{"id": int(image_id), "name": image.name,
            "center": image.projection_center().tolist(),
            "rotation_camera_to_world": image.cam_from_world().rotation.matrix().T.tolist(),
            "camera_id": image.camera_id}
           for image_id, image in best.images.items() if image.has_pose]
(RUN / "geometry.json").write_text(json.dumps({"points": points, "cameras": cameras}) + "\n")
with sqlite3.connect(database) as db:
    feature_count = db.execute("SELECT SUM(rows) FROM keypoints").fetchone()[0]
    matched_pairs = db.execute("SELECT COUNT(*) FROM matches WHERE rows > 0").fetchone()[0]
    verified_pairs = db.execute("SELECT COUNT(*) FROM two_view_geometries WHERE rows >= 15").fetchone()[0]
result = {"status": "completed", "started_utc": started,
          "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "pycolmap_version": pycolmap.__version__, "device": "CPU", "input_images": 100,
          "resolution": [800, 800], "seed": seed, "focal_prior_pixels": focal,
          "camera_extrinsics_supplied": False, "validation_images_used": False,
          "exhaustive_candidate_pairs": 4950, "extracted_keypoints": feature_count,
          "matched_pairs_with_matches": matched_pairs, "verified_pairs_at_least_15_inliers": verified_pairs,
          "models": [{"id": int(i), "registered_images": m.num_reg_images(), "points": m.num_points3D()}
                     for i,m in models.items()], "selected_model": int(best_id),
          "registered_images": best.num_reg_images(), "sparse_points": best.num_points3D(),
          "mean_reprojection_error_pixels": best.compute_mean_reprojection_error(),
          "mean_track_length": best.compute_mean_track_length(),
          "mean_observations_per_registered_image": best.compute_mean_observations_per_reg_image(),
          "timing": dict(times, total_seconds=time.perf_counter()-start),
          "used_to_retrain_brush": False,
          "scope": "Separate SfM addition on original training images; previous Brush/Unity results unchanged."}
result["outputs"] = [{"file": str(p.relative_to(RUN)).replace("\\", "/"),
                       "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                      for p in sorted(binary.glob("*")) if p.is_file()]
(RUN / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
print("SPARSE_COMPLETE " + json.dumps(result), flush=True)
