using System;
using System.Collections.Generic;
using System.IO;
using SignalChase.Mobile;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;

public static class MobileInteractionChecks
{
    [Serializable] private class Check { public string name; public bool passed; }
    [Serializable] private class Report { public string environment="Unity editor Play Mode component tests; not Android deployment"; public List<Check> checks=new List<Check>(); }
    public static void Run()
    {
        if (!EditorApplication.isPlaying) throw new InvalidOperationException("Run through MobileDesktopPreview so lifecycle callbacks are tested in Play Mode.");
        Report report = new Report();
        GameObject canvasObject = new GameObject("Test canvas", typeof(Canvas));
        canvasObject.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        EventSystem events = new GameObject("Test EventSystem", typeof(EventSystem)).GetComponent<EventSystem>();
        RectTransform stick = new GameObject("Joystick", typeof(RectTransform)).GetComponent<RectTransform>();
        stick.SetParent(canvasObject.transform, false); stick.sizeDelta = new Vector2(220, 220);
        RectTransform thumb = new GameObject("Thumb", typeof(RectTransform)).GetComponent<RectTransform>(); thumb.SetParent(stick, false);
        TouchJoystick joystick = stick.gameObject.AddComponent<TouchJoystick>(); joystick.Thumb = thumb;
        Canvas.ForceUpdateCanvases();
        Vector2 center = RectTransformUtility.WorldToScreenPoint(null, stick.position);
        void Add(string name, bool passed) => report.checks.Add(new Check {name=name, passed=passed});
        Add("Joystick starts at zero", joystick.Direction == Vector2.zero);
        PointerEventData first = new PointerEventData(events) {pointerId=1, position=center + Vector2.right * 100};
        joystick.OnPointerDown(first);
        Add("Pointer down produces rightward input and increments gesture count", joystick.Direction.x > .99f && joystick.Gestures == 1);
        Add("Joystick input is clamped to a unit circle", joystick.Direction.magnitude <= 1.0001f);
        PointerEventData second = new PointerEventData(events) {pointerId=2, position=center - Vector2.right * 100};
        joystick.OnPointerDown(second); joystick.OnDrag(second);
        Add("A second pointer cannot steal the active joystick", joystick.Direction.x > .99f && joystick.Gestures == 1);
        first.position = center + Vector2.up * 45;
        joystick.OnDrag(first);
        Add("Active pointer drag changes direction", joystick.Direction.y > .5f && Mathf.Abs(joystick.Direction.x) < .001f);
        joystick.OnPointerUp(second);
        Add("An unrelated pointer up does not clear the joystick", joystick.Direction.y > .5f);
        joystick.OnPointerUp(first);
        Add("Releasing the active pointer clears input and centers the thumb", joystick.Direction == Vector2.zero && thumb.anchoredPosition == Vector2.zero);
        joystick.OnPointerDown(first); stick.gameObject.SetActive(false);
        Add("Disabling the joystick clears held input", joystick.Direction == Vector2.zero);
        UnityEngine.Object.DestroyImmediate(canvasObject); UnityEngine.Object.DestroyImmediate(events.gameObject);
        Directory.CreateDirectory("../evidence");
        File.WriteAllText("../evidence/component-checks.json", JsonUtility.ToJson(report, true));
        foreach (var check in report.checks) Debug.Log("MOBILE_COMPONENT " + check.name + ": " + check.passed);
        if (report.checks.Exists(c => !c.passed)) throw new Exception("Mobile joystick component check failed.");
    }
}
