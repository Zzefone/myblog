using System;
using System.IO;
using SignalChase.Mobile;
using UnityEngine;
using UnityEditor;
using UnityEditor.Android;
using UnityEditor.Build.Reporting;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine.Rendering;
using Unity.InferenceEngine;

public static class MobileProjectBuilder
{
    public static void Configure()
    {
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Materials");
        Material material = AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/SignalChase.mat");
        if (material == null)
        {
            material = new Material(Shader.Find("Standard"));
            AssetDatabase.CreateAsset(material, "Assets/Materials/SignalChase.mat");
        }
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        SignalChaseMobileApp app = new GameObject("Signal Chase Mobile").AddComponent<SignalChaseMobileApp>();
        app.ReachModel = AssetDatabase.LoadAssetAtPath<ModelAsset>("Assets/Models/ReachTarget.onnx");
        app.ChaseModel = AssetDatabase.LoadAssetAtPath<ModelAsset>("Assets/Models/ChaseTarget.onnx");
        app.BaseMaterial = material;
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/SignalChaseMobile.unity");
        EditorBuildSettings.scenes = new[]{new EditorBuildSettingsScene("Assets/Scenes/SignalChaseMobile.unity", true)};
        PlayerSettings.companyName = "WANG Zhaofeng";
        PlayerSettings.productName = "Signal Chase Mobile";
        PlayerSettings.bundleVersion = "1.0.0";
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.wangzhaofeng.signalchase");
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToLandscapeLeft = true;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel29;
        PlayerSettings.Android.targetSdkVersion = (AndroidSdkVersions)35;
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.X86_64;
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.SetApiCompatibilityLevel(NamedBuildTarget.Android, ApiCompatibilityLevel.NET_Standard);
        PlayerSettings.stripEngineCode = true;
        PlayerSettings.Android.useCustomKeystore = false;
        PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
        PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[]{GraphicsDeviceType.OpenGLES3});
        QualitySettings.antiAliasing = 2;
        QualitySettings.shadows = ShadowQuality.Disable;
        AndroidExternalToolsSettings.sdkRootPath = @"D:\1_VAR_blog\HCI\tools\android\sdk";
        AndroidExternalToolsSettings.ndkRootPath = @"D:\1_VAR_blog\HCI\tools\android\ndk\android-ndk-r23b";
        AndroidExternalToolsSettings.jdkRootPath = @"D:\unity\6000.0.23f1\Editor\Data\PlaybackEngines\AndroidPlayer\OpenJDK";
        AssetDatabase.SaveAssets();
        Debug.Log("Signal Chase Mobile scene and Android settings configured.");
    }
    public static void BuildAndroid()
    {
        Configure();
        if (AssetDatabase.LoadAssetAtPath<ModelAsset>("Assets/Models/ReachTarget.onnx") == null || AssetDatabase.LoadAssetAtPath<ModelAsset>("Assets/Models/ChaseTarget.onnx") == null)
            throw new InvalidOperationException("Both trained ONNX models are required before building the Android application.");
        Directory.CreateDirectory("Builds/Android");
        BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
            scenes = new[]{"Assets/Scenes/SignalChaseMobile.unity"},
            locationPathName = "Builds/Android/SignalChaseMobile.apk",
            target = BuildTarget.Android,
            options = BuildOptions.Development
        });
        Debug.Log("Android build result=" + report.summary.result + " bytes=" + report.summary.totalSize);
        if (report.summary.result != BuildResult.Succeeded) throw new Exception("Android build failed: " + report.summary.result);
    }
}
