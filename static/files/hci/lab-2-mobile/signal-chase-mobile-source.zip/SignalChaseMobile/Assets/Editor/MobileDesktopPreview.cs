using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using SignalChase;
using SignalChase.Mobile;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Unity.MLAgents.Policies;

// Optional Windows editor smoke test. This is deliberately not Android evidence.
[InitializeOnLoad]
public static class MobileDesktopPreview
{
    [Serializable] private class Check { public string name; public bool passed; }
    [Serializable] private class Report
    {
        public string environment = "Windows Unity editor preview; not Android execution";
        public string input = "UGUI ExecuteEvents pointer dispatch; not OS or Android touch";
        public int width, height;
        public List<Check> checks = new List<Check>();
    }
    private const string ActiveKey = "SignalChase.MobilePreview.Active";
    private static Report report;
    private static int step;
    private static double nextAt;
    private static double beganAt;
    private static Vector3 targetBefore;
    private static Vector3 agentBefore;
    private static int capturesBefore;
    private static float pausedTime;
    private static DateTime beganUtc;
    private static TouchJoystick joystick;
    private static TargetController target;
    private static RollerChaseAgent agent;
    private static PointerEventData pointer;
    private static string Evidence => Path.GetFullPath("../evidence");

    static MobileDesktopPreview()
    {
        EditorApplication.playModeStateChanged += OnPlayMode;
        if (SessionState.GetBool(ActiveKey, false)) EditorApplication.update += Tick;
    }
    public static void Run()
    {
        SessionState.SetBool(ActiveKey, true);
        EditorSceneManager.OpenScene("Assets/Scenes/SignalChaseMobile.unity");
        Type gameViewType = typeof(Editor).Assembly.GetType("UnityEditor.GameView");
        EditorWindow gameView = EditorWindow.GetWindow(gameViewType);
        gameView.position = new Rect(20, 20, 1280, 720);
        gameView.Show();
        gameView.Focus();
        EditorApplication.isPlaying = true;
    }
    private static void OnPlayMode(PlayModeStateChange state)
    {
        if (!SessionState.GetBool(ActiveKey, false)) return;
        if (state == PlayModeStateChange.EnteredPlayMode)
        {
            report = new Report();
            step = 0;
            beganAt = EditorApplication.timeSinceStartup;
            beganUtc = DateTime.UtcNow;
            nextAt = beganAt + 4;
            EditorApplication.update -= Tick;
            EditorApplication.update += Tick;
            try { MobileInteractionChecks.Run(); }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                Add("Play Mode component checks passed", false);
                Finish(1);
            }
        }
    }
    private static void Add(string name, bool passed)
    {
        report.checks.Add(new Check { name = name, passed = passed });
        Debug.Log("WINDOWS_PREVIEW " + name + ": " + passed);
    }
    private static GameObject Control(string name) => GameObject.Find(name);
    private static void Click(string name)
    {
        GameObject control = Control(name);
        var data = new PointerEventData(EventSystem.current) { pointerId = -1, button = PointerEventData.InputButton.Left };
        ExecuteEvents.Execute(control, data, ExecuteEvents.pointerDownHandler);
        ExecuteEvents.Execute(control, data, ExecuteEvents.pointerUpHandler);
        ExecuteEvents.Execute(control, data, ExecuteEvents.pointerClickHandler);
    }
    private static void Finish(int code)
    {
        Directory.CreateDirectory(Evidence);
        File.WriteAllText(Path.Combine(Evidence, "desktop-preview-checks.json"), JsonUtility.ToJson(report, true));
        SessionState.SetBool(ActiveKey, false);
        EditorApplication.update -= Tick;
        EditorApplication.Exit(code);
    }
    private static void MarkWindowsPreview()
    {
        Canvas overlay = new GameObject("Windows preview evidence label", typeof(Canvas), typeof(CanvasScaler)).GetComponent<Canvas>();
        overlay.renderMode = RenderMode.ScreenSpaceOverlay;
        overlay.sortingOrder = 32760;
        var scaler = overlay.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 720);
        RectTransform footer = new GameObject("Evidence footer", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
        footer.SetParent(overlay.transform, false);
        footer.anchorMin = Vector2.zero;
        footer.anchorMax = new Vector2(1, 0);
        footer.pivot = new Vector2(.5f, 0);
        footer.sizeDelta = new Vector2(0, 30);
        footer.anchoredPosition = Vector2.zero;
        footer.GetComponent<Image>().color = new Color(.015f, .025f, .04f, .96f);
        Text label = new GameObject("Evidence text", typeof(RectTransform), typeof(Text)).GetComponent<Text>();
        label.transform.SetParent(footer, false);
        label.rectTransform.anchorMin = Vector2.zero;
        label.rectTransform.anchorMax = Vector2.one;
        label.rectTransform.offsetMin = label.rectTransform.offsetMax = Vector2.zero;
        label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        label.fontSize = 18;
        label.alignment = TextAnchor.MiddleCenter;
        label.color = new Color(1, .82f, .36f);
        label.text = "WINDOWS EDITOR PREVIEW / ANDROID RUN NOT TESTED";
        label.raycastTarget = false;
    }
    private static void Tick()
    {
        if (!SessionState.GetBool(ActiveKey, false) || !EditorApplication.isPlaying || report == null) return;
        if (EditorApplication.timeSinceStartup - beganAt > 90)
        {
            Add("Preview completes within 90 seconds", false);
            Finish(1);
            return;
        }
        if (EditorApplication.timeSinceStartup < nextAt) return;
        try
        {
            switch (step++)
            {
                case 0:
                    report.width = Screen.width;
                    report.height = Screen.height;
                    joystick = UnityEngine.Object.FindFirstObjectByType<TouchJoystick>();
                    target = UnityEngine.Object.FindFirstObjectByType<TargetController>();
                    agent = UnityEngine.Object.FindFirstObjectByType<RollerChaseAgent>();
                    Add("Runtime UGUI and trained agent are active", joystick != null && target != null && agent != null && agent.GetComponent<BehaviorParameters>().BehaviorType == BehaviorType.InferenceOnly && agent.GetComponent<BehaviorParameters>().Model != null);
                    Add("Initial mode is TOUCH", Control("mode label").GetComponent<Text>().text == "MODE: TOUCH");
                    Canvas.ForceUpdateCanvases();
                    Vector2 center = RectTransformUtility.WorldToScreenPoint(null, joystick.transform.position);
                    pointer = new PointerEventData(EventSystem.current) { pointerId = 12, position = center + new Vector2(60, 35), button = PointerEventData.InputButton.Left };
                    targetBefore = target.transform.position;
                    agentBefore = agent.transform.position;
                    capturesBefore = agent.Successes;
                    ExecuteEvents.Execute(joystick.gameObject, pointer, ExecuteEvents.pointerDownHandler);
                    Add("UGUI pointer event holds joystick input", joystick.Direction.magnitude > .5f && joystick.Gestures == 1);
                    nextAt = EditorApplication.timeSinceStartup + .7;
                    break;
                case 1:
                    Add("Held joystick moves the target", Vector3.Distance(targetBefore, target.transform.position) > .1f);
                    Add("Trained inference produces agent movement in Windows editor", Vector3.Distance(agentBefore, agent.transform.position) > .01f || agent.Successes > capturesBefore);
                    ExecuteEvents.Execute(joystick.gameObject, pointer, ExecuteEvents.pointerUpHandler);
                    Add("Pointer release clears joystick", joystick.Direction == Vector2.zero);
                    Click("pause");
                    targetBefore = target.transform.position;
                    pausedTime = Time.time;
                    nextAt = EditorApplication.timeSinceStartup + .7;
                    break;
                case 2:
                    Add("Pause freezes game time and target", Time.timeScale == 0 && Mathf.Abs(Time.time - pausedTime) < .001f && Vector3.Distance(targetBefore, target.transform.position) < .001f);
                    Click("pause");
                    Add("Resume restores time scale", Time.timeScale == 1);
                    Click("reset");
                    Add("Reset callback was invoked", (int)typeof(SignalChaseMobileApp).GetField("resets", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(UnityEngine.Object.FindFirstObjectByType<SignalChaseMobileApp>()) == 1);
                    Click("mode");
                    Add("STATIC selection stops target motion", Control("mode label").GetComponent<Text>().text == "MODE: STATIC" && !target.Moving && !target.Manual);
                    Click("mode");
                    Add("AUTO selection restores automatic motion", Control("mode label").GetComponent<Text>().text == "MODE: AUTO" && target.Moving && !target.Manual);
                    Click("mode");
                    Add("TOUCH selection restores manual target input", Control("mode label").GetComponent<Text>().text == "MODE: TOUCH" && target.Manual);
                    MarkWindowsPreview();
                    ScreenCapture.CaptureScreenshot(Path.Combine(Evidence, "desktop-preview.png"));
                    nextAt = EditorApplication.timeSinceStartup + 3;
                    break;
                case 3:
                    string screenshot = Path.Combine(Evidence, "desktop-preview.png");
                    Add("Windows editor screenshot was saved", File.Exists(screenshot) && File.GetLastWriteTimeUtc(screenshot) > beganUtc);
                    Finish(report.checks.Exists(c => !c.passed) ? 1 : 0);
                    break;
            }
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);
            Add("Preview completed without exception", false);
            Finish(1);
        }
    }
}
