using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Unity.InferenceEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Policies;

namespace SignalChase.Mobile
{
    public class SignalChaseMobileApp : MonoBehaviour
    {
        public ModelAsset ReachModel;
        public ModelAsset ChaseModel;
        public UnityEngine.Material BaseMaterial;
        private RollerChaseAgent agent;
        private BehaviorParameters behavior;
        private TargetController target;
        private TouchJoystick joystick;
        private RectTransform safe;
        private Text status, instruction, pauseText, modeText;
        private bool paused;
        private int mode = 2;
        private int resets;
        private float logAt;
        private Rect previousSafeArea;
        private readonly List<string> controlNames = new List<string>();
        private readonly List<RectTransform> controlRects = new List<RectTransform>();
        private readonly Color navy = new Color(.04f, .07f, .115f);
        private readonly Color cyan = new Color(.13f, .82f, .89f);

        [Serializable] private class Telemetry
        {
            public string mode; public string policy = "trained_onnx";
            public bool paused; public float time; public float[] agent; public float[] target; public float[] joystick;
            public int captured, completed, resets, gestures; public int width, height;
        }
        private void Start()
        {
            Application.targetFrameRate = 30;
            Application.runInBackground = true;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Time.fixedDeltaTime = .02f;
            QualitySettings.vSyncCount = 0;
            Input.multiTouchEnabled = true;
            BuildArena();
            BuildInterface();
            ApplyMode();
            Debug.Log("SC_MOBILE_START platform=" + Application.platform + " device=" + SystemInfo.deviceModel + " inference=CPU");
            Invoke(nameof(LogControlPositions), 1f);
        }
        private Material Material(Color color)
        {
            Material mat = BaseMaterial != null ? new Material(BaseMaterial) : new Material(Shader.Find("Standard"));
            mat.color = color;
            mat.SetFloat("_Glossiness", .2f);
            return mat;
        }
        private GameObject Primitive(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, Color color, bool collider = true)
        {
            GameObject obj = GameObject.CreatePrimitive(type);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = pos;
            obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().material = Material(color);
            if (!collider) Destroy(obj.GetComponent<Collider>());
            return obj;
        }
        private void BuildArena()
        {
            GameObject arena = new GameObject("Signal Chase Arena");
            PhysicsMaterial surface = new PhysicsMaterial("Low-friction learning surface") { dynamicFriction=0, staticFriction=0, bounciness=0, frictionCombine=PhysicsMaterialCombine.Minimum, bounceCombine=PhysicsMaterialCombine.Minimum };
            GameObject platform = Primitive(PrimitiveType.Cube, "Platform", arena.transform, new Vector3(0, -.2f, 0), new Vector3(10, .4f, 10), new Color(.12f, .20f, .29f));
            platform.GetComponent<Collider>().sharedMaterial = surface;
            for (int i = -4; i <= 4; i++)
            {
                Primitive(PrimitiveType.Cube, "Grid X", arena.transform, new Vector3(i, .003f, 0), new Vector3(.018f, .006f, 9.8f), new Color(.22f, .33f, .42f), false);
                Primitive(PrimitiveType.Cube, "Grid Z", arena.transform, new Vector3(0, .003f, i), new Vector3(9.8f, .006f, .018f), new Color(.22f, .33f, .42f), false);
            }
            GameObject goal = Primitive(PrimitiveType.Cylinder, "Gold target", arena.transform, new Vector3(2, .25f, 2), new Vector3(.95f, .24f, .95f), new Color(1, .68f, .18f), false);
            target = goal.AddComponent<TargetController>();
            target.Moving = true;
            GameObject ball = Primitive(PrimitiveType.Sphere, "Neural agent", arena.transform, new Vector3(-2, .36f, -2), Vector3.one * .7f, cyan);
            ball.GetComponent<Collider>().sharedMaterial = surface;
            ball.SetActive(false);
            Rigidbody body = ball.AddComponent<Rigidbody>();
            body.linearDamping = 2.5f;
            body.angularDamping = .4f;
            body.constraints = RigidbodyConstraints.FreezeRotation;
            behavior = ball.AddComponent<BehaviorParameters>();
            behavior.BehaviorName = "ChaseTarget";
            behavior.BrainParameters.VectorObservationSize = 8;
            behavior.BrainParameters.NumStackedVectorObservations = 1;
            behavior.BrainParameters.ActionSpec = ActionSpec.MakeContinuous(2);
            behavior.BehaviorType = BehaviorType.InferenceOnly;
            behavior.InferenceDevice = InferenceDevice.Burst;
            behavior.DeterministicInference = true;
            behavior.Model = ChaseModel;
            agent = ball.AddComponent<RollerChaseAgent>();
            agent.Target = target;
            agent.TaskName = "ChaseTarget";
            agent.Seed = 742;
            agent.MaxStep = 0;
            DecisionRequester decisions = ball.AddComponent<DecisionRequester>();
            decisions.DecisionPeriod = 5;
            decisions.TakeActionsBetweenDecisions = true;
            if (ReachModel != null && ChaseModel != null) ball.SetActive(true);
            else Debug.LogError("SC_MOBILE_ERROR Trained models are missing. The agent stays inactive; no heuristic fallback.");
            Camera camera = new GameObject("Main Camera").AddComponent<Camera>();
            camera.tag = "MainCamera";
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = navy;
            camera.orthographic = true;
            camera.orthographicSize = 6.1f;
            camera.rect = new Rect(0, .16f, 1, .74f);
            camera.transform.position = new Vector3(0, 11, -8.5f);
            camera.transform.LookAt(Vector3.zero);
            Light sun = new GameObject("Sun").AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.2f;
            sun.transform.rotation = Quaternion.Euler(55, -30, 0);
            RenderSettings.ambientLight = new Color(.58f, .67f, .78f);
        }
        private RectTransform Panel(string name, Transform parent, Color color, Vector2 min, Vector2 max, Vector2 offsetMin, Vector2 offsetMax)
        {
            GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.SetParent(parent, false);
            rt.anchorMin = min; rt.anchorMax = max;
            rt.offsetMin = offsetMin; rt.offsetMax = offsetMax;
            go.GetComponent<Image>().color = color;
            return rt;
        }
        private Text Label(string name, Transform parent, string value, int size, Vector2 min, Vector2 max, Vector2 low, Vector2 high, TextAnchor align = TextAnchor.MiddleLeft)
        {
            GameObject go = new GameObject(name, typeof(RectTransform), typeof(Text));
            RectTransform rt = go.GetComponent<RectTransform>(); rt.SetParent(parent, false);
            rt.anchorMin = min; rt.anchorMax = max; rt.offsetMin = low; rt.offsetMax = high;
            Text text = go.GetComponent<Text>(); text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = value; text.fontSize = size; text.color = Color.white; text.alignment = align;
            text.raycastTarget = false; text.horizontalOverflow = HorizontalWrapMode.Wrap;
            return text;
        }
        private Text Button(string name, string title, Vector2 anchor, Vector2 center, Vector2 size, Action action)
        {
            RectTransform rect = Panel(name, safe, new Color(.14f, .23f, .33f), anchor, anchor, center - size / 2, center + size / 2);
            UnityEngine.UI.Button button = rect.gameObject.AddComponent<UnityEngine.UI.Button>();
            ColorBlock colors = button.colors; colors.highlightedColor = new Color(.65f, .9f, 1); colors.pressedColor = new Color(.3f, .7f, .85f); button.colors = colors;
            button.onClick.AddListener(() => { action(); Debug.Log("SC_TOUCH button=" + name); });
            controlNames.Add(name); controlRects.Add(rect);
            return Label(name + " label", rect, title, 27, Vector2.zero, Vector2.one, new Vector2(8, 6), new Vector2(-8, -6), TextAnchor.MiddleCenter);
        }
        private void BuildInterface()
        {
            Canvas canvas = new GameObject("Touch interface", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster)).GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvas.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720); scaler.matchWidthOrHeight = .5f;
            new GameObject("Touch EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            safe = new GameObject("Safe Area", typeof(RectTransform)).GetComponent<RectTransform>();
            safe.SetParent(canvas.transform, false);
            RefreshSafeArea();
            Panel("Header", safe, new Color(navy.r, navy.g, navy.b, .96f), new Vector2(0, 1), Vector2.one, new Vector2(0, -100), Vector2.zero);
            Label("Title", safe, "SIGNAL CHASE / MOBILE", 35, new Vector2(0, 1), new Vector2(1, 1), new Vector2(28, -52), new Vector2(-28, -6));
            status = Label("Status", safe, "Loading trained models...", 22, new Vector2(0, 1), Vector2.one, new Vector2(30, -91), new Vector2(-25, -53));
            instruction = Label("Instructions", safe, "", 24, Vector2.zero, new Vector2(1, 0), new Vector2(285, 20), new Vector2(-335, 120));
            RectTransform stick = Panel("Joystick", safe, new Color(.12f, .23f, .33f, .95f), Vector2.zero, Vector2.zero, new Vector2(30, 30), new Vector2(250, 250));
            RectTransform thumb = Panel("Thumb", stick, cyan, new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(-36, -36), new Vector2(36, 36));
            joystick = stick.gameObject.AddComponent<TouchJoystick>(); joystick.Thumb = thumb;
            Label("Joystick caption", stick, "MOVE TARGET", 20, Vector2.zero, Vector2.one, new Vector2(8, -21), new Vector2(-8, -185), TextAnchor.MiddleCenter);
            controlNames.Add("joystick"); controlRects.Add(stick);
            modeText = Button("mode", "MODE: TOUCH", new Vector2(1, 0), new Vector2(-170, 205), new Vector2(290, 90), () => { mode = (mode + 1) % 3; ApplyMode(); });
            pauseText = Button("pause", "PAUSE", new Vector2(1, 0), new Vector2(-245, 94), new Vector2(140, 100), TogglePause);
            Button("reset", "RESET", new Vector2(1, 0), new Vector2(-95, 94), new Vector2(140, 100), () => { joystick.Clear(); target.ManualDirection(Vector2.zero); agent.ResetRound(); resets++; });
        }
        private string ModeName => mode == 0 ? "STATIC" : mode == 1 ? "AUTO" : "TOUCH";
        private void ApplyMode()
        {
            joystick.Clear();
            target.Manual = mode == 2;
            target.Moving = mode != 0;
            if (mode == 2) target.ManualDirection(Vector2.zero);
            if (agent.gameObject.activeSelf)
            {
                agent.SetModel(mode == 0 ? "ReachTarget" : "ChaseTarget", mode == 0 ? ReachModel : ChaseModel, InferenceDevice.Burst);
                agent.TaskName = mode == 0 ? "ReachTarget" : "ChaseTarget";
                agent.ResetRound();
            }
            modeText.text = "MODE: " + ModeName;
            instruction.text = mode == 2 ? "Drag the pad to move the gold target.\nThe cyan agent uses its trained model." : mode == 0 ? "Stationary target.\nThe learned agent finds each new position." : "Moving target.\nThe learned agent follows automatically.";
            Debug.Log("SC_MODE " + ModeName);
        }
        private void TogglePause()
        {
            paused = !paused;
            Time.timeScale = paused ? 0 : 1;
            joystick.Clear();
            pauseText.text = paused ? "RESUME" : "PAUSE";
            Debug.Log("SC_PAUSE " + paused);
        }
        private void RefreshSafeArea()
        {
            previousSafeArea = Screen.safeArea;
            safe.anchorMin = new Vector2(previousSafeArea.xMin / Screen.width, previousSafeArea.yMin / Screen.height);
            safe.anchorMax = new Vector2(previousSafeArea.xMax / Screen.width, previousSafeArea.yMax / Screen.height);
            safe.offsetMin = safe.offsetMax = Vector2.zero;
        }
        private void Update()
        {
            if (safe != null && previousSafeArea != Screen.safeArea) RefreshSafeArea();
            if (mode == 2) target.ManualDirection(paused ? Vector2.zero : joystick.Direction);
            if (status != null) status.text = "PPO / CPU inference   |   " + ModeName + "   |   Captures " + agent.Successes + " / " + agent.Completed + (paused ? "   |   PAUSED" : "");
            if (Time.unscaledTime >= logAt)
            {
                logAt = Time.unscaledTime + 1;
                Debug.Log("SC_MOBILE " + JsonUtility.ToJson(new Telemetry { mode=ModeName, paused=paused, time=Time.time, agent=new[]{agent.transform.localPosition.x, agent.transform.localPosition.z}, target=new[]{target.transform.localPosition.x, target.transform.localPosition.z}, joystick=new[]{joystick.Direction.x, joystick.Direction.y}, captured=agent.Successes, completed=agent.Completed, resets=resets, gestures=joystick.Gestures, width=Screen.width, height=Screen.height }));
            }
        }
        private void LogControlPositions()
        {
            for (int i = 0; i < controlNames.Count; i++)
            {
                Vector3[] corners = new Vector3[4]; controlRects[i].GetWorldCorners(corners);
                Vector3 c = (corners[0] + corners[2]) * .5f;
                Debug.Log("SC_CONTROL " + controlNames[i] + " x=" + Mathf.RoundToInt(c.x) + " y=" + Mathf.RoundToInt(Screen.height - c.y));
            }
        }
        private void OnApplicationPause(bool background)
        {
            if (background && !paused && joystick != null) TogglePause();
        }
    }
}
