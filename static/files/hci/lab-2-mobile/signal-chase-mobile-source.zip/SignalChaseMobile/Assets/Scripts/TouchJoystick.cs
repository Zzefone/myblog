using UnityEngine;
using UnityEngine.EventSystems;

namespace SignalChase.Mobile
{
    public class TouchJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform Thumb;
        public Vector2 Direction { get; private set; }
        public int Gestures { get; private set; }
        private int activePointer = int.MinValue;
        public void OnPointerDown(PointerEventData data)
        {
            if (activePointer != int.MinValue) return;
            activePointer = data.pointerId;
            Gestures++;
            OnDrag(data);
            Debug.Log("SC_TOUCH joystick_down pointer=" + data.pointerId);
        }
        public void OnDrag(PointerEventData data)
        {
            if (data.pointerId != activePointer) return;
            RectTransform area = (RectTransform)transform;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(area, data.position, data.pressEventCamera, out Vector2 position);
            float radius = area.rect.width * .36f;
            Direction = Vector2.ClampMagnitude(position / radius, 1f);
            Thumb.anchoredPosition = Direction * radius;
        }
        public void OnPointerUp(PointerEventData data)
        {
            if (data.pointerId != activePointer) return;
            Clear();
            Debug.Log("SC_TOUCH joystick_up");
        }
        public void Clear()
        {
            Direction = Vector2.zero;
            if (Thumb != null) Thumb.anchoredPosition = Vector2.zero;
            activePointer = int.MinValue;
        }
        private void OnDisable() => Clear();
    }
}
