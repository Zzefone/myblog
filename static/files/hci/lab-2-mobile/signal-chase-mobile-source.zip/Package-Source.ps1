param([string]$Destination = "$PSScriptRoot\SignalChaseMobile-source.zip")
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
if (Test-Path -LiteralPath $Destination) { throw "Archive already exists. Pass -Destination with a new filename: $Destination" }
$files = [Collections.Generic.List[IO.FileInfo]]::new()
foreach ($directory in @('Assets','Packages','ProjectSettings')) {
    Get-ChildItem -LiteralPath "$PSScriptRoot\SignalChaseMobile\$directory" -Recurse -File | ForEach-Object { $files.Add($_) }
}
foreach ($name in @('README.md','TEST_REPORT.md','blog-draft.md','Build-Android.ps1','Use-AndroidEnvironment.ps1','Install-AndroidTools.ps1','Install-SDK.ps1','Verify-Apk.ps1','Verify-Mobile.ps1','Package-Source.ps1','Start-Emulator.ps1','Run-DesktopPreview.ps1')) {
    $files.Add((Get-Item -LiteralPath "$PSScriptRoot\$name"))
}
foreach ($name in @('apk-verification.json','apk-badging.txt','apk-manifest.txt','apk-signature.txt','component-checks.json','component-checks-editmode-failed.json','desktop-preview-checks.json','desktop-preview-status.json','desktop-preview.png')) {
    if (Test-Path -LiteralPath "$PSScriptRoot\evidence\$name") { $files.Add((Get-Item -LiteralPath "$PSScriptRoot\evidence\$name")) }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stream = [IO.File]::Open($Destination, [IO.FileMode]::CreateNew)
$archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        $entryName = $file.FullName.Substring($PSScriptRoot.Length + 1).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, $entryName, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $archive.Dispose(); $stream.Dispose() }
Get-FileHash -LiteralPath $Destination -Algorithm SHA256
