+++
title = "HCI Lab 2: Signal Chase on Android"
date = 2026-10-16
description = "Adapting a trained Unity ML-Agents application to touch controls and checking an Android build."
tags = ["HCI", "Unity", "Android", "ML-Agents", "touch interaction"]
categories = ["HCI"]
courses = ["HCI"]
draft = true
source_files = ["HCI/lab-mobile/README.md", "HCI/lab-mobile/TEST_REPORT.md", "HCI/lab-mobile/evidence/apk-verification.json"]
+++

I adapted Signal Chase for a landscape phone screen. The cyan ball uses the final trained neural policy. The player moves the gold target with a touch pad instead of the keyboard.

## Touch controls

The pad sits on the left, with large Mode, Pause and Reset buttons on the right. Releasing the pad stops the target input. Mode switches between a static target, automatic movement, and touch control.

The interface stays inside the screen's safe area. Pause stops the simulation but leaves the controls active, so Resume does not depend on the game clock.

The observations, actions and low-friction physics match the desktop experiment. The app is configured for local CPU inference with both final ONNX models, without Python or a training server.

## Build and checks

The Android build targets API 29 and later, with ARM64 and x86_64 libraries. The SDK, NDK, Java tools and virtual-device files are on D:.

The first build stopped because CMake 3.22.1 was missing. Installing Google's matching SDK package on D: resolved that prerequisite. The build scripts keep the SDK, NDK, CMake, Gradle data and temporary files on D:.

The Development APK built successfully on 16 October. Its actual size is 61,665,641 bytes (61.7 MB), with SHA-256 `39ee54327637d95b47717eed3b7282844bb70ff3802ccdfcd02954376b8df971`. Eight static checks passed: package/version, API levels, landscape launch activity, signature, both IL2CPP ABIs, Unity data and the two final source-model hashes. The libraries' ELF headers also match ARM64 and x86_64.

Android runtime acceptance was deferred at the user's request on 16 October. The earlier unaccelerated emulator attempts crashed before the guest kernel started. There is no successful Android launch, phone touch test or Android screenshot to report yet.

An optional Windows Editor Play Mode run on 17 October recorded the joystick and button observations and produced a labelled layout screenshot. The Editor crashed while disposing the inference worker on shutdown. Those observations are useful for the UI, but the preview was not a clean run and does not replace an Android test.

<!-- Local draft for blog integration. Keep any Windows preview visibly labelled. Publishing the completed APK build and static inspection is allowed; Android runtime acceptance and the whole lab are still incomplete. -->
