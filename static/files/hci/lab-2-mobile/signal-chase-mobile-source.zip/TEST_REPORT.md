# Signal Chase Mobile — build and acceptance record

APK build and static inspection: 2026-10-16 (Europe/Paris). Source packaging and optional Windows editor checks: 2026-10-17.

## Scope

The user chose to finish the Android APK first and defer Android runtime acceptance. This delivery covers the Unity source, an APK build, static package inspection and reproducible verification scripts. A static APK check cannot establish that the app launches, receives phone touches, performs well or survives the Android lifecycle.

No Android runtime test has passed on this host. There is no physical-device test, Android screenshot, performance measurement or usability study. No Windows virtualization feature, security setting or reboot was performed for this work.

## Implementation

The landscape UGUI interface contains a target joystick, MODE (STATIC / AUTO / TOUCH), PAUSE / RESUME and RESET. The canvas uses the display safe area. The pad changes target input; the trained policy controls the cyan agent. On release or disable, the joystick clears its input and centers its thumb. Pause uses unscaled UI updates so Resume remains operable.

The two common agent/target scripts are byte-identical to the final desktop experiment. The agent receives eight observations, produces two continuous actions and uses a DecisionPeriod of 5. `MaxStep` is zero; the shared code applies its own 500-physics-step episode timeout. Agent and platform use zero static/dynamic friction, matching the corrected training environment.

The included models match the final run02 PPO export:

| Source asset | SHA-256 |
| --- | --- |
| ReachTarget.onnx | `816fbb31b82516c94ca90e5a530d31aa6e2db9613ead47f997a50fb7caf93813` |
| ChaseTarget.onnx | `da21c288c6174ed28ca8766acaefef6fa3688a9e226c846b0fb82e5dd001a3ae` |

The desktop policy evaluation belongs to the ML-Agents experiment. Its scores are not mobile evaluation scores. The Android build loads both source assets as Unity `ModelAsset` objects and refuses to build if either is missing. Unity serializes them into player data; the APK check reports source-asset hashes rather than claiming the raw `.onnx` files are separate APK entries.

## Build environment

| Component | Version / location |
| --- | --- |
| Unity | 6000.0.23f1, under `D:/unity/` |
| ML-Agents | 4.0.0 |
| Unity Inference Engine | 2.2.1 |
| Java | OpenJDK 17 from the matching Unity Android module |
| Android SDK | API 35; build-tools 34.0.0 |
| NDK | r23b |
| CMake | 3.22.1, installed with Google's sdkmanager |
| Player | IL2CPP; ARM64 and x86_64; OpenGL ES 3 |
| Android compatibility | Minimum API 29; target API 35 |

Tools, downloads, SDK/NDK/CMake, Gradle user data, Java home, temporary files, virtual devices and Unity package/Burst caches used by the supplied scripts are on D:. The environment script changes only its process and children. Unity/Windows may maintain their existing application preferences independently; no new tools were installed on C:.

The earlier build attempt stopped at a genuine prerequisite error: missing `sdk/cmake/3.22.1`. The official SDK package was installed on D:, its executable reported version 3.22.1, and the build was restarted. `Install-SDK.ps1` now includes this dependency.

## APK result

Unity completed the build successfully and exited with code 0. The APK is `SignalChaseMobile/Builds/Android/SignalChaseMobile.apk`.

- Actual APK file size: **61,665,641 bytes** (61.7 MB decimal).
- SHA-256: `39ee54327637d95b47717eed3b7282844bb70ff3802ccdfcd02954376b8df971`.
- Static inspection: **8 passed, 0 failed** in `evidence/apk-verification.json`.
- Identity: `com.wangzhaofeng.signalchase`, version 1.0.0 / code 1.
- Manifest: minimum API 29, target API 35, landscape `UnityPlayerGameActivity` launch activity.
- Native libraries: ARM64 and x86_64, including both IL2CPP libraries.
- Signature: `apksigner verify` succeeded; APK Signature Scheme v2, RSA 2048-bit Android Debug certificate. This is a Unity Development build.
- Data: `boot.config`, `globalgamemanagers`, `level0` and IL2CPP `global-metadata.dat` are present.

The first inspection assumed a compressed `data.unity3d` container. This APK uses separate Unity data entries, so the initial data-layout check was a false negative. The inspector was corrected to inspect the actual supported layout; the APK did not need rebuilding. Native command output was normalized to strings so the JSON report contains complete, readable signature evidence.

The raw build log is `evidence/android-build.log`. It contains package shader warnings and the Unity-bundled Android Gradle plugin 8.3.0 warning that it was tested through compileSdk 34 while this project uses 35. These warnings did not fail the build. No package, native configuration or Windows virtualization feature was changed to suppress them. The internal Unity BuildReport total is not the APK file size above.

The inspector also reads the ELF headers directly from the archive: ELF64 little-endian machine 183 for ARM64 and machine 62 for x86_64. Both match the ABI directory names.

## Optional Windows editor observations

These observations are **not Android runtime acceptance**. The test dispatches synthetic UGUI pointer events in Windows Unity Editor Play Mode; it does not inject operating-system or Android touch input.

The first component test ran in Edit Mode and reported 7/8 passes. Its last check assumed `SetActive(false)` would invoke `OnDisable` on a normal, non-ExecuteAlways MonoBehaviour in Edit Mode. That was a test construction error. Moving the check into actual Play Mode produced 8/8 component passes, including lifecycle cleanup. Only Editor test scripts were changed; the APK runtime source and models were not changed or rebuilt for this test.

The Play Mode run recorded 13/13 interaction observations: active trained inference, target movement from the joystick, agent movement, pointer release, Pause/Resume, Reset and all three modes. It saved `evidence/desktop-preview.png` at 1920 × 1049 with a visible Windows/Android-not-tested label. These are observations from the preview, not a clean end-to-end preview pass: on exit, the Editor crashed while finalizing the Inference Engine worker (`Worker.Finalize` / `CPUTensorData.Dispose` / `JobHandle.Complete`). The process was stopped after that crash. No further optional preview attempt was made.

`evidence/desktop-preview-status.json` records that limitation; the individual component and interaction JSON files retain their measured results. The failed Edit Mode component JSON is retained separately. The screenshot is a genuine Windows capture and cannot establish Android rendering, Android lifecycle behavior or phone usability.

## Deferred Android runtime checks

Previous unaccelerated official emulator attempts failed before the Linux guest kernel started. Versions 37.2.12 and 35.2.10, host and software graphics, single/dual-core and CPU settings were tried; the process exited with Windows access violation `0xc0000005`. This is not a successful emulator boot. Relevant logs remain under `evidence/` and the Android tools logs directory.

The APK has not been installed on a working Android device. The following acceptance checks remain unperformed: startup and ONNX inference on Android; real touch dispatch and joystick release; STATIC/AUTO/TOUCH switching; Pause/Resume and Reset; relaunch/background handling; safe-area behavior on a real display; frame rate, thermal behavior and user evaluation.

When the user resumes acceptance, connect an authorized Android 10+ ARM64 phone and run `Verify-Mobile.ps1 -Serial DEVICE_SERIAL`. It records actual Android screenshots, logcat and individual checks in `evidence/verification.json`. The README gives the setup commands. A working emulator can also be used, but its evidence must remain labelled as emulator evidence.

## Source delivery

The source package includes only Unity Assets/Packages/ProjectSettings, project scripts, this report and selected inspection evidence. SDKs, downloads, caches, `Library`, `Temp`, builds, debug keystores, virtual-device disks, user settings and teacher course materials are excluded. The APK is supplied separately from the source archive.
