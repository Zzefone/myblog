$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\1_VAR_blog\HCI\tools\android'
$env:TEMP = "$taskRoot\temp"
$env:TMP = $env:TEMP
$env:ANDROID_USER_HOME = "$taskRoot\user-home"
$env:ANDROID_EMULATOR_HOME = "$taskRoot\emulator-home"
$env:ANDROID_AVD_HOME = "$taskRoot\avd"
$env:ANDROID_SDK_ROOT = "$taskRoot\sdk"
$env:GRADLE_USER_HOME = "$taskRoot\gradle"
$env:JAVA_TOOL_OPTIONS = "-Duser.home=$taskRoot\java-home -Djava.io.tmpdir=$taskRoot\temp"
foreach ($taskPath in @($taskRoot, $env:TEMP, $env:ANDROID_USER_HOME, $env:ANDROID_EMULATOR_HOME, $env:ANDROID_AVD_HOME, $env:ANDROID_SDK_ROOT, $env:GRADLE_USER_HOME, "$taskRoot\downloads", "$taskRoot\java-home")) {
    New-Item -ItemType Directory -Path $taskPath -Force | Out-Null
}
$modules = Get-Content 'D:\unity\6000.0.23f1\modules.json' -Raw | ConvertFrom-Json -AsHashtable
$androidModule = $modules | Where-Object id -eq android
$selection = @($androidModule, $androidModule.subModules[0], ($androidModule.subModules[1].subModules | Where-Object id -eq 'android-ndk-r23b'), ($androidModule.subModules[1].subModules | Where-Object id -eq 'android-sdk-command-line-tools-6.0'))
$selection | ForEach-Object -Parallel {
    $part = $_
    $suffix = if ($part.type -eq 'EXE') { '.exe' } else { '.zip' }
    $downloadPath = "D:\1_VAR_blog\HCI\tools\android\downloads\$($part.id)$suffix"
    $expectedBytes = @{android=459944840; 'android-open-jdk-17.0.9+9'=117700264; 'android-ndk-r23b'=788638042; 'android-sdk-command-line-tools-6.0'=119629490}[$part.id]
    if (-not (Test-Path -LiteralPath $downloadPath) -or (Get-Item -LiteralPath $downloadPath).Length -ne $expectedBytes) {
        & 'C:\Windows\System32\curl.exe' --silent --show-error --location --fail --retry 5 --retry-all-errors --connect-timeout 30 --continue-at - --output $downloadPath $part.url
        if ($LASTEXITCODE -ne 0) { throw "Download failed: $($part.id)" }
    }
    if ((Get-Item -LiteralPath $downloadPath).Length -ne $expectedBytes) { throw "Incomplete download: $($part.id)" }
    [PSCustomObject]@{ id=$part.id; file=$downloadPath; bytes=(Get-Item -LiteralPath $downloadPath).Length }
} -ThrottleLimit 4
$installerPath = "$taskRoot\downloads\android.exe"
$expectedMd5 = [Text.Encoding]::ASCII.GetString([Convert]::FromBase64String($androidModule.integrity.Substring(4)))
$actualMd5 = (Get-FileHash -LiteralPath $installerPath -Algorithm MD5).Hash.ToLowerInvariant()
if ($actualMd5 -ne $expectedMd5) { throw "Android support checksum mismatch: $actualMd5" }
$signature = Get-AuthenticodeSignature -LiteralPath $installerPath
if ($signature.Status -ne 'Valid') { throw "Invalid Unity installer signature: $($signature.Status)" }
Write-Output "Unity support installer verified: $actualMd5 / $($signature.SignerCertificate.Subject)"
$installProcess = Start-Process -FilePath $installerPath -ArgumentList '/S','/D=D:\unity\6000.0.23f1' -WindowStyle Hidden -Wait -PassThru
if ($installProcess.ExitCode -ne 0) { throw "Unity support installer exit $($installProcess.ExitCode)" }
$androidPlayer = 'D:\unity\6000.0.23f1\Editor\Data\PlaybackEngines\AndroidPlayer'
Expand-Archive -LiteralPath "$taskRoot\downloads\android-open-jdk-17.0.9+9.zip" -DestinationPath "$androidPlayer\OpenJDK" -Force -ErrorAction Stop
Expand-Archive -LiteralPath "$taskRoot\downloads\android-ndk-r23b.zip" -DestinationPath "$taskRoot\ndk" -Force -ErrorAction Stop
Expand-Archive -LiteralPath "$taskRoot\downloads\android-sdk-command-line-tools-6.0.zip" -DestinationPath "$taskRoot\cmdline-extract" -Force -ErrorAction Stop
New-Item -ItemType Directory -Path "$taskRoot\sdk\cmdline-tools" -Force | Out-Null
if (-not (Test-Path -LiteralPath "$taskRoot\sdk\cmdline-tools\6.0")) {
    $commandLineSource = [IO.Path]::GetFullPath("$taskRoot\cmdline-extract\cmdline-tools")
    $commandLineDestination = [IO.Path]::GetFullPath("$taskRoot\sdk\cmdline-tools\6.0")
    $validatedRoot = [IO.Path]::GetFullPath($taskRoot).TrimEnd('\') + '\'
    if (-not $commandLineSource.StartsWith($validatedRoot, [StringComparison]::OrdinalIgnoreCase) -or -not $commandLineDestination.StartsWith($validatedRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The command-line tools move must remain inside the D: Android tools directory.'
    }
    Move-Item -LiteralPath $commandLineSource -Destination $commandLineDestination
}
Get-ChildItem -LiteralPath "$androidPlayer\OpenJDK" | Select-Object Name
if (-not (Test-Path -LiteralPath "$taskRoot\ndk\android-ndk-r23b\source.properties")) { throw 'NDK extraction did not complete.' }
Write-Output 'Android engine, OpenJDK, NDK and command-line tools installed on D:.'
