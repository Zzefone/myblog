$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
$env:UPM_CACHE_ROOT = 'D:\1_VAR_blog\HCI\tools\unity-cache\upm'
$env:BURST_CACHE_PATH = 'D:\1_VAR_blog\HCI\tools\unity-cache\burst'
New-Item -ItemType Directory -Path "$PSScriptRoot\evidence" -Force | Out-Null
if (Test-Path -LiteralPath "$PSScriptRoot\evidence\android-build.log") {
    $previousBuildLog = "$PSScriptRoot\evidence\android-build-before-$(Get-Date -Format 'yyyyMMdd-HHmmss-fff').log"
    Copy-Item -LiteralPath "$PSScriptRoot\evidence\android-build.log" -Destination $previousBuildLog
}
$unityEditor = 'D:\unity\6000.0.23f1\Editor\Unity.exe'
$unityArguments = @('-batchmode', '-nographics', '-quit', '-projectPath', "$PSScriptRoot\SignalChaseMobile", '-buildTarget', 'Android', '-job-worker-count', '2', '-executeMethod', 'MobileProjectBuilder.BuildAndroid', '-logFile', "$PSScriptRoot\evidence\android-build.log")
$unityProcess = Start-Process -FilePath $unityEditor -ArgumentList $unityArguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -Wait
if ($unityProcess.ExitCode -ne 0) { throw "Android Unity build exited $($unityProcess.ExitCode). See evidence/android-build.log." }
Get-FileHash -LiteralPath "$PSScriptRoot\SignalChaseMobile\Builds\Android\SignalChaseMobile.apk" -Algorithm SHA256
