$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
New-Item -ItemType Directory -Path "$PSScriptRoot\evidence" -Force | Out-Null
$avdManager = "$env:ANDROID_HOME\cmdline-tools\6.0\bin\avdmanager.bat"
if (-not (Test-Path -LiteralPath "$env:ANDROID_AVD_HOME\SignalChase_API29.avd\config.ini")) {
    'no' | & $avdManager create avd --force --name SignalChase_API29 --package 'system-images;android-29;default;x86_64' --device pixel_2 --path "$env:ANDROID_AVD_HOME\SignalChase_API29.avd"
    if ($LASTEXITCODE -ne 0) { throw 'AVD creation failed.' }
}
$emulator = "$taskAndroidRoot\emulator-35.2.10\emulator\emulator.exe"
$arguments = @('-avd', 'SignalChase_API29', '-no-window', '-no-audio', '-no-boot-anim', '-no-snapshot', '-no-metrics', '-show-kernel', '-accel', 'off', '-gpu', 'swiftshader_indirect', '-feature', '-Vulkan', '-memory', '1536', '-cores', '2', '-skin', '1280x720', '-camera-back', 'none', '-camera-front', 'none', '-timezone', 'Europe/Paris')
$emulatorProcess = Start-Process -FilePath $emulator -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -Wait -RedirectStandardOutput "$PSScriptRoot\evidence\emulator.log" -RedirectStandardError "$PSScriptRoot\evidence\emulator.err.log"
$emulatorProcess | Select-Object Id,ProcessName
if ($emulatorProcess.ExitCode -ne 0) { throw "Emulator exited $($emulatorProcess.ExitCode). Check evidence/emulator.log and emulator.err.log." }
Write-Output 'Headless API 29 emulator launched. Use adb -s emulator-5554 shell getprop sys.boot_completed to check readiness.'
