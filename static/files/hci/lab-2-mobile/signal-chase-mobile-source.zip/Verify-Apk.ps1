param([string]$Apk = "$PSScriptRoot\SignalChaseMobile\Builds\Android\SignalChaseMobile.apk")
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
if (-not (Test-Path -LiteralPath $Apk)) { throw "APK is missing: $Apk" }
$evidencePath = "$PSScriptRoot\evidence"
New-Item -ItemType Directory -Path $evidencePath -Force | Out-Null
$checks = [Collections.Generic.List[object]]::new()
function Check($name, $passed, $detail) {
    $checks.Add([ordered]@{ name=$name; passed=[bool]$passed; detail=$detail })
    Write-Host "$name : $passed"
}
$buildTools = "$env:ANDROID_HOME\build-tools\34.0.0"
$badging = @(& "$buildTools\aapt.exe" dump badging $Apk 2>&1 | ForEach-Object { $_.ToString() })
if ($LASTEXITCODE -ne 0) { throw 'aapt could not inspect the APK.' }
$badging | Set-Content -LiteralPath "$evidencePath\apk-badging.txt" -Encoding utf8
$badgingText = $badging -join "`n"
$manifest = @(& "$buildTools\aapt.exe" dump xmltree $Apk AndroidManifest.xml 2>&1 | ForEach-Object { $_.ToString() })
if ($LASTEXITCODE -ne 0) { throw 'aapt could not read the packaged manifest.' }
$manifest | Set-Content -LiteralPath "$evidencePath\apk-manifest.txt" -Encoding utf8
$manifestText = $manifest -join "`n"
Check 'Application identifier and version' ($badgingText -match "package: name='com.wangzhaofeng.signalchase' versionCode='1' versionName='1.0.0'") ($badging | Select-Object -First 1)
Check 'Minimum API 29 and target API 35' ($badgingText -match "sdkVersion:'29'" -and $badgingText -match "targetSdkVersion:'35'") ($badging | Where-Object { $_ -match 'sdkVersion|targetSdkVersion' })
Check 'Landscape Unity launch activity' ($badgingText -match "launchable-activity: name='com.unity3d.player.UnityPlayer(Game)?Activity'" -and $manifestText -match 'android:screenOrientation[^\r\n]*\(type 0x10\)0x0\b') @{activity=($badging | Where-Object { $_ -match 'launchable-activity' }); orientation=($manifest | Where-Object { $_ -match 'screenOrientation' })}
$signature = @(& "$buildTools\apksigner.bat" verify --verbose --print-certs $Apk 2>&1 | ForEach-Object { $_.ToString() })
$signatureExit = $LASTEXITCODE
$signature | Set-Content -LiteralPath "$evidencePath\apk-signature.txt" -Encoding utf8
Check 'Android APK signature verifies' ($signatureExit -eq 0) $signature
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($Apk)
try {
    $entries = @($archive.Entries | ForEach-Object FullName)
    $libraries = @($entries | Where-Object { $_ -like 'lib/*/*.so' })
    $abis = @($libraries | ForEach-Object { ($_ -split '/')[1] } | Sort-Object -Unique)
    $elfHeaders = foreach ($expected in @(@{abi='arm64-v8a';machine=183}, @{abi='x86_64';machine=62})) {
        $entryName = "lib/$($expected.abi)/libil2cpp.so"
        $entry = $archive.GetEntry($entryName)
        $valid = $false
        $machine = -1
        if ($entry) {
            $reader = [IO.BinaryReader]::new($entry.Open())
            try {
                $header = $reader.ReadBytes(20)
                if ($header.Length -eq 20) {
                    $machine = [int]$header[18] + 256 * [int]$header[19]
                    $valid = ($header[0] -eq 127 -and $header[1] -eq 69 -and $header[2] -eq 76 -and $header[3] -eq 70 -and $header[4] -eq 2 -and $header[5] -eq 1 -and $machine -eq $expected.machine)
                }
            } finally { $reader.Dispose() }
        }
        [ordered]@{entry=$entryName; elf_class=64; machine=$machine; valid=$valid}
    }
    Check 'ARM64 and x86_64 IL2CPP native libraries' (($abis.Count -eq 2) -and ($abis -contains 'arm64-v8a') -and ($abis -contains 'x86_64') -and @($elfHeaders | Where-Object { -not $_.valid }).Count -eq 0) @{libraries=$libraries; elf_headers=$elfHeaders}
    $sceneDataPresent = ($entries -contains 'assets/bin/Data/data.unity3d') -or (($entries -contains 'assets/bin/Data/globalgamemanagers') -and ($entries -contains 'assets/bin/Data/level0'))
    Check 'Unity scene data and IL2CPP metadata are present' (($entries -contains 'assets/bin/Data/boot.config') -and ($entries -contains 'assets/bin/Data/Managed/Metadata/global-metadata.dat') -and $sceneDataPresent) ($entries | Where-Object { $_ -match 'boot.config|global-metadata.dat|data.unity3d|globalgamemanagers$|level0$' })
} finally { $archive.Dispose() }
$models = @(
    @{name='ReachTarget.onnx'; expected='816fbb31b82516c94ca90e5a530d31aa6e2db9613ead47f997a50fb7caf93813'},
    @{name='ChaseTarget.onnx'; expected='da21c288c6174ed28ca8766acaefef6fa3688a9e226c846b0fb82e5dd001a3ae'}
)
$modelHashes = foreach ($model in $models) {
    $actual = (Get-FileHash -LiteralPath "$PSScriptRoot\SignalChaseMobile\Assets\Models\$($model.name)" -Algorithm SHA256).Hash.ToLowerInvariant()
    Check "Final trained source model: $($model.name)" ($actual -eq $model.expected) $actual
    [ordered]@{name=$model.name; sha256=$actual}
}
$report = [ordered]@{
    environment='Static Android APK inspection; no Android device execution'
    inspected_at=(Get-Date).ToString('o')
    android_runtime_acceptance='Deferred by the user on 2026-10-16; not performed'
    apk=[ordered]@{path=$Apk; bytes=(Get-Item -LiteralPath $Apk).Length; sha256=(Get-FileHash -LiteralPath $Apk -Algorithm SHA256).Hash.ToLowerInvariant()}
    source_models=$modelHashes
    checks=$checks
    passed=@($checks | Where-Object passed).Count
    failed=@($checks | Where-Object { -not $_.passed }).Count
}
$report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$evidencePath\apk-verification.json" -Encoding utf8
if ($report.failed -gt 0) { throw "APK inspection failed: $($report.failed) checks. See evidence/apk-verification.json." }
[pscustomobject]$report | Select-Object environment,passed,failed | Format-List
