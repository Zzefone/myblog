param([string]$Serial = '')
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
$adb = "$env:ANDROID_HOME\platform-tools\adb.exe"
$apk = "$PSScriptRoot\SignalChaseMobile\Builds\Android\SignalChaseMobile.apk"
$package = 'com.wangzhaofeng.signalchase'
$evidence = "$PSScriptRoot\evidence"
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
if (-not $Serial) {
    $connected = @(& $adb devices | Where-Object { $_ -match '^\S+\s+device$' } | ForEach-Object { ($_ -split '\s+')[0] })
    if ($connected.Count -ne 1) { throw 'Connect one authorized Android device, or pass -Serial from adb devices. Android runtime acceptance is currently deferred.' }
    $Serial = $connected[0]
}
if (-not (Test-Path -LiteralPath $apk)) { throw 'Build the APK first with Build-Android.ps1.' }
$checks = [Collections.Generic.List[object]]::new()
function Device { & $adb -s $Serial @args }
function State {
    $records = Device logcat -d -s Unity:I '*:S'
    $match = $records | Where-Object { $_ -match 'SC_MOBILE \{' } | Select-Object -Last 1
    if (-not $match) { throw 'No runtime telemetry received from the Android application.' }
    return ($match.Substring($match.IndexOf('{')) | ConvertFrom-Json)
}
function Check($name, $passed, $details) {
    $checks.Add([ordered]@{name=$name; passed=[bool]$passed; details=$details})
    Write-Output "$name : $passed"
}
function Capture($name) {
    Device shell screencap -p /sdcard/signal-chase-verification.png | Out-Null
    Device pull /sdcard/signal-chase-verification.png "$evidence\$name.png" | Out-Null
}
function TapControl($name) {
    $line = Device logcat -d -s Unity:I '*:S' | Where-Object { $_ -match "SC_CONTROL $name x=(\d+) y=(\d+)" } | Select-Object -Last 1
    if (-not $line -or $line -notmatch "SC_CONTROL $name x=(\d+) y=(\d+)") { throw "Control $name not found." }
    Device shell input tap $Matches[1] $Matches[2] | Out-Null
    Start-Sleep -Seconds 5
}
$deviceState = Device get-state 2>&1
if ($LASTEXITCODE -ne 0 -or ($deviceState -join '').Trim() -ne 'device') { throw "Android device $Serial is unavailable or unauthorized." }
$booted = (Device shell getprop sys.boot_completed).Trim()
if ($booted -ne '1') { throw 'Android has not finished booting.' }
Device install -r $apk
if ($LASTEXITCODE -ne 0) { throw 'APK installation failed.' }
Device logcat -c
Device shell monkey -p $package -c android.intent.category.LAUNCHER 1 | Out-Null
Start-Sleep -Seconds 20
$initial = State
Check 'Android Unity app started with trained ONNX policy' ($initial.policy -eq 'trained_onnx' -and $initial.mode -eq 'TOUCH') $initial
Capture '01-touch-mode'
$line = Device logcat -d -s Unity:I '*:S' | Where-Object { $_ -match 'SC_CONTROL joystick x=(\d+) y=(\d+)' } | Select-Object -Last 1
if (-not $line -or $line -notmatch 'SC_CONTROL joystick x=(\d+) y=(\d+)') { throw 'Joystick screen position missing.' }
$jx = [int]$Matches[1]; $jy = [int]$Matches[2]
Device shell input swipe $jx $jy ($jx + 85) ($jy - 55) 2500 | Out-Null
Start-Sleep -Seconds 5
$released = State
$touchLog = Device logcat -d -s Unity:I '*:S'
Check 'Real Android touch gesture reached the joystick' ($released.gestures -gt $initial.gestures -and ($touchLog -match 'SC_TOUCH joystick_down')) @{before=$initial;after=$released}
Check 'Joystick returns to zero after release' (($released.joystick[0] -eq 0) -and ($released.joystick[1] -eq 0)) $released.joystick
Capture '02-after-touch'
TapControl 'pause'
$paused = State
Start-Sleep -Seconds 5
$still = State
Check 'Pause stops game time and world movement' ($paused.paused -and $still.paused -and [Math]::Abs($still.time - $paused.time) -lt .001 -and [Math]::Abs($still.target[0] - $paused.target[0]) -lt .001 -and [Math]::Abs($still.target[1] - $paused.target[1]) -lt .001) @{before=$paused;after=$still}
Capture '03-paused'
TapControl 'pause'
$resumed = State
Check 'Resume restarts game time' (-not $resumed.paused -and $resumed.time -gt $still.time) $resumed
$beforeReset = $resumed.resets
TapControl 'reset'
$reset = State
Check 'Reset button restarts the round' ($reset.resets -eq ($beforeReset + 1)) $reset
TapControl 'mode'
$static = State
Check 'Static mode can be selected by touch' ($static.mode -eq 'STATIC') $static
Capture '04-static-mode'
TapControl 'mode'
$auto = State
Check 'Automatic moving-target mode can be selected by touch' ($auto.mode -eq 'AUTO') $auto
Capture '05-auto-mode'
TapControl 'mode'
$touch = State
Check 'Touch mode can be restored' ($touch.mode -eq 'TOUCH') $touch
Device shell am force-stop $package | Out-Null
Device shell monkey -p $package -c android.intent.category.LAUNCHER 1 | Out-Null
Start-Sleep -Seconds 20
$restart = State
Check 'App relaunches with trained inference enabled' ($restart.policy -eq 'trained_onnx' -and $restart.mode -eq 'TOUCH' -and $restart.resets -eq 0) $restart
Capture '06-relaunched'
Device logcat -d | Set-Content -LiteralPath "$evidence\android-logcat.txt" -Encoding utf8
$fatal = Device logcat -d | Select-String 'FATAL EXCEPTION|SC_MOBILE_ERROR|NullReferenceException|Failed to load.*onnx|Model.*not compatible'
Check 'No fatal application or missing-model error' ($null -eq $fatal) ($fatal | ForEach-Object ToString)
$isEmulator = ((Device shell getprop ro.kernel.qemu) -join '').Trim() -eq '1'
$platform = if ($isEmulator) { 'Android emulator (not a physical device)' } else { 'Physical Android device' }
$report = [ordered]@{platform=$platform; serial=$Serial; package=$package; device_model=((Device shell getprop ro.product.model) -join '').Trim(); apk_sha256=(Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash; checks=$checks; passed=($checks|Where-Object passed).Count; failed=($checks|Where-Object {-not $_.passed}).Count}
$report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$evidence\verification.json" -Encoding utf8
[pscustomobject]$report | Select-Object platform,passed,failed | Format-List
if ($report.failed -gt 0) { throw "Mobile verification failed: $($report.failed) checks." }
