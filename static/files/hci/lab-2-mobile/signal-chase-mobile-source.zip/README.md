# Signal Chase Mobile — HCI Lab 2

An Android touch adaptation of the ML-Agents Signal Chase project. The cyan ball is controlled by the trained PPO neural policy. The player moves the gold target with a touch joystick; the joystick does not drive the agent directly.

## Interaction

- Landscape layout with a screen-safe-area canvas.
- A large bottom-left pad moves the target. Releasing it returns the input to zero.
- MODE cycles between a stationary target, automatic target motion, and touch control.
- PAUSE/RESUME freezes and restores the simulation. RESET starts another round.
- The same eight observations, two continuous actions, physics settings, and trained models as the desktop experiment are used. CPU inference works without Python or a network connection.

## Project

Open `SignalChaseMobile` in Unity 6000.0.23f1. Packages are locked to ML-Agents 4.0.0 and Unity Inference Engine 2.2.1. The runtime scene is `Assets/Scenes/SignalChaseMobile.unity`.

The scene builder creates a 10 × 10 platform and a 0.7-unit ball. Ball mass is 1, linear damping 2.5, angular damping 0.4, and rotation is frozen. Agent action acceleration is 14; planar speed is capped at 4.5. The ball and platform share a zero-static/zero-dynamic-friction material, matching the training environment.

The final run02 PPO model assets are included in `SignalChaseMobile/Assets/Models/ReachTarget.onnx` and `ChaseTarget.onnx`. Their SHA-256 values match the completed desktop experiment; `Verify-Apk.ps1` checks both. The build refuses to run if either model is missing.

| Model | SHA-256 |
| --- | --- |
| ReachTarget | `816fbb31b82516c94ca90e5a530d31aa6e2db9613ead47f997a50fb7caf93813` |
| ChaseTarget | `da21c288c6174ed28ca8766acaefef6fa3688a9e226c846b0fb82e5dd001a3ae` |

## Android tools and build

All newly installed tools, downloaded archives, SDK/NDK packages, virtual-device disks, Gradle data, Java user files, and temporary files are on D:. `Use-AndroidEnvironment.ps1` sets the paths for this shell and its child processes; it does not modify system-wide environment variables.

1. Run `Install-AndroidTools.ps1` to install the matching Android editor module, OpenJDK 17, NDK r23b, and command-line tools. This downloads official Unity/Google files and verifies the Unity installer checksum/signature.
2. Run `Install-SDK.ps1` after accepting the SDK licences. The script uses the API 35 platform, build-tools 34.0.0 and CMake 3.22.1. `-IncludeEmulator` additionally downloads an emulator and an API 29 x86_64 system image; the image archive is checked against Google's repository SHA-1.
3. Run `Build-Android.ps1`. The APK target is Android 10/API 29 or later, with ARM64 and x86_64 IL2CPP libraries and OpenGL ES 3 graphics.
4. Run `Verify-Apk.ps1` for signature, manifest, native-library and source-model checks. The results are saved in `evidence/apk-verification.json`. These checks do not execute Android code.

The delivered Development APK is 61,665,641 bytes. SHA-256: `39ee54327637d95b47717eed3b7282844bb70ff3802ccdfcd02954376b8df971`. Static inspection passed all eight checks; Android runtime acceptance remains deferred.

## Runtime acceptance: deferred

On 2026-10-16, the user chose to finish the APK first and defer Android runtime acceptance. There are no successful Android launch, touch, performance or phone usability results in this delivery. No Windows virtualization features or security settings were changed.

The unaccelerated emulator attempts on this Windows host crashed before the guest kernel started. Both emulator versions and several graphics/CPU settings were tried; retained logs document the failure. Do not treat `Start-Emulator.ps1` as a validated path on this host.

When runtime acceptance resumes, use an Android 10+ ARM64 device with USB debugging enabled. Connect the phone, accept its debugging prompt, then run the following from this directory:

```powershell
. .\Use-AndroidEnvironment.ps1
adb devices
.\Verify-Mobile.ps1 -Serial 'DEVICE_SERIAL'
```

The verification script installs the APK, sends Android touch gestures, checks joystick release, Mode, Pause/Resume, Reset and relaunch, and saves actual screenshots plus logcat to `evidence/`. Read the resulting `verification.json` before claiming these checks passed. Allow app installation and keep the phone unlocked during the test. The same script can later use a working emulator serial; it identifies emulator evidence separately.

The private debug signing key is tool-generated under the D: Java/Android user directory. Do not include it in source submissions. Do not distribute `Library`, `Temp`, the SDK, or virtual-device disks with the Unity source.

## Evidence

`TEST_REPORT.md` and `evidence/apk-verification.json` describe the completed scope. An absent `evidence/verification.json` means Android runtime checks have not run. Any Windows preview is labelled as such and cannot substitute for Android evidence.

An optional Windows Editor Play Mode run captured `evidence/desktop-preview.png` and recorded eight component checks plus thirteen interaction observations. The Editor then crashed during Inference Engine worker disposal on shutdown, so this is not a clean preview pass. `evidence/desktop-preview-status.json` and the report preserve this distinction. Its pointer input was synthetic UGUI dispatch, not Android touch. Runtime source and the delivered APK were not changed for the preview.

`SignalChaseMobile-source.zip` contains the Unity `Assets`, `Packages`, `ProjectSettings`, build/verification scripts and report. It excludes `Library`, `Temp`, builds, SDK/NDK downloads, Gradle data, virtual devices, the debug keystore and teacher course materials. `Package-Source.ps1 -Destination NEW_ARCHIVE.zip` creates another archive without overwriting the previous delivery.
