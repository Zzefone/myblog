$taskAndroidRoot = 'D:\1_VAR_blog\HCI\tools\android'
$env:TEMP = "$taskAndroidRoot\temp"
$env:TMP = $env:TEMP
$env:ANDROID_HOME = "$taskAndroidRoot\sdk"
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
$env:ANDROID_SDK_HOME = "$taskAndroidRoot\java-home"
$env:ANDROID_USER_HOME = "$taskAndroidRoot\java-home\.android"
$env:ANDROID_EMULATOR_HOME = $env:ANDROID_USER_HOME
$env:ANDROID_AVD_HOME = "$taskAndroidRoot\avd"
$env:GRADLE_USER_HOME = "$taskAndroidRoot\gradle"
$env:JAVA_HOME = 'D:\unity\6000.0.23f1\Editor\Data\PlaybackEngines\AndroidPlayer\OpenJDK'
$env:JAVA_TOOL_OPTIONS = "-Duser.home=$taskAndroidRoot\java-home -Djava.io.tmpdir=$taskAndroidRoot\temp"
$env:ANDROID_I_WANT_MY_TCG = 'yes'
$env:ANDROID_NDK_ROOT = "$taskAndroidRoot\ndk\android-ndk-r23b"
foreach ($taskPath in @($env:TEMP, $env:ANDROID_SDK_HOME, $env:ANDROID_USER_HOME, $env:ANDROID_EMULATOR_HOME, $env:ANDROID_AVD_HOME, $env:GRADLE_USER_HOME, "$taskAndroidRoot\java-home")) {
    New-Item -ItemType Directory -Path $taskPath -Force | Out-Null
}
$env:PATH = "$env:JAVA_HOME\bin;$env:ANDROID_HOME\platform-tools;$env:ANDROID_HOME\emulator;$env:ANDROID_HOME\cmdline-tools\6.0\bin;$env:PATH"
