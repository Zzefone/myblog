$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
$env:UPM_CACHE_ROOT = 'D:\1_VAR_blog\HCI\tools\unity-cache\upm'
$env:BURST_CACHE_PATH = 'D:\1_VAR_blog\HCI\tools\unity-cache\burst'
$editor = 'D:\unity\6000.0.23f1\Editor\Unity.exe'
$arguments = @('-batchmode', '-projectPath', "$PSScriptRoot\SignalChaseMobile", '-buildTarget', 'Android', '-job-worker-count', '2', '-executeMethod', 'MobileDesktopPreview.Run', '-logFile', "$PSScriptRoot\evidence\desktop-preview.log")
$previewProcess = Start-Process -FilePath $editor -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -Wait
if ($previewProcess.ExitCode -ne 0) { throw "Windows editor preview exited $($previewProcess.ExitCode). See evidence/desktop-preview.log." }
Get-Content -LiteralPath "$PSScriptRoot\evidence\desktop-preview-checks.json" -Raw
