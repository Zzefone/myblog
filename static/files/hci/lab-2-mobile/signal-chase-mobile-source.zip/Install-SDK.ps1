param([switch]$IncludeEmulator)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Use-AndroidEnvironment.ps1"
$sdkManager = "$env:ANDROID_HOME\cmdline-tools\6.0\bin\sdkmanager.bat"
$licenseAnswers = 1..100 | ForEach-Object { 'y' }
$licenseAnswers | & $sdkManager --sdk_root=$env:ANDROID_HOME --licenses
if ($LASTEXITCODE -ne 0) { throw 'SDK license acceptance failed.' }
& $sdkManager --sdk_root=$env:ANDROID_HOME 'platform-tools' 'platforms;android-35' 'build-tools;34.0.0' 'cmake;3.22.1'
if ($LASTEXITCODE -ne 0) { throw 'SDK package installation failed.' }
if (-not $IncludeEmulator) { return }
& $sdkManager --sdk_root=$env:ANDROID_HOME 'emulator'
if ($LASTEXITCODE -ne 0) { throw 'Emulator package installation failed.' }
$repositoryFile = "$taskAndroidRoot\downloads\sys-img2-1.xml"
& 'C:\Windows\System32\curl.exe' --silent --show-error --location --fail --output $repositoryFile 'https://dl.google.com/android/repository/sys-img/android/sys-img2-1.xml'
if ($LASTEXITCODE -ne 0) { throw 'Google system-image metadata download failed.' }
$repository = [xml](Get-Content -LiteralPath $repositoryFile -Raw)
$systemPackage = $repository.SelectSingleNode("//*[@path='system-images;android-29;default;x86_64']")
$archive = $systemPackage.archives.archive | Where-Object { $_.'host-os' -eq 'windows' }
$archiveFile = "$taskAndroidRoot\downloads\$($archive.complete.url)"
if (-not (Test-Path -LiteralPath $archiveFile) -or (Get-Item -LiteralPath $archiveFile).Length -ne [long]$archive.complete.size) {
    & 'C:\Windows\System32\curl.exe' --silent --show-error --location --fail --retry 5 --retry-all-errors --continue-at - --output $archiveFile "https://dl.google.com/android/repository/sys-img/android/$($archive.complete.url)"
    if ($LASTEXITCODE -ne 0) { throw 'Google system-image download failed.' }
}
$actualImageSha1 = (Get-FileHash -LiteralPath $archiveFile -Algorithm SHA1).Hash
if ($actualImageSha1 -ne [string]$archive.complete.checksum) { throw 'Google system-image checksum mismatch.' }
Expand-Archive -LiteralPath $archiveFile -DestinationPath "$env:ANDROID_HOME\system-images\android-29\default" -Force -ErrorAction Stop
& "$env:ANDROID_HOME\emulator\emulator.exe" -accel-check
Write-Output 'SDK and API 29 emulator files are installed on D:.'
