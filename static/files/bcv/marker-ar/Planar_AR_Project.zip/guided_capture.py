"""User-guided physical test. This is an app window, not screen automation."""
from pathlib import Path
from datetime import datetime
from dataclasses import asdict
import csv,json,time
import tkinter as tk
import cv2
from PIL import Image,ImageTk
from ar_core import PlanarAR,Settings,read_image,write_image

ROOT=Path(__file__).resolve().parent
STAGES=[
 ('frontal','正面：整张参考图可见，保持稳定'),
 ('tilt','倾斜：手机向左或向右倾斜约 30 度，保持图片可见'),
 ('rotation','旋转：把手机在画面内转一个角度，保持稳定'),
 ('dim','变暗：降低手机屏幕亮度，继续展示图片'),
 ('occlusion_25','恢复亮度：用手遮住参考图约四分之一'),
 ('occlusion_50','遮挡：用手遮住参考图约一半，其余部分可见'),
 ('clutter','复杂背景：取消遮挡，把手机移到较杂乱的背景前'),
 ('absent','无参考图：把手机完全移出摄像头画面')]


def main():
    target=ROOT/'output'/'private'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-guided')
    target.mkdir(parents=True,exist_ok=True)
    root=tk.Tk()
    root.title('BCV 摄像头测试 — 按提示操作手机')
    root.geometry('1120x740')
    instruction=tk.Label(root,text='请准备：手机横屏显示参考图，面向摄像头',font=('Microsoft YaHei',20),wraplength=1080)
    instruction.pack(pady=16)
    countdown=tk.Label(root,text='正在打开摄像头……',font=('Microsoft YaHei',16))
    countdown.pack(pady=5)
    panel=tk.Label(root)
    panel.pack(expand=True)
    stats=tk.Label(root,text='只在本地保存。结束后自动关闭摄像头。',font=('Microsoft YaHei',12))
    stats.pack(pady=10)
    alive=[True]
    root.protocol('WM_DELETE_WINDOW',lambda:alive.__setitem__(0,False))
    root.update()
    cap=cv2.VideoCapture(0,cv2.CAP_DSHOW)
    engine=PlanarAR(read_image(ROOT/'assets'/'marker.png'),read_image(ROOT/'assets'/'substitute.png'),Settings())
    if not cap.isOpened():
        root.destroy()
        raise RuntimeError('Camera 0 unavailable')
    writer=None
    rows=[]
    best={}
    start=time.perf_counter()
    try:
        while alive[0]:
            elapsed=time.perf_counter()-start
            if elapsed>=84: break
            ok,frame=cap.read()
            if not ok: break
            if elapsed<4:
                instruction.configure(text='准备：手机正对摄像头，整张参考图可见')
                countdown.configure(text=f'{4-int(elapsed)} 秒后开始；第一段保持正面')
                result=engine.process(frame,debug=False)
            else:
                stage_index=min(7,int((elapsed-4)//10))
                stage,description=STAGES[stage_index]
                within=(elapsed-4)%10
                instruction.configure(text=f'{stage_index+1}/8  {description}')
                countdown.configure(text=f'{"调整动作" if within<3 else "正在记录，请保持"}  | 本段剩余 {10-int(within)} 秒')
                result=engine.process(frame,debug=False)
                if within>=3:
                    if writer is None:
                        writer=cv2.VideoWriter(str(target/'input.avi'),cv2.VideoWriter_fourcc(*'MJPG'),15,
                                               (frame.shape[1],frame.shape[0]))
                        if not writer.isOpened(): raise RuntimeError('Video writer unavailable')
                    writer.write(frame)
                    m=result['metrics']
                    rows.append(dict(video_index=len(rows),scenario=stage,t_seconds=elapsed,
                        accepted=m['accepted'],matches=m['matches'],inliers=m['inliers'],
                        inlier_ratio=m['inlier_ratio'],processing_ms=m['processing_ms'],reason=m['reason']))
                    if m['accepted'] and (stage not in best or m['inliers']>best[stage][0]):
                        best[stage]=(m['inliers'],frame.copy())
            view=cv2.hconcat([frame,result['augmented']])
            rgb=cv2.cvtColor(view,cv2.COLOR_BGR2RGB)
            pil=Image.fromarray(rgb)
            pil.thumbnail((1080,490))
            photo=ImageTk.PhotoImage(pil)
            panel.configure(image=photo)
            panel.image=photo
            m=result['metrics']
            stats.configure(text=f'{"已找到参考图" if m["accepted"] else "未接受定位"}  | 匹配 {m["matches"]} | 内点 {m["inliers"]}  | 本地保存，不上传摄像头原图')
            root.update()
    finally:
        cap.release()
        if writer: writer.release()
        root.destroy()
    if rows:
        with (target/'frames.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summary=[]
    for stage,description in STAGES:
        group=[r for r in rows if r['scenario']==stage]
        summary.append(dict(scenario=stage,frames=len(group),accepted=sum(r['accepted'] for r in group)))
        if stage in best:
            result=engine.process(best[stage][1])
            for key in ['frame','outline','augmented']:
                write_image(target/stage/(key+'.png'),result[key])
            (target/stage/'metrics.json').write_text(json.dumps(result['metrics'],indent=2),encoding='utf-8')
    (target/'summary.json').write_text(json.dumps(dict(stages=summary,completed=elapsed>=84,
        note='Guided physical phone-marker test. Actions are qualitative, not calibrated angle/lux/occlusion measurements.',
        settings=asdict(engine.settings),elapsed_seconds=elapsed),indent=2),encoding='utf-8')
    print(json.dumps(summary),flush=True)
    print('Private session:',target,flush=True)


if __name__=='__main__':main()
