"""Compare both descriptors on the same recorded frames; publish masked views."""
from pathlib import Path
from dataclasses import asdict
import argparse,csv,json,time
import cv2
import numpy as np
from ar_core import PlanarAR,Settings,read_image,write_image
from evaluate import compose,save_csv

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('session',type=Path)
    parser.add_argument('--stride',type=int,default=4)
    args=parser.parse_args()
    with (args.session/'frames.csv').open(encoding='utf-8',newline='') as f:
        timeline=list(csv.DictReader(f))
    marker=read_image(ROOT/'assets'/'marker.png')
    substitute=read_image(ROOT/'assets'/'substitute.png')
    engines={method:PlanarAR(marker,substitute,Settings(method=method,ratio=.72 if method=='SIFT' else .78))
             for method in ['SIFT','ORB']}
    cap=cv2.VideoCapture(str(args.session/'input.avi'))
    rows=[]
    index=0
    while True:
        ok,frame=cap.read()
        if not ok:break
        if index>=len(timeline):raise RuntimeError('Video/timeline mismatch')
        if index%args.stride==0:
            original_stage=timeline[index]['scenario']
            timestamp=float(timeline[index]['t_seconds'])
            # Review at 79, 81 and 83 seconds confirmed the phone had left the
            # frame. Earlier accepted frames still show the actual marker.
            stage=('removal_transition' if original_stage=='absent' and timestamp<79
                   else original_stage)
            for method,engine in engines.items():
                result=engine.process(frame,debug=False)
                m=result['metrics']
                rows.append(dict(video_index=index,t_seconds=timestamp,scenario=stage,
                    guided_scenario=original_stage,method=method,
                    accepted=m['accepted'],inliers=m['inliers'],matches=m['matches'],
                    inlier_ratio=m['inlier_ratio'],reprojection_median_px=m['reprojection_median_px'],
                    processing_ms=m['processing_ms'],reason=m['reason']))
        index+=1
    cap.release()
    assert index==len(timeline),(index,len(timeline))
    save_csv(OUT/'webcam_replay_trials.csv',rows)
    summary=[]
    stages=list(dict.fromkeys(r['scenario'] for r in rows))
    for stage in stages:
        for method in ['SIFT','ORB']:
            group=[r for r in rows if r['scenario']==stage and r['method']==method]
            residuals=[r['reprojection_median_px'] for r in group if r['accepted']]
            summary.append(dict(scenario=stage,method=method,frames=len(group),
                accepted=sum(r['accepted'] for r in group),
                acceptance_percent=100*sum(r['accepted'] for r in group)/max(1,len(group)),
                median_processing_ms=float(np.median([r['processing_ms'] for r in group])) if group else None,
                median_inlier_residual_px=float(np.median(residuals)) if residuals else None))
    save_csv(OUT/'webcam_replay_summary.csv',summary)
    examples=[]
    labels=[]
    for stage in stages:
        if stage in ['absent','removal_transition']:continue
        source=args.session/stage/'frame.png'
        if not source.exists():continue
        frame=read_image(source)
        result=engines['SIFT'].process(frame)
        if not result['metrics']['accepted']:continue
        # Whiten all pixels outside the estimated marker polygon. Raw backgrounds,
        # faces and room details remain in the private directory only.
        mask=np.zeros(frame.shape[:2],np.uint8)
        cv2.fillConvexPoly(mask,np.rint(result['corners']).astype(np.int32),255)
        clean=np.full_like(frame,255)
        clean[mask>0]=frame[mask>0]
        augmented=np.full_like(frame,255)
        augmented[mask>0]=result['augmented'][mask>0]
        write_image(OUT/'figures'/f'real_{stage}_input_masked.png',clean)
        write_image(OUT/'figures'/f'real_{stage}_replacement_masked.png',augmented)
        if stage in ['frontal','tilt','rotation','dim','occlusion_25','occlusion_50']:
            x,y,w,h=cv2.boundingRect(np.rint(result['corners']).astype(np.int32))
            x0,y0=max(0,x-12),max(0,y-12)
            x1,y1=min(frame.shape[1],x+w+12),min(frame.shape[0],y+h+12)
            examples.extend([clean[y0:y1,x0:x1],augmented[y0:y1,x0:x1]])
            labels.extend([f'Real webcam: {stage}', 'Replacement; background removed'])
    compose(OUT/'figures'/'real_phone_comparison.png',examples[:4],labels[:4],columns=2,cell=(460,350))
    compose(OUT/'figures'/'real_phone_conditions.png',examples,labels,columns=2,cell=(400,300))
    live=json.loads((args.session/'summary.json').read_text(encoding='utf-8'))
    meta=dict(source_session=args.session.name,source_type='real integrated webcam viewing marker on a phone screen',
        live_stages=live['stages'],recorded_frames=len(timeline),sample_stride=args.stride,
        sampled_frames=len(rows)//2,completed=live['completed'],opencv=cv2.__version__,
        comparison='Same MJPG-decoded frames for both methods; every fourth captured frame sampled by default.',
        note='Acceptance is an algorithm decision, not ground-truth accuracy. Inlier residual is not independent corner error. Guided actions are qualitative.',
        negative_review='Frames at 79, 81 and 83 seconds were visually reviewed locally: phone absent. The guided absence stage before 79 seconds is reported separately as removal_transition, since it includes the real marker leaving the frame.',
        privacy='Published examples whiten all pixels outside the estimated marker polygon. Best-inlier snapshots illustrate the output; aggregate metrics use every sampled frame.',
        settings={method:asdict(engine.settings) for method,engine in engines.items()})
    baseline_files=sorted((OUT/'private').glob('*-frontal/summary.json'))
    if baseline_files:
        baseline=json.loads(baseline_files[0].read_text(encoding='utf-8'))
        meta['initial_frontal']={k:baseline[k] for k in ['frames','accepted','elapsed_seconds','observed_processing_loop_fps']}
        meta['initial_frontal']['source_session']=baseline_files[0].parent.name
    (OUT/'webcam_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(summary),flush=True)
    print('Sampled',len(rows)//2,'real frames; comparison and privacy-masked examples saved.',flush=True)


if __name__=='__main__':main()
