"""Feature matching and planar image replacement. No coded-marker detector."""
from dataclasses import dataclass, asdict
from pathlib import Path
import time
import cv2
import numpy as np
try:
    from OpenCV_Image_Utilities import imread_utf8
    TEACHER_UTILITIES_AVAILABLE = True
except ImportError:
    imread_utf8 = None
    TEACHER_UTILITIES_AVAILABLE = False


@dataclass
class Settings:
    method: str = "SIFT"
    features: int = 1800
    ratio: float = 0.72
    ransac_px: float = 3.0
    min_inliers: int = 10
    min_inlier_ratio: float = 0.35
    min_coverage: float = 0.03
    opacity: float = 1.0


def read_image(path):
    result = (imread_utf8(str(path), cv2.IMREAD_COLOR) if imread_utf8 is not None
              else cv2.imdecode(np.fromfile(Path(path), np.uint8), cv2.IMREAD_COLOR))
    if result is None:
        raise ValueError(f"Cannot read image: {path}")
    return result


def write_image(path, bgr):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    ok, data = cv2.imencode(path.suffix, bgr)
    if not ok:
        raise ValueError(f"Cannot encode image: {path}")
    data.tofile(path)


def corners(image):
    h, w = image.shape[:2]
    return np.float32([[0, 0], [w-1, 0], [w-1, h-1], [0, h-1]])


class PlanarAR:
    def __init__(self, marker, substitute, settings=None):
        self.marker = marker.copy()
        self.substitute = cv2.resize(substitute, (marker.shape[1], marker.shape[0]))
        self.settings = settings or Settings()
        self._signature = None
        self._prepare()

    def _prepare(self):
        signature = (self.settings.method.upper(), int(self.settings.features))
        if signature == self._signature:
            return
        method, features = signature
        if features < 50:
            raise ValueError("Use at least 50 features")
        if method == "SIFT":
            self.detector = cv2.SIFT_create(nfeatures=features)
            self.norm = cv2.NORM_L2
        elif method == "ORB":
            self.detector = cv2.ORB_create(nfeatures=features, fastThreshold=12)
            self.norm = cv2.NORM_HAMMING
        else:
            raise ValueError("Method must be SIFT or ORB")
        self.marker_keypoints, self.marker_descriptors = self.detector.detectAndCompute(
            cv2.cvtColor(self.marker, cv2.COLOR_BGR2GRAY), None)
        self._signature = signature

    def process(self, frame, debug=True):
        started = time.perf_counter()
        self._prepare()
        cfg = self.settings
        if not (0 < cfg.ratio < 1 and cfg.ransac_px > 0 and 0 <= cfg.opacity <= 1):
            raise ValueError("Invalid matching, RANSAC or opacity setting")
        keypoints, descriptors = self.detector.detectAndCompute(
            cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), None)
        metrics = dict(method=cfg.method, marker_keypoints=len(self.marker_keypoints),
                       frame_keypoints=len(keypoints), matches=0, inliers=0,
                       inlier_ratio=0., source_coverage=0., reprojection_median_px=None,
                       accepted=False, reason="Too few descriptors")
        matches = []
        H = quad = None
        inlier_mask = None
        if self.marker_descriptors is not None and descriptors is not None and len(descriptors) >= 2:
            matcher = cv2.BFMatcher(self.norm, crossCheck=False)
            pairs = matcher.knnMatch(self.marker_descriptors, descriptors, k=2)
            candidates = [p[0] for p in pairs if len(p) == 2 and p[0].distance < cfg.ratio*p[1].distance]
            # Prevent many reference points from mapping to the same target point.
            used = set()
            for match in sorted(candidates, key=lambda m: m.distance):
                if match.trainIdx not in used:
                    matches.append(match)
                    used.add(match.trainIdx)
            metrics["matches"] = len(matches)
            metrics["reason"] = "Not enough filtered matches"
            if len(matches) >= max(4, cfg.min_inliers):
                src = np.float32([self.marker_keypoints[m.queryIdx].pt for m in matches])
                dst = np.float32([keypoints[m.trainIdx].pt for m in matches])
                H, mask = cv2.findHomography(src, dst, cv2.RANSAC, cfg.ransac_px,
                                             maxIters=2500, confidence=.995)
                metrics["reason"] = "Homography could not be estimated"
                if H is not None and mask is not None and np.isfinite(H).all():
                    inlier_mask = mask.ravel().astype(bool)
                    n = int(inlier_mask.sum())
                    metrics["inliers"] = n
                    metrics["inlier_ratio"] = n/len(matches)
                    if n >= 4:
                        projected = cv2.perspectiveTransform(src[inlier_mask, None], H)[:, 0]
                        error = np.linalg.norm(projected-dst[inlier_mask], axis=1)
                        metrics["reprojection_median_px"] = float(np.median(error))
                        area = cv2.contourArea(cv2.convexHull(src[inlier_mask]))
                        metrics["source_coverage"] = float(area/((self.marker.shape[1]-1)*(self.marker.shape[0]-1)))
                        quad = cv2.perspectiveTransform(corners(self.marker)[None], H)[0]
                        valid_quad = self.valid_quadrilateral(quad, frame.shape)
                        checks = [
                            (n >= cfg.min_inliers, "Too few RANSAC inliers"),
                            (metrics["inlier_ratio"] >= cfg.min_inlier_ratio, "Low inlier ratio"),
                            (metrics["source_coverage"] >= cfg.min_coverage, "Inliers cover too little of marker"),
                            (metrics["reprojection_median_px"] <= cfg.ransac_px, "High reprojection error"),
                            (valid_quad, "Implausible marker outline"),
                        ]
                        metrics["accepted"] = all(ok for ok, _ in checks)
                        metrics["reason"] = "Marker found" if metrics["accepted"] else next(msg for ok, msg in checks if not ok)
        output = frame.copy()
        if metrics["accepted"]:
            output = self.augment(frame, H)
        metrics["processing_ms"] = (time.perf_counter()-started)*1000
        metrics["settings"] = asdict(cfg)
        result = dict(frame=frame, augmented=output, H=H if metrics["accepted"] else None,
                      corners=quad if metrics["accepted"] else None, metrics=metrics)
        if debug:
            overlay = frame.copy()
            if metrics["accepted"]:
                cv2.polylines(overlay, [np.rint(quad).astype(np.int32)], True, (0, 210, 0), 2, cv2.LINE_AA)
            marker_kp = cv2.drawKeypoints(self.marker, self.marker_keypoints, None,
                flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
            frame_kp = cv2.drawKeypoints(overlay, keypoints, None,
                flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
            displayed = matches[:100]
            displayed_mask = inlier_mask[:100].astype(int).tolist() if inlier_mask is not None else None
            match_view = cv2.drawMatches(self.marker, self.marker_keypoints, frame,
                keypoints, displayed, None, matchesMask=displayed_mask,
                flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS,
                matchColor=(20, 200, 20), singlePointColor=(200, 200, 200))
            result.update(keypoints=frame_kp, marker_keypoints_image=marker_kp,
                          matches_image=match_view, outline=overlay)
        return result

    @staticmethod
    def valid_quadrilateral(quad, shape):
        if not np.isfinite(quad).all() or not cv2.isContourConvex(quad.astype(np.float32)):
            return False
        area = abs(cv2.contourArea(quad))
        h, w = shape[:2]
        lengths = np.linalg.norm(quad-np.roll(quad, 1, axis=0), axis=1)
        return bool(900 <= area <= 1.5*w*h and lengths.min() >= 12
                    and lengths.max()/lengths.min() < 15
                    and np.all(quad[:, 0] > -w) and np.all(quad[:, 0] < 2*w)
                    and np.all(quad[:, 1] > -h) and np.all(quad[:, 1] < 2*h))

    def augment(self, frame, H):
        h, w = frame.shape[:2]
        warped = cv2.warpPerspective(self.substitute, H, (w, h))
        mask = cv2.warpPerspective(np.full(self.marker.shape[:2], 255, np.uint8), H,
                                   (w, h), flags=cv2.INTER_NEAREST)
        weight = mask.astype(np.float32)[..., None]/255*self.settings.opacity
        return np.clip(frame.astype(np.float32)*(1-weight)+warped.astype(np.float32)*weight,
                       0, 255).astype(np.uint8)
