"""Generate original, reproducible marker/substitute graphics and a demo clip."""
from pathlib import Path
import math
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent


def font(size, bold=False):
    path = Path('C:/Windows/Fonts') / ('arialbd.ttf' if bold else 'arial.ttf')
    return ImageFont.truetype(str(path), size) if path.exists() else ImageFont.load_default()


def main():
    out = ROOT/'assets'
    out.mkdir(exist_ok=True)
    rng = np.random.default_rng(74123)
    image = Image.new('RGB', (800, 600), 'white')
    draw = ImageDraw.Draw(image)
    draw.rectangle((7, 7, 792, 592), outline='black', width=7)
    draw.rectangle((24, 24, 775, 132), fill=(25, 32, 43))
    draw.text((45, 38), 'BCV / PLANAR AR', font=font(49, True), fill='white')
    draw.text((48, 98), 'REFERENCE IMAGE   01', font=font(20), fill='white')
    # Irregular, asymmetric marks produce varied local patches rather than a
    # repeating checkerboard or an ArUco code.
    for i in range(120):
        x = int(rng.integers(35, 756))
        y = int(rng.integers(155, 548))
        r = int(rng.integers(6, 23))
        color = [(0, 0, 0), (55, 78, 92), (125, 49, 35), (40, 95, 63)][i % 4]
        if i % 4 == 0:
            draw.ellipse((x-r, y-r, x+r, y+r), outline=color, width=int(rng.integers(2, 6)))
            draw.line((x-r, y, x+r//2, y+r), fill=color, width=3)
        elif i % 4 == 1:
            draw.polygon([(x-r, y-r), (x+r, y-3), (x+4, y+r)], fill=color)
        elif i % 4 == 2:
            draw.rectangle((x-r, y-r//2, x+r, y+r//2), outline=color, width=3)
            draw.line((x-r, y-r, x+r, y+r), fill=color, width=2)
        else:
            draw.text((x-r, y-r), str(i), fill=color, font=font(15, True))
    draw.rectangle((35, 245, 430, 335), fill='white', outline='black', width=3)
    draw.text((53, 257), 'FIND THIS IMAGE', font=font(33, True), fill='black')
    draw.text((54, 303), 'Rotate / tilt / cover one corner', font=font(18), fill='black')
    draw.text((40, 557), 'Basic Computer Vision | Wang Zhaofeng | 2026', font=font(20), fill='black')
    image.save(out/'marker.png')
    low = Image.new('RGB', (800, 600), 'white')
    ImageDraw.Draw(low).rectangle((180, 150, 620, 450), fill=(95, 95, 95))
    low.save(out/'marker_low_detail.png')
    replacement = Image.new('RGB', (800, 600), (232, 222, 198))
    d = ImageDraw.Draw(replacement)
    d.rectangle((15, 15, 785, 585), outline=(30, 30, 30), width=7)
    d.text((48, 49), 'A DIFFERENT VIEW', font=font(48, True), fill=(25, 25, 25))
    d.text((51, 115), 'Marker-based augmented reality', font=font(27), fill=(25, 25, 25))
    d.ellipse((475, 180, 690, 395), fill=(195, 86, 53))
    d.polygon([(70, 465), (265, 235), (445, 465)], fill=(48, 86, 76))
    d.polygon([(270, 465), (444, 300), (650, 465)], fill=(71, 103, 119))
    d.text((50, 519), 'BCV FINAL PROJECT / 2026', font=font(27, True), fill=(25, 25, 25))
    replacement.save(out/'substitute.png')
    # A local HTML file is useful on any device once copied with marker.png.
    (out/'show_marker.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>BCV marker</title>
<style>html,body{margin:0;height:100%;background:white}body{display:flex;align-items:center;justify-content:center}img{max-width:100vw;max-height:100vh;object-fit:contain}</style>
<img src="marker.png" alt="BCV reference marker; display in landscape orientation"></html>''', encoding='utf-8')
    print('Created marker, low-detail marker and substitute:', out)


if __name__ == '__main__':
    main()
