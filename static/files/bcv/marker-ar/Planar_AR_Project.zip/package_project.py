"""Create a public source bundle; never include camera evidence or course PDFs."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def main():
    names = ['ar_core.py','ar_app.py','evaluate.py','make_assets.py','write_report.py','webcam_check.py',
             'requirements.txt','README.md','run.ps1','package_project.py']
    files = [ROOT/name for name in names if (ROOT/name).exists()]
    files += list((ROOT/'assets').glob('*'))
    files += [ROOT/'output'/name for name in ['synthetic_trials.csv','synthetic_summary.csv',
        'evaluation_metadata.json','Project_Report.pdf','Project_Report.md'] if (ROOT/'output'/name).exists()]
    files += list((ROOT/'output'/'figures').glob('*'))
    target = ROOT/'output'/'Planar_AR_Project.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert not any('private/' in name or name.endswith('OpenCV_Image_Utilities.py') for name in z.namelist())
    print(f'Verified source bundle: {target} ({target.stat().st_size/1024**2:.2f} MiB)')


if __name__=='__main__':
    main()
