"""Reproducible synthetic tests. These are not real webcam observations."""
from pathlib import Path
from dataclasses import asdict
from datetime import datetime, timezone
import argparse
import csv
import hashlib
import json
import platform
import sys
import time
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
from ar_core import PlanarAR, Settings, corners, read_image, write_image

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'output'
CONDITIONS = ['normal', 'rotation', 'perspective', 'dim', 'shadow', 'blur',
              'occlusion_25', 'occlusion_50', 'clutter', 'absent']


def save_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def background(seed, clutter=False):
    rng = np.random.default_rng(seed)
    base = np.zeros((600, 800, 3), np.uint8)
    base[:] = (195, 198, 202)
    for i in range(150 if clutter else 16):
        x, y = rng.integers(0, 800), rng.integers(0, 600)
        color = tuple(int(v) for v in rng.integers(25, 230, 3))
        cv2.putText(base, str(i*17), (int(x), int(y)), cv2.FONT_HERSHEY_SIMPLEX,
                    float(rng.uniform(.4, 1.2)), color, 1, cv2.LINE_AA)
    return base


def scene(marker, condition, seed=0):
    rng = np.random.default_rng(seed)
    frame = background(seed, condition == 'clutter')
    base_quad = np.float32([[130, 90], [685, 80], [690, 505], [120, 520]])
    if condition == 'perspective':
        base_quad = np.float32([[280, 65], [560, 180], [690, 470], [90, 520]])
    elif condition == 'rotation':
        rect = np.float32([[-260, -180], [260, -180], [260, 180], [-260, 180]])
        angle = np.deg2rad(28)
        R = np.float32([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
        base_quad = rect@R.T + np.float32([400, 300])
    quad = base_quad + rng.uniform(-9, 9, (4, 2)).astype(np.float32)
    H = cv2.getPerspectiveTransform(corners(marker), quad)
    if condition != 'absent':
        warped = cv2.warpPerspective(marker, H, (800, 600))
        mask = cv2.warpPerspective(np.full(marker.shape[:2], 255, np.uint8), H,
                                   (800, 600), flags=cv2.INTER_NEAREST)
        frame[mask > 0] = warped[mask > 0]
    if condition == 'dim':
        frame = np.clip(frame.astype(np.float32)*.30 + rng.normal(0, 2, frame.shape), 0, 255).astype(np.uint8)
    elif condition == 'shadow':
        factor = np.linspace(.25, 1., 800)[None, :, None]
        frame = np.clip(frame*factor, 0, 255).astype(np.uint8)
    elif condition == 'blur':
        frame = cv2.GaussianBlur(frame, (11, 11), 2.5)
    elif condition in ['occlusion_25', 'occlusion_50']:
        # Occlude an exactly known left fraction of the marker in its own plane.
        fraction = .25 if condition == 'occlusion_25' else .50
        overlay = np.zeros(marker.shape[:2], np.uint8)
        overlay[:, :round(marker.shape[1]*fraction)] = 255
        warped_occluder = cv2.warpPerspective(overlay, H, (800, 600), flags=cv2.INTER_NEAREST)
        frame[warped_occluder > 0] = (105, 125, 145)
    return frame, quad, H


def compose(path, images, titles, columns=3, cell=(400, 320)):
    rows = (len(images)+columns-1)//columns
    canvas = Image.new('RGB', (columns*cell[0], rows*cell[1]), 'white')
    draw = ImageDraw.Draw(canvas)
    fpath = Path('C:/Windows/Fonts/arial.ttf')
    font = ImageFont.truetype(str(fpath), 17) if fpath.exists() else ImageFont.load_default()
    for i, (image, title) in enumerate(zip(images, titles)):
        x, y = (i%columns)*cell[0], (i//columns)*cell[1]
        draw.text((x+10, y+5), title, font=font, fill='black')
        thumb = ImageOps.contain(Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)),
                                 (cell[0]-12, cell[1]-38))
        canvas.paste(thumb, (x+(cell[0]-thumb.width)//2, y+32))
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)


def implementation_checks(marker, substitute):
    engine = PlanarAR(marker, substitute)
    blank = np.full((600, 800, 3), 127, np.uint8)
    result = engine.process(blank, debug=False)
    assert not result['metrics']['accepted'] and np.array_equal(result['augmented'], blank)
    frame, truth, H = scene(marker, 'normal', 3)
    result = engine.process(frame)
    assert result['metrics']['accepted'], result['metrics']
    assert np.mean(np.linalg.norm(result['corners']-truth, axis=1)) < 3
    warped_mask = cv2.warpPerspective(np.full(marker.shape[:2], 255, np.uint8),
        result['H'], (800, 600), flags=cv2.INTER_NEAREST) > 0
    assert np.array_equal(result['augmented'][~warped_mask], frame[~warped_mask])
    engine.settings.opacity = 0
    assert np.array_equal(engine.process(frame, False)['augmented'], frame)
    engine.settings.opacity = 1
    assert not engine.valid_quadrilateral(np.float32([[1,1],[2,2],[3,3],[4,4]]), frame.shape)
    return {'blank_rejection': True, 'known_corner_alignment': True,
            'outside_mask_unchanged': True, 'zero_opacity_unchanged': True,
            'degenerate_quad_rejected': True}


def make_demo(marker):
    path = OUT/'synthetic_demo.avi'
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*'MJPG'), 15, (800, 600))
    if not writer.isOpened():
        raise RuntimeError('MJPG writer unavailable')
    try:
        base = background(37, True)
        for index in range(150):
            t = index/149
            quad = np.float32([[120+60*np.sin(t*6), 100], [650, 90+50*np.sin(t*5)],
                               [680-50*np.sin(t*6), 500], [100, 500-40*np.sin(t*4)]])
            H = cv2.getPerspectiveTransform(corners(marker), quad)
            frame = base.copy()
            warp = cv2.warpPerspective(marker, H, (800, 600))
            mask = cv2.warpPerspective(np.full(marker.shape[:2], 255, np.uint8), H, (800, 600))
            frame[mask > 0] = warp[mask > 0]
            cv2.putText(frame, 'SYNTHETIC DEMO - not a webcam recording', (15, 580),
                        cv2.FONT_HERSHEY_SIMPLEX, .55, (0, 0, 0), 1, cv2.LINE_AA)
            writer.write(frame)
    finally:
        writer.release()
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--trials', type=int, default=3)
    args = parser.parse_args()
    cv2.setRNGSeed(20261017)
    OUT.mkdir(exist_ok=True)
    marker = read_image(ROOT/'assets'/'marker.png')
    low = read_image(ROOT/'assets'/'marker_low_detail.png')
    substitute = read_image(ROOT/'assets'/'substitute.png')
    checks = implementation_checks(marker, substitute)
    rows, examples = [], {}
    for marker_name, reference in [('rich', marker), ('low_detail', low)]:
        for method in ['SIFT', 'ORB']:
            settings = Settings(method=method, ratio=.72 if method == 'SIFT' else .78)
            engine = PlanarAR(reference, substitute, settings)
            for condition in CONDITIONS:
                for trial in range(args.trials):
                    frame, true_corners, H = scene(reference, condition, 100+trial)
                    result = engine.process(frame, debug=trial == 0 and marker_name == 'rich')
                    m = result['metrics']
                    error = float(np.mean(np.linalg.norm(result['corners']-true_corners, axis=1))) if m['accepted'] and condition != 'absent' else None
                    success = bool(m['accepted'] and error is not None and error <= 5)
                    rows.append(dict(marker=marker_name, method=method, condition=condition, trial=trial,
                        accepted=m['accepted'], success_within_5px=success,
                        corner_error_px=error, false_positive=bool(condition == 'absent' and m['accepted']),
                        keypoints=m['frame_keypoints'], matches=m['matches'], inliers=m['inliers'],
                        inlier_ratio=m['inlier_ratio'], coverage=m['source_coverage'],
                        processing_ms=m['processing_ms'], reason=m['reason']))
                    if marker_name == 'rich' and trial == 0:
                        examples[method, condition] = result
                        if method == 'SIFT':
                            for key in ['frame', 'augmented', 'outline', 'matches_image']:
                                write_image(OUT/'examples'/f'{condition}_{key}.png', result[key])
                print(marker_name, method, condition, flush=True)
    save_csv(OUT/'synthetic_trials.csv', rows)
    summary = []
    for marker_name in ['rich', 'low_detail']:
        for method in ['SIFT', 'ORB']:
            for condition in CONDITIONS:
                group = [r for r in rows if (r['marker'], r['method'], r['condition']) == (marker_name, method, condition)]
                errors = [r['corner_error_px'] for r in group if r['corner_error_px'] is not None]
                summary.append(dict(marker=marker_name, method=method, condition=condition,
                    trials=len(group), accepted=sum(r['accepted'] for r in group),
                    successes_5px=sum(r['success_within_5px'] for r in group),
                    false_positives=sum(r['false_positive'] for r in group),
                    mean_corner_error_px=float(np.mean(errors)) if errors else None,
                    median_processing_ms=float(np.median([r['processing_ms'] for r in group]))))
    save_csv(OUT/'synthetic_summary.csv', summary)
    for condition in ['normal', 'perspective', 'occlusion_50', 'dim', 'clutter', 'blur']:
        r = examples['SIFT', condition]
        compose(OUT/'figures'/f'{condition}_comparison.png', [r['outline'], r['matches_image'], r['augmented']],
                [f'Synthetic: {condition}', 'Filtered inlier matches', 'Replacement'])
    images = [examples['SIFT', c]['augmented'] for c in CONDITIONS if c != 'absent']
    compose(OUT/'figures'/'conditions.png', images, ['Synthetic: '+c for c in CONDITIONS if c != 'absent'])
    demo = make_demo(marker)
    files = [ROOT/'ar_core.py', ROOT/'evaluate.py', ROOT/'OpenCV_Image_Utilities.py', ROOT/'assets'/'marker.png', ROOT/'assets'/'substitute.png']
    metadata = dict(run_utc=datetime.now(timezone.utc).isoformat(), executable=sys.executable,
        python=sys.version, opencv=cv2.__version__, numpy=np.__version__, platform=platform.platform(),
        random_seed=20261017, trials_per_case=args.trials, total_cases=len(rows),
        settings={method:asdict(Settings(method=method, ratio=.72 if method == 'SIFT' else .78)) for method in ['SIFT','ORB']},
        checks=checks, evaluation_type='synthetic planar warps; not real webcam footage',
        success_rule='accepted homography and mean four-corner error <=5 pixels; absent cases scored as false positives',
        source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        webcam_marker_test='pending physical presentation by user')
    (OUT/'evaluation_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print('Completed',len(rows),'cases. Demo:',demo,flush=True)


if __name__ == '__main__':
    main()
