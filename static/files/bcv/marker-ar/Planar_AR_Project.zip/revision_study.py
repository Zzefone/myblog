"""Post-hoc sensitivity and recorded-frame diagnostics; never opens a camera.

Synthetic descriptors are cached, but matching/RANSAC/acceptance follow ar_core.
The original evaluation is retained unchanged. Raw replay frames remain private.
"""
from pathlib import Path
from dataclasses import replace, asdict
from datetime import datetime, timezone
import argparse, csv, hashlib, json
import cv2
import numpy as np
from ar_core import PlanarAR, Settings, read_image, write_image, corners
from evaluate import scene, CONDITIONS, save_csv, compose

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'output'
SESSION = OUT/'private'/'20261017-164106-guided'
SEEDS = [300, 301]


def cache(engine, frame):
    kp, des = engine.detector.detectAndCompute(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), None)
    pairs = []
    if engine.marker_descriptors is not None and des is not None and len(des) >= 2:
        pairs = cv2.BFMatcher(engine.norm).knnMatch(engine.marker_descriptors, des, k=2)
    return kp, pairs


def estimate(engine, frame, cached, cfg):
    kp, pairs = cached
    candidates = [p[0] for p in pairs if len(p) == 2 and p[0].distance < cfg.ratio*p[1].distance]
    matches, used = [], set()
    for m in sorted(candidates, key=lambda m:m.distance):
        if m.trainIdx not in used:
            matches.append(m); used.add(m.trainIdx)
    metrics = dict(frame_keypoints=len(kp), matches=len(matches), inliers=0,
                   inlier_ratio=0., source_coverage=0., accepted=False,
                   reprojection_median_px=None, reason='Not enough filtered matches')
    quad = None
    if len(matches) >= max(4, cfg.min_inliers):
        src = np.float32([engine.marker_keypoints[m.queryIdx].pt for m in matches])
        dst = np.float32([kp[m.trainIdx].pt for m in matches])
        cv2.setRNGSeed(20261019)
        H, mask = cv2.findHomography(src, dst, cv2.RANSAC, cfg.ransac_px,
                                     maxIters=2500, confidence=.995)
        metrics['reason'] = 'Homography could not be estimated'
        if H is not None and mask is not None and np.isfinite(H).all():
            inside = mask.ravel().astype(bool)
            n = int(inside.sum())
            metrics.update(inliers=n, inlier_ratio=n/len(matches))
            if n >= 4:
                projected = cv2.perspectiveTransform(src[inside,None], H)[:,0]
                metrics['reprojection_median_px'] = float(np.median(np.linalg.norm(projected-dst[inside],axis=1)))
                metrics['source_coverage'] = float(cv2.contourArea(cv2.convexHull(src[inside]))/
                    ((engine.marker.shape[1]-1)*(engine.marker.shape[0]-1)))
                quad = cv2.perspectiveTransform(corners(engine.marker)[None], H)[0]
                checks = [(n >= cfg.min_inliers,'Too few RANSAC inliers'),
                    (metrics['inlier_ratio'] >= cfg.min_inlier_ratio,'Low inlier ratio'),
                    (metrics['source_coverage'] >= cfg.min_coverage,'Inliers cover too little of marker'),
                    (metrics['reprojection_median_px'] <= cfg.ransac_px,'High reprojection error'),
                    (engine.valid_quadrilateral(quad,frame.shape),'Implausible marker outline')]
                metrics['accepted'] = all(ok for ok,_ in checks)
                metrics['reason'] = 'Marker found' if metrics['accepted'] else next(msg for ok,msg in checks if not ok)
    return metrics, quad


def sensitivity():
    marker = read_image(ROOT/'assets/marker.png')
    substitute = read_image(ROOT/'assets/substitute.png')
    rows, equivalence = [], []
    scans = dict(ratio=[.60,.66,.70,.72,.75,.78,.82,.86,.90],
                 ransac_px=[1.,2.,3.,5.,8.], min_inliers=[4,6,10,15,20],
                 min_coverage=[0.,.01,.03,.06,.10])
    for name, ref in [('rich',marker),('low_detail',read_image(ROOT/'assets/marker_low_detail.png'))]:
        for method in ['SIFT','ORB']:
            baseline = Settings(method=method,ratio=.72 if method=='SIFT' else .78)
            engine = PlanarAR(ref,substitute,baseline)
            for condition in CONDITIONS:
                for seed in SEEDS:
                    frame, truth, _ = scene(ref,condition,seed)
                    saved = cache(engine,frame)
                    if seed == SEEDS[0] and condition in ['normal','perspective','absent']:
                        cv2.setRNGSeed(20261019)
                        actual = engine.process(frame,debug=False)
                        expected, quad = estimate(engine,frame,saved,baseline)
                        for key in ['matches','inliers','accepted','source_coverage','inlier_ratio']:
                            assert actual['metrics'][key] == expected[key],(name,method,condition,key)
                        if expected['accepted']:
                            assert np.allclose(actual['corners'],quad)
                        equivalence.append([name,method,condition])
                    for parameter, values in scans.items():
                        for value in values:
                            cfg = replace(baseline,**{parameter:value})
                            m, quad = estimate(engine,frame,saved,cfg)
                            err = float(np.mean(np.linalg.norm(quad-truth,axis=1))) if m['accepted'] and condition!='absent' else None
                            rows.append(dict(marker=name,method=method,condition=condition,seed=seed,
                                parameter=parameter,value=value,accepted=m['accepted'],
                                success_5px=bool(err is not None and err<=5),corner_error_px=err,
                                false_positive=bool(condition=='absent' and m['accepted']),
                                matches=m['matches'],inliers=m['inliers'],coverage=m['source_coverage']))
            print('Sensitivity complete:',name,method,flush=True)
    save_csv(OUT/'sensitivity_trials.csv',rows)
    summary=[]
    for method in ['SIFT','ORB']:
        for parameter,values in scans.items():
            for value in values:
                group=[r for r in rows if r['method']==method and r['parameter']==parameter and r['value']==value]
                positive=[r for r in group if r['marker']=='rich' and r['condition']!='absent']
                low=[r for r in group if r['marker']=='low_detail' and r['condition']!='absent']
                negatives=[r for r in group if r['condition']=='absent']
                errors=[r['corner_error_px'] for r in positive if r['corner_error_px'] is not None]
                summary.append(dict(method=method,parameter=parameter,value=value,
                    rich_success=sum(r['success_5px'] for r in positive),rich_total=len(positive),
                    rich_accepted=sum(r['accepted'] for r in positive),
                    mean_corner_error_px=float(np.mean(errors)) if errors else None,
                    low_detail_accepted=sum(r['accepted'] for r in low),low_detail_total=len(low),
                    false_positives=sum(r['false_positive'] for r in negatives),negatives=len(negatives)))
    save_csv(OUT/'sensitivity_summary.csv',summary)
    meta=dict(run_utc=datetime.now(timezone.utc).isoformat(),type='post-hoc one-factor-at-a-time sensitivity',
        seeds=SEEDS,original_seeds=[100,101,102],settings={m:asdict(Settings(method=m,ratio=.72 if m=='SIFT' else .78)) for m in ['SIFT','ORB']},
        scans=scans,total_parameter_evaluations=len(rows),marker_scene_cases=40,
        cached_evaluator_equivalence_checks=equivalence,opencv=cv2.__version__,
        limitation='Small synthetic set; not an independent generalization test or evidence of a unique optimum.',
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'ar_core.py',ROOT/'evaluate.py']})
    (OUT/'sensitivity_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')


def replay():
    with (SESSION/'frames.csv').open(encoding='utf-8',newline='') as f: timeline=list(csv.DictReader(f))
    marker=read_image(ROOT/'assets/marker.png');substitute=read_image(ROOT/'assets/substitute.png')
    engines={m:PlanarAR(marker,substitute,Settings(method=m,ratio=.72 if m=='SIFT' else .78)) for m in ['SIFT','ORB']}
    cap=cv2.VideoCapture(str(SESSION/'input.avi')); rows=[];index=0
    while True:
        ok,frame=cap.read()
        if not ok:break
        if index%4==0:
            t=float(timeline[index]['t_seconds']); stage=timeline[index]['scenario']
            if stage=='absent' and t<79:stage='removal_transition'
            for method,engine in engines.items():
                m=engine.process(frame,False)['metrics']
                rows.append(dict(video_index=index,t_seconds=t,scenario=stage,method=method,
                    **{k:m[k] for k in ['frame_keypoints','matches','inliers','source_coverage','accepted','reason']}))
        index+=1
    cap.release();assert index==len(timeline)
    save_csv(OUT/'webcam_diagnostics_trials.csv',rows)
    summary=[]
    for stage in dict.fromkeys(r['scenario'] for r in rows):
        for method in engines:
            g=[r for r in rows if r['scenario']==stage and r['method']==method]
            failures={reason:sum(r['reason']==reason for r in g) for reason in dict.fromkeys(r['reason'] for r in g) if reason!='Marker found'}
            summary.append(dict(scenario=stage,method=method,frames=len(g),accepted=sum(r['accepted'] for r in g),
                median_keypoints=float(np.median([r['frame_keypoints'] for r in g])),
                median_matches=float(np.median([r['matches'] for r in g])),
                median_inliers=float(np.median([r['inliers'] for r in g])),failure_counts=json.dumps(failures)))
    save_csv(OUT/'webcam_diagnostics_summary.csv',summary)
    print(json.dumps(summary),flush=True)


def annotated_examples():
    annotations=json.loads((OUT/'manual_corners.json').read_text(encoding='utf-8'))
    marker=read_image(ROOT/'assets/marker.png');substitute=read_image(ROOT/'assets/substitute.png')
    engines={m:PlanarAR(marker,substitute,Settings(method=m,ratio=.72 if m=='SIFT' else .78)) for m in ['SIFT','ORB']}
    cap=cv2.VideoCapture(str(SESSION/'input.avi'));rows=[];panels=[];labels=[]
    for entry in annotations['frames']:
        cap.set(cv2.CAP_PROP_POS_FRAMES,entry['video_index']);ok,frame=cap.read();assert ok
        truth=np.float32(entry['corners_tl_tr_br_bl'])
        for method,engine in engines.items():
            result=engine.process(frame,False);q=result['corners']
            error=np.linalg.norm(q-truth,axis=1) if q is not None else None
            rows.append(dict(video_index=entry['video_index'],requested_time=entry['requested_time'],method=method,
                accepted=q is not None,mean_corner_error_px=float(np.mean(error)) if error is not None else None,
                max_corner_error_px=float(np.max(error)) if error is not None else None,
                per_corner_error_px=json.dumps(error.tolist()) if error is not None else None))
        if entry['requested_time']==11:
            engine=engines['SIFT']; result=engine.process(frame,False)
            mask=np.zeros(frame.shape[:2],np.uint8);cv2.fillConvexPoly(mask,np.rint(truth).astype(np.int32),255)
            clean=np.full_like(frame,255);clean[mask>0]=frame[mask>0]
            x,y,w,h=cv2.boundingRect(truth)
            for opacity,label in [(0,'Real input'),(.5,'Opacity 0.5 (course alpha 0.5)'),(1,'Opacity 1 (course alpha 0)')]:
                engine.settings.opacity=opacity
                augmented=engine.augment(frame,result['H'])
                private=np.full_like(frame,255);private[mask>0]=augmented[mask>0]
                panels.append(private[y:y+h,x:x+w]);labels.append(label)
            compose(OUT/'figures/blending_comparison.png',panels,labels,columns=3,cell=(360,300))
            engine.settings.opacity=1
            # Draw only the strongest 60 points inside the manually bounded artwork.
            kp,_=engine.detector.detectAndCompute(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),None)
            inside=[k for k in kp if cv2.pointPolygonTest(truth,k.pt,False)>=0]
            selected=sorted(inside,key=lambda k:k.response,reverse=True)[:60]
            faded=cv2.addWeighted(clean,.35,np.full_like(clean,255),.65,0)
            reference_faded=cv2.addWeighted(marker,.35,np.full_like(marker,255),.65,0)
            rich=cv2.drawKeypoints(faded,selected,None,color=(0,0,0),flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
            ref=cv2.drawKeypoints(reference_faded,sorted(engine.marker_keypoints,key=lambda k:k.response,reverse=True)[:60],None,
                color=(0,0,0),flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
            compose(OUT/'figures/rich_keypoints.png',[ref,rich[y:y+h,x:x+w]],
                ['Reference: strongest 60 SIFT points','Real frame: strongest 60 inside marker'],columns=2,cell=(480,370))
            outline=clean.copy();cv2.polylines(outline,[np.rint(truth).astype(np.int32)],True,(0,0,0),1)
            for i,(a,b) in enumerate(zip(truth,result['corners'])):
                cv2.drawMarker(outline,tuple(np.rint(a).astype(int)),(0,0,0),cv2.MARKER_CROSS,9,1)
                cv2.circle(outline,tuple(np.rint(b).astype(int)),4,(0,0,0),1)
            write_image(OUT/'figures/manual_corner_example.png',outline[y:y+h,x:x+w])
    cap.release();save_csv(OUT/'manual_corner_results.csv',rows);print(json.dumps(rows),flush=True)


def plots():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with (OUT/'sensitivity_summary.csv').open(encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f))
    fig,axes=plt.subplots(1,2,figsize=(8,2.65),layout='constrained')
    for ax,param,label in zip(axes,['ratio','ransac_px'],['Ratio threshold','RANSAC threshold (px)']):
        for method,style,marker in [('SIFT','-','o'),('ORB','--','s')]:
            group=[r for r in rows if r['method']==method and r['parameter']==param]
            ax.plot([float(r['value']) for r in group],[int(r['rich_success']) for r in group],
                    color='black',linestyle=style,marker=marker,markersize=4,label=method)
        ax.set(xlabel=label,ylabel='Successes within 5 px / 18',ylim=(14,18.5),yticks=[14,15,16,17,18])
        ax.grid(axis='y',color='.85',linewidth=.5);ax.spines[['top','right']].set_visible(False)
        ax.legend(frameon=False,fontsize=8,loc='lower right')
    fig.savefig(OUT/'figures/parameter_sensitivity.png',dpi=200)
    plt.close(fig)
    # Fixed-time failed frame; strict inner artwork polygon removes phone/room.
    cap=cv2.VideoCapture(str(SESSION/'input.avi'));cap.set(cv2.CAP_PROP_POS_FRAMES,324)
    ok,frame=cap.read();cap.release();assert ok
    polygon=np.int32([[478,228],[636,210],[636,354],[499,370]])
    mask=np.zeros(frame.shape[:2],np.uint8);cv2.fillConvexPoly(mask,polygon,255)
    clean=np.full_like(frame,255);clean[mask>0]=frame[mask>0]
    marker=read_image(ROOT/'assets/marker.png');substitute=read_image(ROOT/'assets/substitute.png')
    metrics={}
    for method in ['SIFT','ORB']:
        engine=PlanarAR(marker,substitute,Settings(method=method,ratio=.72 if method=='SIFT' else .78))
        metrics[method]=engine.process(frame,False)['metrics']
    assert not any(m['accepted'] for m in metrics.values())
    compose(OUT/'figures/failure_examples.png',[read_image(ROOT/'assets/marker_low_detail.png'),clean[210:371,478:637]],
            ['Low-detail reference: no usable match','Real dim frame at 40 s: both rejected'],columns=2,cell=(440,340))
    (OUT/'failure_example_metadata.json').write_text(json.dumps(dict(video_index=324,
        privacy='Only the manually selected inner artwork polygon is retained; cropped edges are not detection results.',
        metrics=metrics),indent=2),encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('part',choices=['sensitivity','replay','annotated','plots'])
    part=parser.parse_args().part
    {'sensitivity':sensitivity,'replay':replay,'annotated':annotated_examples,'plots':plots}[part]()
