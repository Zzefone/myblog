"""Short, headless real-marker check; run only when the marker is presented.

Frames are kept locally in output/private/, never added to the website bundle.
Use ar_app.py for interactive parameter changes and additional scenarios.
"""
from pathlib import Path
from datetime import datetime
import argparse
import csv
import json
import time
import cv2
from ar_core import PlanarAR, Settings, read_image, write_image

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--camera',type=int,default=0)
    parser.add_argument('--seconds',type=float,default=12)
    parser.add_argument('--method',choices=['SIFT','ORB'],default='SIFT')
    parser.add_argument('--scenario',default='frontal')
    parser.add_argument('--backend',choices=['DirectShow','MSMF'],default='DirectShow')
    args=parser.parse_args()
    engine=PlanarAR(read_image(ROOT/'assets'/'marker.png'),read_image(ROOT/'assets'/'substitute.png'),
        Settings(method=args.method,ratio=.72 if args.method=='SIFT' else .78))
    target=ROOT/'output'/'private'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+args.scenario)
    target.mkdir(parents=True,exist_ok=True)
    cap=cv2.VideoCapture(args.camera,cv2.CAP_DSHOW if args.backend=='DirectShow' else cv2.CAP_MSMF)
    if not cap.isOpened():
        raise RuntimeError('Camera could not be opened')
    rows=[]
    best=None
    best_inliers=-1
    start=time.perf_counter()
    print('Real camera test started; no screen-control tool is in use.',flush=True)
    try:
        while time.perf_counter()-start < args.seconds:
            ok,frame=cap.read()
            if not ok: break
            if frame.shape[1]>960:
                scale=960/frame.shape[1]
                frame=cv2.resize(frame,None,fx=scale,fy=scale)
            result=engine.process(frame,debug=False)
            m=result['metrics']
            rows.append(dict(t_seconds=time.perf_counter()-start,accepted=m['accepted'],
                matches=m['matches'],inliers=m['inliers'],inlier_ratio=m['inlier_ratio'],
                coverage=m['source_coverage'],reprojection_median_px=m['reprojection_median_px'],
                processing_ms=m['processing_ms'],reason=m['reason'],
                corners=json.dumps(result['corners'].tolist()) if result['corners'] is not None else ''))
            if m['accepted'] and m['inliers']>best_inliers:
                best_inliers=m['inliers']
                best=frame.copy()
    finally:
        cap.release()
    elapsed=time.perf_counter()-start
    if rows:
        with (target/'frames.csv').open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    summary=dict(scenario=args.scenario,method=args.method,camera=args.camera,backend=args.backend,
        frames=len(rows),accepted=sum(r['accepted'] for r in rows),elapsed_seconds=elapsed,
        observed_processing_loop_fps=len(rows)/elapsed,
        note='Real webcam frames. Acceptance is a detector decision, not ground-truth accuracy. Loop FPS excludes GUI.',
        marker_presentation='User confirmed phone marker in front of camera before running.')
    (target/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    if best is not None:
        result=engine.process(best)
        for key in ['frame','outline','augmented','matches_image']:
            write_image(target/(key+'.png'),result[key])
        # Rectified marker-only view; no other regions are included.
        inverse=cv2.invert(result['H'])[1]
        size=(engine.marker.shape[1],engine.marker.shape[0])
        rectified=cv2.warpPerspective(best,inverse,size)
        write_image(target/'rectified_marker.png',rectified)
    print(json.dumps(summary),flush=True)
    print('Local evidence:',target,flush=True)


if __name__=='__main__': main()
