$ErrorActionPreference = 'Stop'
$projectDirectory = $PSScriptRoot
$opencvPython = 'D:\anaconda3\envs\opencv\python.exe'
Push-Location -LiteralPath $projectDirectory
try {
    & $opencvPython (Join-Path $projectDirectory 'ar_app.py') @args
} finally {
    Pop-Location
}
