"""Plain three-page English report, based on saved measurements."""
from pathlib import Path
import csv
import html
import json
from PIL import Image as PILImage
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Image, Spacer, PageBreak

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
W=A4[0]-112
body=ParagraphStyle('body',fontName='Helvetica',fontSize=10.5,leading=14.5,spaceAfter=9,textColor=colors.black)
heading=ParagraphStyle('heading',parent=body,fontName='Helvetica-Bold',fontSize=13,leading=17,spaceBefore=10,keepWithNext=True)
title=ParagraphStyle('title',parent=heading,fontSize=16,leading=20)
small=ParagraphStyle('small',parent=body,fontSize=9,leading=12)
story=[]
text=[]


def p(value, style=body):
    story.append(Paragraph(html.escape(value),style))
    text.append(value+'\n')


def table(headers,rows,widths):
    data=[[Paragraph('<b>'+html.escape(str(x))+'</b>' if i==0 else html.escape(str(x)),small)
           for x in row] for i,row in enumerate([headers]+rows)]
    t=Table(data,colWidths=widths,repeatRows=1)
    t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LINEABOVE',(0,0),(-1,0),.5,colors.black),
        ('LINEBELOW',(0,0),(-1,-1),.25,colors.black),('TOPPADDING',(0,0),(-1,-1),5),
        ('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    story.extend([t,Spacer(1,8)])
    text.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |')
    text.extend('| '+' | '.join(map(str,row))+' |' for row in rows)
    text.append('')


def image(path,height,caption):
    with PILImage.open(path) as im: w,h=im.size
    scale=min(W/w,height/h)
    story.append(Image(str(path),w*scale,h*scale))
    p(caption,small)
    text.append(f'![{caption}]({path.relative_to(OUT).as_posix()})\n')


def footer(canvas,doc):
    canvas.setFillColor(colors.black)
    canvas.setFont('Helvetica',9)
    canvas.drawRightString(A4[0]-56,28,str(doc.page))


def main():
    metadata=json.loads((OUT/'evaluation_metadata.json').read_text(encoding='utf-8'))
    with (OUT/'synthetic_summary.csv').open(encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f))
    real=json.loads((OUT/'webcam_metadata.json').read_text(encoding='utf-8')) if (OUT/'webcam_metadata.json').exists() else None
    p('Final Project: Marker-based Augmented Reality',title)
    p('Course: Basic Computer Vision | Student: Wang Zhaofeng | Date: 17/10/2026')
    p('The software and GUI were tested on synthetic images and on a phone-displayed marker through the integrated webcam.' if real else
      'Current version: software and synthetic validation completed. Testing a phone-displayed marker through the webcam is still pending.')
    p('1. Method and implementation',heading)
    p('The program finds a reference image in a video frame, then replaces it with another image. Both reference graphics were generated for this project. The application accepts a webcam or a recorded video.')
    table(['Step','Choice and reason'],[
        ['Feature extraction','SIFT is the default. ORB is available for comparison. Marker descriptors are computed once and refreshed when the method or feature limit changes.'],
        ['Matching','Brute-force kNN with k=2. SIFT uses L2 distance; ORB uses Hamming distance.'],
        ['Filtering','A ratio test rejects ambiguous matches. Each target feature is used once. RANSAC then selects geometrically consistent pairs.'],
        ['Alignment','A homography maps the planar marker to the frame. Inlier count, ratio, coverage and the projected outline are checked before replacement.'],
        ['Augmentation','warpPerspective transforms the substitute image. A warped mask limits blending to the marker region. Failed detection leaves the current frame unchanged.']
    ],[105,W-105])
    p('Default settings: 1800 features; ratio 0.72 for SIFT and 0.78 for the ORB benchmark; RANSAC threshold 3 pixels; at least 10 inliers; inlier ratio at least 0.35; reference-point coverage at least 3%; opacity 1. The GUI lets the user adjust the main values.')
    p("The teacher's OpenCV_Image_Utilities.py is used for UTF-8 path reading when available. Its file encoding was converted from cp1252 to UTF-8 without changing the function bodies. Its overlay routine paints a mask with a solid colour, so image replacement is implemented separately.")
    p('Optional residual alignment refinement and 3D rendering are not included.')

    story.append(PageBreak())
    p('2. Synthetic experiments',heading)
    p('The test set contains two marker types, two descriptors and ten conditions, with three small geometric perturbations per condition: 120 runs. Frames are 800 x 600. The known homography provides the true corner locations. A positive run succeeds when the accepted estimate has mean four-corner error at most 5 pixels. Absence cases are counted separately.')
    summary=[]
    positive=[]
    for condition in ['normal','rotation','perspective','dim','shadow','blur','occlusion_25','occlusion_50','clutter']:
        a=next(r for r in rows if r['marker']=='rich' and r['method']=='SIFT' and r['condition']==condition)
        b=next(r for r in rows if r['marker']=='rich' and r['method']=='ORB' and r['condition']==condition)
        summary.append([condition.replace('_',' '),f"{a['successes_5px']}/3",f"{float(a['mean_corner_error_px']):.2f}",f"{b['successes_5px']}/3",f"{float(b['mean_corner_error_px']):.2f}"])
        positive.extend([a,b])
    table(['Condition','SIFT pass','Error px','ORB pass','Error px'],summary,[139,78,84,80,W-381])
    p('Both methods pass all 27 positive cases for the rich marker. The feature-poor grey rectangle passes none of the 27 positive cases for either method. No marker-absence false positives were observed in the 12 tested negative runs. These are small, controlled synthetic sets, not estimates of real-world reliability.')
    p('SIFT gives smaller corner error in the strong perspective case. Performance timings are recorded per run in the CSV files; they exclude debug drawing and GUI display. They should not be read as live camera FPS.')
    image(OUT/'figures'/'perspective_comparison.png',160,'Synthetic perspective test: detected outline, RANSAC inlier matches and replacement.')

    if real:
        story.append(PageBreak())
        p('3. Real phone and webcam tests',heading)
        p('The marker was displayed on a phone in front of the integrated camera. An initial frontal test accepted all 203 frames in 12.5 seconds. A second, guided recording covered tilt, rotation, dimming, partial covering, background changes and marker removal. These were handheld actions, not calibrated angle or lighting measurements.')
        with (OUT/'webcam_replay_summary.csv').open(encoding='utf-8',newline='') as f: real_rows=list(csv.DictReader(f))
        real_table=[]
        for stage in ['frontal','tilt','rotation','dim','occlusion_25','occlusion_50','clutter','absent']:
            a=next(r for r in real_rows if r['scenario']==stage and r['method']=='SIFT')
            b=next(r for r in real_rows if r['scenario']==stage and r['method']=='ORB')
            real_table.append([stage.replace('_',' '),f"{a['accepted']}/{a['frames']}",f"{b['accepted']}/{b['frames']}",
                               f"{float(a['median_processing_ms']):.1f}",f"{float(b['median_processing_ms']):.1f}"])
        table(['Condition','SIFT accepted','ORB accepted','SIFT ms','ORB ms'],real_table,[125,100,100,78,W-403])
        p('Both methods process the same sampled frames from the MJPG recording, taking every fourth frame. Accepted means the estimate passed the checks; it is not ground-truth accuracy. Timings exclude GUI drawing. SIFT is more reliable in this recording; ORB processes frames faster but loses more difficult views.')
        p('Dimming caused frequent losses. The covering steps also included changes in position and focus, so their labels do not establish a measured occlusion percentage. The phone-removal transition before 79 seconds is excluded from the absence row; it still contains the actual marker. Later reviewed samples contain no phone.')
        image(OUT/'figures'/'real_phone_comparison.png',190,'Real camera examples and replacements. Pixels outside the estimated marker are whitened for privacy.')

    story.append(PageBreak())
    p('4. Interface and limits' if real else '3. Interface and webcam validation',heading)
    image(OUT/'figures'/'gui-synthetic-demo.jpg',280,'Actual application window playing the generated synthetic demo, not a webcam recording.')
    p('The GUI provides camera selection, video input, SIFT/ORB selection, matching and RANSAC controls, opacity and two diagnostic views. The replacement and inlier matches appear beside the input frame. Camera capture runs in a separate process so an unavailable virtual camera can be stopped without freezing the interface.')
    p('The interface was launched and inspected with a generated demo. A separate guided capture window recorded the real phone tests. The camera input was 640 x 480. Raw camera images stay under output/private/; only marker-masked examples are published.' if real else
      'The interface was launched and its synthetic video output inspected. Camera indices 0 and 1 returned 640 x 480 frames during an access check. No physical marker test has been completed yet.')
    p('The application can also save an input frame, outline, replacement, matches and recent metrics with Save evidence. The camera capture process stops when the application closes.')
    p('Current limits',heading)
    p('The synthetic tests reuse the exact reference artwork and cannot reproduce screen reflections, rolling shutter, focus changes or all camera noise. A plain marker has too few distinctive features. Severe viewpoint changes, blur and occlusion can remove enough matches to prevent alignment.')
    p('Occlusion is tested as a detection challenge. The replacement is drawn over the full estimated marker region, including any foreground hand; foreground-aware occlusion handling is not implemented. There is no temporal tracking or smoothing. The guided sequence is a small qualitative test, and no independent real-camera corner accuracy or jitter score is claimed.')
    p('References: course project sheet; OpenCV Feature Matching and Feature Matching + Homography tutorials. Tested with Python '+metadata['python'].split()[0]+', OpenCV '+metadata['opencv']+' and NumPy '+metadata['numpy']+'.')
    doc=SimpleDocTemplate(str(OUT/'Project_Report.pdf'),pagesize=A4,leftMargin=56,rightMargin=56,
        topMargin=45,bottomMargin=45,title='Marker-based AR - project report',author='Wang Zhaofeng')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    (OUT/'Project_Report.md').write_text('\n'.join(text),encoding='utf-8')
    print(OUT/'Project_Report.pdf')


if __name__=='__main__': main()
