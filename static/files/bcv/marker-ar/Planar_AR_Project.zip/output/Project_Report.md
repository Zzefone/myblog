Final Project: Marker-based Augmented Reality

Course: Basic Computer Vision | Student: Wang Zhaofeng | Date: 17/10/2026

Current version: software and synthetic validation completed. Testing a phone-displayed marker through the webcam is still pending.

1. Method and implementation

The program finds a reference image in a video frame, then replaces it with another image. Both reference graphics were generated for this project. The application accepts a webcam or a recorded video.

| Step | Choice and reason |
| --- | --- |
| Feature extraction | SIFT is the default. ORB is available for comparison. Marker descriptors are computed once and refreshed when the method or feature limit changes. |
| Matching | Brute-force kNN with k=2. SIFT uses L2 distance; ORB uses Hamming distance. |
| Filtering | A ratio test rejects ambiguous matches. Each target feature is used once. RANSAC then selects geometrically consistent pairs. |
| Alignment | A homography maps the planar marker to the frame. Inlier count, ratio, coverage and the projected outline are checked before replacement. |
| Augmentation | warpPerspective transforms the substitute image. A warped mask limits blending to the marker region. Failed detection leaves the current frame unchanged. |

Default settings: 1800 features; ratio 0.72 for SIFT and 0.78 for the ORB benchmark; RANSAC threshold 3 pixels; at least 10 inliers; inlier ratio at least 0.35; reference-point coverage at least 3%; opacity 1. The GUI lets the user adjust the main values.

The teacher's OpenCV_Image_Utilities.py is used for UTF-8 path reading when available. Its file encoding was converted from cp1252 to UTF-8 without changing the function bodies. Its overlay routine paints a mask with a solid colour, so image replacement is implemented separately.

Optional residual alignment refinement and 3D rendering are not included.

2. Synthetic experiments

The test set contains two marker types, two descriptors and ten conditions, with three small geometric perturbations per condition: 120 runs. Frames are 800 x 600. The known homography provides the true corner locations. A positive run succeeds when the accepted estimate has mean four-corner error at most 5 pixels. Absence cases are counted separately.

| Condition | SIFT pass | Error px | ORB pass | Error px |
| --- | --- | --- | --- | --- |
| normal | 3/3 | 0.13 | 3/3 | 0.62 |
| rotation | 3/3 | 0.20 | 3/3 | 0.56 |
| perspective | 3/3 | 0.49 | 3/3 | 3.50 |
| dim | 3/3 | 0.13 | 3/3 | 0.75 |
| shadow | 3/3 | 0.14 | 3/3 | 0.61 |
| blur | 3/3 | 0.56 | 3/3 | 2.14 |
| occlusion 25 | 3/3 | 0.12 | 3/3 | 0.62 |
| occlusion 50 | 3/3 | 0.38 | 3/3 | 1.38 |
| clutter | 3/3 | 0.14 | 3/3 | 0.60 |

Both methods pass all 27 positive cases for the rich marker. The feature-poor grey rectangle passes none of the 27 positive cases for either method. No marker-absence false positives were observed in the 12 tested negative runs. These are small, controlled synthetic sets, not estimates of real-world reliability.

SIFT gives smaller corner error in the strong perspective case. Performance timings are recorded per run in the CSV files; they exclude debug drawing and GUI display. They should not be read as live camera FPS.

Synthetic perspective test: detected outline, RANSAC inlier matches and replacement.

![Synthetic perspective test: detected outline, RANSAC inlier matches and replacement.](figures/perspective_comparison.png)

3. Interface and webcam validation

Actual application window playing the generated synthetic demo, not a webcam recording.

![Actual application window playing the generated synthetic demo, not a webcam recording.](figures/gui-synthetic-demo.jpg)

The GUI provides camera selection, video input, SIFT/ORB selection, matching and RANSAC controls, opacity and two diagnostic views. The replacement and inlier matches appear beside the input frame. Camera capture runs in a separate process so an unavailable virtual camera can be stopped without freezing the interface.

The interface was launched and its synthetic video output inspected. Camera indices 0 and 1 returned 640 x 480 frames during an access check; a camera image alone does not validate marker detection. No physical marker test has been completed yet.

Next, display assets/marker.png full-screen on a phone. Save evidence for a frontal view, rotation/tilt, lighting changes, partial occlusion and a cluttered background. Compare SIFT and ORB on the same recorded input. Evidence is stored locally under output/private/ and is not published automatically.

4. Current limits

The synthetic tests reuse the exact reference artwork and cannot reproduce screen reflections, rolling shutter, focus changes or all camera noise. A plain marker has too few distinctive features. Severe viewpoint changes, blur and occlusion can remove enough matches to prevent alignment.

Occlusion is currently tested as a detection challenge. The replacement is drawn over the full estimated marker region, including any foreground hand; foreground-aware occlusion handling is not implemented. There is no temporal tracking or smoothing, so live jitter still needs to be measured.

References: course project sheet; OpenCV Feature Matching and Feature Matching + Homography tutorials. Tested with Python 3.11.16, OpenCV 5.0.0 and NumPy 2.4.6.
