"""Tk GUI for live webcam / recorded-video planar augmentation.

Camera capture runs in a disposable child process so an unavailable virtual
camera cannot freeze the interface. No camera frames are saved automatically.
"""
from pathlib import Path
import argparse
import csv
import json
import multiprocessing as mp
import queue
import time
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import cv2
import numpy as np
from PIL import Image, ImageTk, ImageOps
from ar_core import PlanarAR, Settings, read_image, write_image

ROOT = Path(__file__).resolve().parent


def capture_worker(source, backend, frames, messages, stop):
    api = {'Auto': cv2.CAP_ANY, 'MSMF': cv2.CAP_MSMF, 'DirectShow': cv2.CAP_DSHOW}[backend]
    cap = cv2.VideoCapture(source, api if isinstance(source, int) else cv2.CAP_ANY)
    if not cap.isOpened():
        messages.put('Cannot open the selected camera or video')
        return
    if isinstance(source, int):
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    messages.put('Source opened')
    try:
        while not stop.is_set():
            start = time.perf_counter()
            ok, frame = cap.read()
            if not ok:
                messages.put('End of video' if isinstance(source, str) else 'Camera did not return a frame')
                break
            if frame.shape[1] > 960:
                scale = 960/frame.shape[1]
                frame = cv2.resize(frame, None, fx=scale, fy=scale)
            try:
                frames.put_nowait(frame)
            except queue.Full:
                try:
                    frames.get_nowait()
                except queue.Empty:
                    pass
                try:
                    frames.put_nowait(frame)
                except queue.Full:
                    pass
            if isinstance(source, str):
                stop.wait(max(0, 1/max(1, fps)-(time.perf_counter()-start)))
    finally:
        cap.release()


class App:
    def __init__(self, root, args):
        self.root, self.args = root, args
        self.process = None
        self.frame_queue = self.message_queue = self.stop_event = None
        self.last = None
        self.recent = []
        self.method = tk.StringVar(value='SIFT')
        self.camera = tk.IntVar(value=args.camera)
        self.backend = tk.StringVar(value='DirectShow')
        self.mode = tk.StringVar(value='Outline')
        self.ratio = tk.DoubleVar(value=.72)
        self.ransac = tk.DoubleVar(value=3)
        self.minimum = tk.IntVar(value=10)
        self.features = tk.IntVar(value=1800)
        self.opacity = tk.DoubleVar(value=1)
        self.status = tk.StringVar(value='Choose a camera and click Start camera, or open the generated demo video.')
        self.engine = PlanarAR(read_image(args.marker), read_image(args.substitute))
        root.title('BCV - Marker-based augmented reality')
        root.geometry('1280x840')
        root.minsize(960, 650)
        toolbar = ttk.Frame(root, padding=8)
        toolbar.pack(fill='x')
        ttk.Label(toolbar, text='Camera index').pack(side='left')
        ttk.Spinbox(toolbar, from_=0, to=7, width=3, textvariable=self.camera).pack(side='left', padx=4)
        ttk.Combobox(toolbar, width=10, values=['DirectShow', 'MSMF', 'Auto'], state='readonly', textvariable=self.backend).pack(side='left', padx=4)
        ttk.Button(toolbar, text='Start camera', command=self.start_camera).pack(side='left', padx=3)
        ttk.Button(toolbar, text='Open video', command=self.open_video).pack(side='left', padx=3)
        ttk.Button(toolbar, text='Demo', command=lambda: self.start_source(str(ROOT/'output'/'synthetic_demo.avi'))).pack(side='left', padx=3)
        ttk.Button(toolbar, text='Stop', command=self.stop).pack(side='left', padx=3)
        ttk.Button(toolbar, text='Save evidence', command=self.save).pack(side='left', padx=3)
        ttk.Button(toolbar, text='Marker file', command=self.show_marker).pack(side='left', padx=3)
        controls = ttk.Frame(root, padding=(8, 0, 8, 6))
        controls.pack(fill='x')
        ttk.Label(controls, text='Descriptor').grid(row=0, column=0)
        ttk.Combobox(controls, values=['SIFT', 'ORB'], width=7, state='readonly', textvariable=self.method).grid(row=1, column=0, padx=6)
        for column, (label, variable, low, high, resolution) in enumerate([
                ('Ratio test', self.ratio, .5, .95, .01),
                ('RANSAC px', self.ransac, 1, 8, .5),
                ('Min inliers', self.minimum, 4, 30, 1),
                ('Features', self.features, 500, 3000, 100),
                ('Opacity', self.opacity, 0, 1, .05)], 1):
            tk.Scale(controls, label=label, variable=variable, from_=low, to=high,
                     resolution=resolution, orient='horizontal', length=170,
                     highlightthickness=0).grid(row=0, column=column, rowspan=2, padx=4)
        ttk.Label(controls, text='Left view').grid(row=0, column=6)
        ttk.Combobox(controls, values=['Outline', 'Keypoints'], width=9, state='readonly', textvariable=self.mode).grid(row=1, column=6)
        views = ttk.Frame(root, padding=8)
        views.pack(fill='both', expand=True)
        self.labels = []
        for column, title in enumerate(['Camera / detected marker', 'Replacement', 'Filtered RANSAC matches']):
            group = ttk.Frame(views)
            group.grid(row=0, column=column, sticky='nsew', padx=3)
            views.columnconfigure(column, weight=1, uniform='views')
            ttk.Label(group, text=title).pack()
            label = tk.Label(group, background='white')
            label.pack(fill='both', expand=True)
            self.labels.append(label)
        views.rowconfigure(0, weight=1)
        ttk.Label(root, textvariable=self.status, padding=8, wraplength=1200).pack(fill='x')
        ttk.Label(root, text='Show assets/marker.png on a phone/tablet. Keep the image flat, bright and visible. Saved camera images stay in output/private/.', padding=8).pack(fill='x')
        root.protocol('WM_DELETE_WINDOW', self.close)
        root.after(100, self.tick)
        if args.demo:
            root.after(400, lambda: self.start_source(str(ROOT/'output'/'synthetic_demo.avi')))
        if args.smoke_seconds:
            root.after(int(args.smoke_seconds*1000), self.close)

    def show_marker(self):
        window = tk.Toplevel(self.root)
        window.title('Reference marker - assets/marker.png')
        image = Image.open(self.args.marker)
        image.thumbnail((800, 600))
        photo = ImageTk.PhotoImage(image)
        label = tk.Label(window, image=photo)
        label.image = photo
        label.pack()
        ttk.Label(window, text=str(self.args.marker)).pack()

    def start_camera(self):
        self.start_source(int(self.camera.get()))

    def open_video(self):
        path = filedialog.askopenfilename(filetypes=[('Video', '*.mp4 *.avi *.mov *.mkv'), ('All files', '*')])
        if path:
            self.start_source(path)

    def start_source(self, source):
        self.stop()
        if isinstance(source, str) and not Path(source).exists():
            messagebox.showerror('Missing video', 'Run evaluate.py to generate the demo first.')
            return
        self.frame_queue = mp.Queue(maxsize=1)
        self.message_queue = mp.Queue()
        self.stop_event = mp.Event()
        self.process = mp.Process(target=capture_worker,
            args=(source, self.backend.get(), self.frame_queue, self.message_queue, self.stop_event), daemon=True)
        self.process.start()
        self.status.set(f'Opening {source}. If a virtual camera stays blank, stop and try another index/backend.')

    def stop(self):
        if self.process is not None:
            self.stop_event.set()
            self.process.join(timeout=.3)
            if self.process.is_alive():
                self.process.terminate()
                self.process.join(timeout=1)
            self.process = None
            self.frame_queue.close()
            self.message_queue.close()
            self.frame_queue = self.message_queue = None
        self.status.set('Stopped')

    def tick(self):
        try:
            if self.message_queue is not None:
                try:
                    self.status.set(self.message_queue.get_nowait())
                except queue.Empty:
                    pass
            if self.frame_queue is not None:
                try:
                    frame = self.frame_queue.get_nowait()
                except queue.Empty:
                    frame = None
                if frame is not None:
                    self.engine.settings = Settings(method=self.method.get(), features=int(self.features.get()),
                        ratio=float(self.ratio.get()), ransac_px=float(self.ransac.get()),
                        min_inliers=int(self.minimum.get()), opacity=float(self.opacity.get()))
                    self.last = self.engine.process(frame)
                    m = self.last['metrics']
                    self.recent.append({k: m[k] for k in ['method', 'matches', 'inliers', 'inlier_ratio', 'accepted', 'processing_ms', 'reason']})
                    self.recent = self.recent[-600:]
                    self.status.set(f"{m['reason']} | {m['method']} | keypoints {m['frame_keypoints']} | matches {m['matches']} | inliers {m['inliers']} | processing {m['processing_ms']:.1f} ms (excluding drawing/display)")
                    self.render()
        except Exception as exc:
            self.status.set(f'Error: {exc}')
        self.root.after(20, self.tick)

    def render(self):
        source = self.last['keypoints'] if self.mode.get() == 'Keypoints' else self.last['outline']
        for label, image in zip(self.labels, [source, self.last['augmented'], self.last['matches_image']]):
            pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            pil = ImageOps.contain(pil, (max(100, label.winfo_width()), max(100, label.winfo_height())))
            photo = ImageTk.PhotoImage(pil)
            label.configure(image=photo)
            label.image = photo

    def save(self):
        if self.last is None:
            return
        target = ROOT/'output'/'private'/datetime.now().strftime('%Y%m%d-%H%M%S-%f')
        target.mkdir(parents=True, exist_ok=True)
        for name in ['frame', 'outline', 'augmented', 'keypoints', 'matches_image']:
            write_image(target/f'{name}.png', self.last[name])
        (target/'metrics.json').write_text(json.dumps(self.last['metrics'], indent=2), encoding='utf-8')
        with (target/'recent_frames.csv').open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(self.recent[0]))
            writer.writeheader()
            writer.writerows(self.recent)
        self.status.set(f'Saved locally: {target}')

    def close(self):
        self.stop()
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--marker', type=Path, default=ROOT/'assets'/'marker.png')
    parser.add_argument('--substitute', type=Path, default=ROOT/'assets'/'substitute.png')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--smoke-seconds', type=float, default=0, help='Auto-close GUI for a smoke test')
    args = parser.parse_args()
    root = tk.Tk()
    App(root, args)
    root.mainloop()


if __name__ == '__main__':
    mp.freeze_support()
    main()
