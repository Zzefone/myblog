# BCV Final Project: Marker-based augmented reality

状态：程序、GUI 和 120 个合成测试已完成；已确认电脑摄像头能返回图像。**手机展示 marker 的真实测试尚未完成**。报告和博客草稿已注明此限制。

## 打开程序

在 PowerShell 中：

```powershell
Set-Location 'D:\1_VAR_blog\BCV\final_project'
& 'D:\anaconda3\envs\opencv\python.exe' .\ar_app.py
```

也可运行 `run.ps1`。点击 **Start camera**；默认摄像头编号 0、DirectShow 后端。如果是虚拟摄像头或无画面，停止后换编号或 MSMF 后端。电脑检测到 Integrated Camera，测试时编号 0 和 1 均能读取 640×480 图像，其中一个可能是 NVIDIA 虚拟摄像头。

## 手机展示

把 `assets/marker.png` 发到手机，横屏、全屏显示，适当提高亮度并避免反光。把整张图片放在摄像头前，先正对镜头，再慢慢转动。检测成功时，左侧会画出边框，中间会出现替换图片，右侧显示 RANSAC 内点匹配。

主算法是 SIFT + kNN ratio test + RANSAC 单应性 + 透视替换；可切换到 ORB 比较。界面可调特征点上限、ratio、RANSAC 像素阈值、最小内点数和不透明度。对齐不可靠时不叠加；没有隐藏的跨帧跟踪或保留上一帧定位。

## 真实测试需要保存什么

每种情况停稳后点击 **Save evidence**：

1. 正面、正常光照，整张图可见。
2. 旋转或倾斜手机。
3. 改变屏幕亮度或房间光线。
4. 用手遮住约四分之一、再遮住约一半。
5. 更复杂背景；另测一次没有 marker 的画面。

每次会在 `output/private/<时间>/` 保存输入图、轮廓、替换图、匹配图、参数和最近帧指标。摄像头画面默认不保存，也不自动上传。此目录不进入博客素材或下载包。尚未采集的测试不会写成成功。

## 自动测试和演示

```powershell
& 'D:\anaconda3\envs\opencv\python.exe' .\make_assets.py
& 'D:\anaconda3\envs\opencv\python.exe' .\evaluate.py
& 'D:\anaconda3\envs\opencv\python.exe' .\ar_app.py --demo
```

`evaluate.py` 在 800×600 合成图上测试丰富/低细节两种参考图、SIFT/ORB、10 种条件、每种 3 个透视扰动，共 120 次。成功条件为接受配准，且四个角点的平均误差不超过 5 像素。无 marker 场景单独计误检。种子、参数、库版本和文件哈希见 `output/evaluation_metadata.json`。这组小型合成测试不能替代真实摄像头测试，也不能据此保证任意遮挡、光照或背景下稳定。

`output/synthetic_demo.avi` 是自动生成的视频，画面中明确标为 SYNTHETIC，不是摄像头录像。`output/figures/gui-synthetic-demo.jpg` 为实际程序界面截图，里面播放的是该合成演示。

## 文件

- `ar_core.py`：特征、匹配、过滤、单应性、几何检查和图像替换。
- `ar_app.py`：交互界面及摄像头/视频读取。
- `make_assets.py`：生成原创 marker、低细节对照和替换图。
- `evaluate.py`：合成测试、实现检查和示例图。
- `assets/marker.png`：要展示在手机上的图片。
- `assets/substitute.png`：替换图片。
- `output/synthetic_summary.csv`：每组结果。
- `output/Project_Report.pdf`：简短英文报告，当前注明真实测试待补。

本地存在老师提供的 `OpenCV_Image_Utilities.py` 时，程序复用其 `imread_utf8`。原文件编码为 cp1252，已备份到 `tmp/original/` 并转成 UTF-8，未改函数体。`overlay_uchar_image` 是纯色遮罩叠加，不是完整图片融合，所以透视贴图由项目代码完成。公开代码包不包含老师的工具文件；缺少它时使用等价的本地读图实现。

依赖已经存在于 opencv 环境，无需重新安装。报告生成另外使用带 reportlab 的 Codex 文档 Python。3D 渲染和可选的残差配准细化未实现。
